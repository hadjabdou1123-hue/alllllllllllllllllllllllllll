/* { "version": "1", "hash": "MEQCIFFwiew/FVansRtei5mIiJZtU7D6sU9FsooHZJr40sEXAiAnO/w3KvwKAbstScYdVu2W3RxgR97rmRRgjd3r5YFt4w==" } */
/* https://hcaptcha.com/license */
! function() {
    "use strict";

    function e(e) {
        var t = this.constructor;
        return this.then((function(n) {
            return t.resolve(e()).then((function() {
                return n
            }))
        }), (function(n) {
            return t.resolve(e()).then((function() {
                return t.reject(n)
            }))
        }))
    }

    function t(e) {
        return new this((function(t, n) {
            if (!e || "undefined" == typeof e.length) return n(new TypeError(typeof e + " " + e + " is not iterable(cannot read property Symbol(Symbol.iterator))"));
            var r = Array.prototype.slice.call(e);
            if (0 === r.length) return t([]);
            var i = r.length;

            function o(e, n) {
                if (n && ("object" == typeof n || "function" == typeof n)) {
                    var a = n.then;
                    if ("function" == typeof a) return void a.call(n, (function(t) {
                        o(e, t)
                    }), (function(n) {
                        r[e] = {
                            status: "rejected",
                            reason: n
                        }, 0 == --i && t(r)
                    }))
                }
                r[e] = {
                    status: "fulfilled",
                    value: n
                }, 0 == --i && t(r)
            }
            for (var a = 0; a < r.length; a++) o(a, r[a])
        }))
    }
    var n = setTimeout,
        r = "undefined" != typeof setImmediate ? setImmediate : null;

    function i(e) {
        return Boolean(e && "undefined" != typeof e.length)
    }

    function o() {}

    function a(e) {
        if (!(this instanceof a)) throw new TypeError("Promises must be constructed via new");
        if ("function" != typeof e) throw new TypeError("not a function");
        this._state = 0, this._handled = !1, this._value = undefined, this._deferreds = [], p(e, this)
    }

    function s(e, t) {
        for (; 3 === e._state;) e = e._value;
        0 !== e._state ? (e._handled = !0, a._immediateFn((function() {
            var n = 1 === e._state ? t.onFulfilled : t.onRejected;
            if (null !== n) {
                var r;
                try {
                    r = n(e._value)
                } catch (i) {
                    return void c(t.promise, i)
                }
                l(t.promise, r)
            } else(1 === e._state ? l : c)(t.promise, e._value)
        }))) : e._deferreds.push(t)
    }

    function l(e, t) {
        try {
            if (t === e) throw new TypeError("A promise cannot be resolved with itself.");
            if (t && ("object" == typeof t || "function" == typeof t)) {
                var n = t.then;
                if (t instanceof a) return e._state = 3, e._value = t, void u(e);
                if ("function" == typeof n) return void p((r = n, i = t, function() {
                    r.apply(i, arguments)
                }), e)
            }
            e._state = 1, e._value = t, u(e)
        } catch (o) {
            c(e, o)
        }
        var r, i
    }

    function c(e, t) {
        e._state = 2, e._value = t, u(e)
    }

    function u(e) {
        2 === e._state && 0 === e._deferreds.length && a._immediateFn((function() {
            e._handled || a._unhandledRejectionFn(e._value)
        }));
        for (var t = 0, n = e._deferreds.length; t < n; t++) s(e, e._deferreds[t]);
        e._deferreds = null
    }

    function h(e, t, n) {
        this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = n
    }

    function p(e, t) {
        var n = !1;
        try {
            e((function(e) {
                n || (n = !0, l(t, e))
            }), (function(e) {
                n || (n = !0, c(t, e))
            }))
        } catch (r) {
            if (n) return;
            n = !0, c(t, r)
        }
    }
    a.prototype["catch"] = function(e) {
        return this.then(null, e)
    }, a.prototype.then = function(e, t) {
        var n = new this.constructor(o);
        return s(this, new h(e, t, n)), n
    }, a.prototype["finally"] = e, a.all = function(e) {
        return new a((function(t, n) {
            if (!i(e)) return n(new TypeError("Promise.all accepts an array"));
            var r = Array.prototype.slice.call(e);
            if (0 === r.length) return t([]);
            var o = r.length;

            function a(e, i) {
                try {
                    if (i && ("object" == typeof i || "function" == typeof i)) {
                        var s = i.then;
                        if ("function" == typeof s) return void s.call(i, (function(t) {
                            a(e, t)
                        }), n)
                    }
                    r[e] = i, 0 == --o && t(r)
                } catch (l) {
                    n(l)
                }
            }
            for (var s = 0; s < r.length; s++) a(s, r[s])
        }))
    }, a.allSettled = t, a.resolve = function(e) {
        return e && "object" == typeof e && e.constructor === a ? e : new a((function(t) {
            t(e)
        }))
    }, a.reject = function(e) {
        return new a((function(t, n) {
            n(e)
        }))
    }, a.race = function(e) {
        return new a((function(t, n) {
            if (!i(e)) return n(new TypeError("Promise.race accepts an array"));
            for (var r = 0, o = e.length; r < o; r++) a.resolve(e[r]).then(t, n)
        }))
    }, a._immediateFn = "function" == typeof r && function(e) {
        r(e)
    } || function(e) {
        n(e, 0)
    }, a._unhandledRejectionFn = function(e) {
        "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
    };
    var d = function() {
        if ("undefined" != typeof self) return self;
        if ("undefined" != typeof window) return window;
        if ("undefined" != typeof global) return global;
        throw new Error("unable to locate global object")
    }();

    function f(e, t, n) {
        return t <= e && e <= n
    }

    function m(e) {
        if (e === undefined) return {};
        if (e === Object(e)) return e;
        throw TypeError("Could not convert argument to dictionary")
    }
    "function" != typeof d.Promise ? d.Promise = a : (d.Promise.prototype["finally"] || (d.Promise.prototype["finally"] = e), d.Promise.allSettled || (d.Promise.allSettled = t));
    var g = function(e) {
            return e >= 0 && e <= 127
        },
        y = -1;

    function V(e) {
        this.tokens = [].slice.call(e), this.tokens.reverse()
    }
    V.prototype = {
        endOfStream: function() {
            return !this.tokens.length
        },
        read: function() {
            return this.tokens.length ? this.tokens.pop() : y
        },
        prepend: function(e) {
            if (Array.isArray(e))
                for (var t = e; t.length;) this.tokens.push(t.pop());
            else this.tokens.push(e)
        },
        push: function(e) {
            if (Array.isArray(e))
                for (var t = e; t.length;) this.tokens.unshift(t.shift());
            else this.tokens.unshift(e)
        }
    };
    var v = -1;

    function b(e, t) {
        if (e) throw TypeError("Decoder error");
        return t || 65533
    }

    function R(e) {
        return e = String(e).trim().toLowerCase(), Object.prototype.hasOwnProperty.call(w, e) ? w[e] : null
    }
    var w = {};
    [{
        encodings: [{
            labels: ["unicode-1-1-utf-8", "utf-8", "utf8"],
            name: "UTF-8"
        }],
        heading: "The Encoding"
    }].forEach((function(e) {
        e.encodings.forEach((function(e) {
            e.labels.forEach((function(t) {
                w[t] = e
            }))
        }))
    }));
    var T, S = {
            "UTF-8": function(e) {
                return new W(e)
            }
        },
        E = {
            "UTF-8": function(e) {
                return new x(e)
            }
        },
        _ = "utf-8";

    function k(e, t) {
        if (!(this instanceof k)) throw TypeError("Called as a function. Did you forget 'new'?");
        e = e !== undefined ? String(e) : _, t = m(t), this._encoding = null, this._decoder = null, this._ignoreBOM = !1, this._BOMseen = !1, this._error_mode = "replacement", this._do_not_flush = !1;
        var n = R(e);
        if (null === n || "replacement" === n.name) throw RangeError("Unknown encoding: " + e);
        if (!E[n.name]) throw Error("Decoder not present. Did you forget to include encoding-indexes.js first?");
        var r = this;
        return r._encoding = n, t.fatal && (r._error_mode = "fatal"), t.ignoreBOM && (r._ignoreBOM = !0), Object.defineProperty || (this.encoding = r._encoding.name.toLowerCase(), this.fatal = "fatal" === r._error_mode, this.ignoreBOM = r._ignoreBOM), r
    }

    function U(e, t) {
        if (!(this instanceof U)) throw TypeError("Called as a function. Did you forget 'new'?");
        t = m(t), this._encoding = null, this._encoder = null, this._do_not_flush = !1, this._fatal = t.fatal ? "fatal" : "replacement";
        var n = this;
        if (t.NONSTANDARD_allowLegacyEncoding) {
            var r = R(e = e !== undefined ? String(e) : _);
            if (null === r || "replacement" === r.name) throw RangeError("Unknown encoding: " + e);
            if (!S[r.name]) throw Error("Encoder not present. Did you forget to include encoding-indexes.js first?");
            n._encoding = r
        } else n._encoding = R("utf-8");
        return Object.defineProperty || (this.encoding = n._encoding.name.toLowerCase()), n
    }

    function x(e) {
        var t = e.fatal,
            n = 0,
            r = 0,
            i = 0,
            o = 128,
            a = 191;
        this.handler = function(e, s) {
            if (s === y && 0 !== i) return i = 0, b(t);
            if (s === y) return v;
            if (0 === i) {
                if (f(s, 0, 127)) return s;
                if (f(s, 194, 223)) i = 1, n = 31 & s;
                else if (f(s, 224, 239)) 224 === s && (o = 160), 237 === s && (a = 159), i = 2, n = 15 & s;
                else {
                    if (!f(s, 240, 244)) return b(t);
                    240 === s && (o = 144), 244 === s && (a = 143), i = 3, n = 7 & s
                }
                return null
            }
            if (!f(s, o, a)) return n = i = r = 0, o = 128, a = 191, e.prepend(s), b(t);
            if (o = 128, a = 191, n = n << 6 | 63 & s, (r += 1) !== i) return null;
            var l = n;
            return n = i = r = 0, l
        }
    }

    function W(e) {
        e.fatal;
        this.handler = function(e, t) {
            if (t === y) return v;
            if (g(t)) return t;
            var n, r;
            f(t, 128, 2047) ? (n = 1, r = 192) : f(t, 2048, 65535) ? (n = 2, r = 224) : f(t, 65536, 1114111) && (n = 3, r = 240);
            for (var i = [(t >> 6 * n) + r]; n > 0;) {
                var o = t >> 6 * (n - 1);
                i.push(128 | 63 & o), n -= 1
            }
            return i
        }
    }
    Object.defineProperty && (Object.defineProperty(k.prototype, "encoding", {
            get: function() {
                return this._encoding.name.toLowerCase()
            }
        }), Object.defineProperty(k.prototype, "fatal", {
            get: function() {
                return "fatal" === this._error_mode
            }
        }), Object.defineProperty(k.prototype, "ignoreBOM", {
            get: function() {
                return this._ignoreBOM
            }
        })), k.prototype.decode = function(e, t) {
            var n;
            n = "object" == typeof e && e instanceof ArrayBuffer ? new Uint8Array(e) : "object" == typeof e && "buffer" in e && e.buffer instanceof ArrayBuffer ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(0), t = m(t), this._do_not_flush || (this._decoder = E[this._encoding.name]({
                fatal: "fatal" === this._error_mode
            }), this._BOMseen = !1), this._do_not_flush = Boolean(t.stream);
            for (var r, i = new V(n), o = [];;) {
                var a = i.read();
                if (a === y) break;
                if ((r = this._decoder.handler(i, a)) === v) break;
                null !== r && (Array.isArray(r) ? o.push.apply(o, r) : o.push(r))
            }
            if (!this._do_not_flush) {
                do {
                    if ((r = this._decoder.handler(i, i.read())) === v) break;
                    null !== r && (Array.isArray(r) ? o.push.apply(o, r) : o.push(r))
                } while (!i.endOfStream());
                this._decoder = null
            }
            return function(e) {
                var t, n;
                return t = ["UTF-8", "UTF-16LE", "UTF-16BE"], n = this._encoding.name, -1 === t.indexOf(n) || this._ignoreBOM || this._BOMseen || (e.length > 0 && 65279 === e[0] ? (this._BOMseen = !0, e.shift()) : e.length > 0 && (this._BOMseen = !0)),
                    function(e) {
                        for (var t = "", n = 0; n < e.length; ++n) {
                            var r = e[n];
                            r <= 65535 ? t += String.fromCharCode(r) : (r -= 65536, t += String.fromCharCode(55296 + (r >> 10), 56320 + (1023 & r)))
                        }
                        return t
                    }(e)
            }.call(this, o)
        }, Object.defineProperty && Object.defineProperty(U.prototype, "encoding", {
            get: function() {
                return this._encoding.name.toLowerCase()
            }
        }), U.prototype.encode = function(e, t) {
            e = e === undefined ? "" : String(e), t = m(t), this._do_not_flush || (this._encoder = S[this._encoding.name]({
                fatal: "fatal" === this._fatal
            })), this._do_not_flush = Boolean(t.stream);
            for (var n, r = new V(function(e) {
                    for (var t = String(e), n = t.length, r = 0, i = []; r < n;) {
                        var o = t.charCodeAt(r);
                        if (o < 55296 || o > 57343) i.push(o);
                        else if (o >= 56320 && o <= 57343) i.push(65533);
                        else if (o >= 55296 && o <= 56319)
                            if (r === n - 1) i.push(65533);
                            else {
                                var a = t.charCodeAt(r + 1);
                                if (a >= 56320 && a <= 57343) {
                                    var s = 1023 & o,
                                        l = 1023 & a;
                                    i.push(65536 + (s << 10) + l), r += 1
                                } else i.push(65533)
                            }
                        r += 1
                    }
                    return i
                }(e)), i = [];;) {
                var o = r.read();
                if (o === y) break;
                if ((n = this._encoder.handler(r, o)) === v) break;
                Array.isArray(n) ? i.push.apply(i, n) : i.push(n)
            }
            if (!this._do_not_flush) {
                for (;
                    (n = this._encoder.handler(r, r.read())) !== v;) Array.isArray(n) ? i.push.apply(i, n) : i.push(n);
                this._encoder = null
            }
            return new Uint8Array(i)
        }, window.TextDecoder || (window.TextDecoder = k), window.TextEncoder || (window.TextEncoder = U),
        function(e) {
            if ("function" != typeof Promise) throw "Promise support required";
            var t = e.crypto || e.msCrypto;
            if (t) {
                var n = t.subtle || t.webkitSubtle;
                if (n) {
                    var r = e.Crypto || t.constructor || Object,
                        i = e.SubtleCrypto || n.constructor || Object,
                        o = (e.CryptoKey || e.Key, e.navigator.userAgent.indexOf("Edge/") > -1),
                        a = !!e.msCrypto && !o,
                        s = !t.subtle && !!t.webkitSubtle;
                    if (a || s) {
                        var l = {
                                KoZIhvcNAQEB: "1.2.840.113549.1.1.1"
                            },
                            c = {
                                "1.2.840.113549.1.1.1": "KoZIhvcNAQEB"
                            };
                        if (["generateKey", "importKey", "unwrapKey"].forEach((function(e) {
                                var r = n[e];
                                n[e] = function(i, o, l) {
                                    var c, u, h, f, b = [].slice.call(arguments);
                                    switch (e) {
                                        case "generateKey":
                                            c = m(i), u = o, h = l;
                                            break;
                                        case "importKey":
                                            c = m(l), u = b[3], h = b[4], "jwk" === i && ((o = y(o)).alg || (o.alg = g(c)), o.key_ops || (o.key_ops = "oct" !== o.kty ? "d" in o ? h.filter(E) : h.filter(S) : h.slice()), b[1] = V(o));
                                            break;
                                        case "unwrapKey":
                                            c = b[4], u = b[5], h = b[6], b[2] = l._key
                                    }
                                    if ("generateKey" === e && "HMAC" === c.name && c.hash) return c.length = c.length || {
                                        "SHA-1": 512,
                                        "SHA-256": 512,
                                        "SHA-384": 1024,
                                        "SHA-512": 1024
                                    }[c.hash.name], n.importKey("raw", t.getRandomValues(new Uint8Array(c.length + 7 >> 3)), c, u, h);
                                    if (s && "generateKey" === e && "RSASSA-PKCS1-v1_5" === c.name && (!c.modulusLength || c.modulusLength >= 2048)) return (i = m(i)).name = "RSAES-PKCS1-v1_5", delete i.hash, n.generateKey(i, !0, ["encrypt", "decrypt"]).then((function(e) {
                                        return Promise.all([n.exportKey("jwk", e.publicKey), n.exportKey("jwk", e.privateKey)])
                                    })).then((function(e) {
                                        return e[0].alg = e[1].alg = g(c), e[0].key_ops = h.filter(S), e[1].key_ops = h.filter(E), Promise.all([n.importKey("jwk", e[0], c, !0, e[0].key_ops), n.importKey("jwk", e[1], c, u, e[1].key_ops)])
                                    })).then((function(e) {
                                        return {
                                            publicKey: e[0],
                                            privateKey: e[1]
                                        }
                                    }));
                                    if ((s || a && "SHA-1" === (c.hash || {}).name) && "importKey" === e && "jwk" === i && "HMAC" === c.name && "oct" === o.kty) return n.importKey("raw", d(p(o.k)), l, b[3], b[4]);
                                    if (s && "importKey" === e && ("spki" === i || "pkcs8" === i)) return n.importKey("jwk", v(o), l, b[3], b[4]);
                                    if (a && "unwrapKey" === e) return n.decrypt(b[3], l, o).then((function(e) {
                                        return n.importKey(i, e, b[4], b[5], b[6])
                                    }));
                                    try {
                                        f = r.apply(n, b)
                                    } catch (R) {
                                        return Promise.reject(R)
                                    }
                                    return a && (f = new Promise((function(e, t) {
                                        f.onabort = f.onerror = function(e) {
                                            t(e)
                                        }, f.oncomplete = function(t) {
                                            e(t.target.result)
                                        }
                                    }))), f = f.then((function(e) {
                                        return "HMAC" === c.name && (c.length || (c.length = 8 * e.algorithm.length)), 0 == c.name.search("RSA") && (c.modulusLength || (c.modulusLength = (e.publicKey || e).algorithm.modulusLength), c.publicExponent || (c.publicExponent = (e.publicKey || e).algorithm.publicExponent)), e = e.publicKey && e.privateKey ? {
                                            publicKey: new T(e.publicKey, c, u, h.filter(S)),
                                            privateKey: new T(e.privateKey, c, u, h.filter(E))
                                        } : new T(e, c, u, h)
                                    }))
                                }
                            })), ["exportKey", "wrapKey"].forEach((function(e) {
                                var t = n[e];
                                n[e] = function(r, i, o) {
                                    var l, c = [].slice.call(arguments);
                                    switch (e) {
                                        case "exportKey":
                                            c[1] = i._key;
                                            break;
                                        case "wrapKey":
                                            c[1] = i._key, c[2] = o._key
                                    }
                                    if ((s || a && "SHA-1" === (i.algorithm.hash || {}).name) && "exportKey" === e && "jwk" === r && "HMAC" === i.algorithm.name && (c[0] = "raw"), !s || "exportKey" !== e || "spki" !== r && "pkcs8" !== r || (c[0] = "jwk"), a && "wrapKey" === e) return n.exportKey(r, i).then((function(e) {
                                        return "jwk" === r && (e = d(unescape(encodeURIComponent(JSON.stringify(y(e)))))), n.encrypt(c[3], o, e)
                                    }));
                                    try {
                                        l = t.apply(n, c)
                                    } catch (u) {
                                        return Promise.reject(u)
                                    }
                                    return a && (l = new Promise((function(e, t) {
                                        l.onabort = l.onerror = function(e) {
                                            t(e)
                                        }, l.oncomplete = function(t) {
                                            e(t.target.result)
                                        }
                                    }))), "exportKey" === e && "jwk" === r && (l = l.then((function(e) {
                                        return (s || a && "SHA-1" === (i.algorithm.hash || {}).name) && "HMAC" === i.algorithm.name ? {
                                            kty: "oct",
                                            alg: g(i.algorithm),
                                            key_ops: i.usages.slice(),
                                            ext: !0,
                                            k: h(f(e))
                                        } : ((e = y(e)).alg || (e.alg = g(i.algorithm)), e.key_ops || (e.key_ops = "public" === i.type ? i.usages.filter(S) : "private" === i.type ? i.usages.filter(E) : i.usages.slice()), e)
                                    }))), !s || "exportKey" !== e || "spki" !== r && "pkcs8" !== r || (l = l.then((function(e) {
                                        return e = b(y(e))
                                    }))), l
                                }
                            })), ["encrypt", "decrypt", "sign", "verify"].forEach((function(e) {
                                var t = n[e];
                                n[e] = function(r, i, o, s) {
                                    if (a && (!o.byteLength || s && !s.byteLength)) throw new Error("Empty input is not allowed");
                                    var l, c = [].slice.call(arguments),
                                        u = m(r);
                                    if (!a || "sign" !== e && "verify" !== e || "RSASSA-PKCS1-v1_5" !== r && "HMAC" !== r || (c[0] = {
                                            name: r
                                        }), a && i.algorithm.hash && (c[0].hash = c[0].hash || i.algorithm.hash), a && "decrypt" === e && "AES-GCM" === u.name) {
                                        var h = r.tagLength >> 3;
                                        c[2] = (o.buffer || o).slice(0, o.byteLength - h), r.tag = (o.buffer || o).slice(o.byteLength - h)
                                    }
                                    a && "AES-GCM" === u.name && c[0].tagLength === undefined && (c[0].tagLength = 128), c[1] = i._key;
                                    try {
                                        l = t.apply(n, c)
                                    } catch (p) {
                                        return Promise.reject(p)
                                    }
                                    return a && (l = new Promise((function(t, n) {
                                        l.onabort = l.onerror = function(e) {
                                            n(e)
                                        }, l.oncomplete = function(n) {
                                            n = n.target.result;
                                            if ("encrypt" === e && n instanceof AesGcmEncryptResult) {
                                                var r = n.ciphertext,
                                                    i = n.tag;
                                                (n = new Uint8Array(r.byteLength + i.byteLength)).set(new Uint8Array(r), 0), n.set(new Uint8Array(i), r.byteLength), n = n.buffer
                                            }
                                            t(n)
                                        }
                                    }))), l
                                }
                            })), a) {
                            var u = n.digest;
                            n.digest = function(e, t) {
                                if (!t.byteLength) throw new Error("Empty input is not allowed");
                                var r;
                                try {
                                    r = u.call(n, e, t)
                                } catch (i) {
                                    return Promise.reject(i)
                                }
                                return r = new Promise((function(e, t) {
                                    r.onabort = r.onerror = function(e) {
                                        t(e)
                                    }, r.oncomplete = function(t) {
                                        e(t.target.result)
                                    }
                                })), r
                            }, e.crypto = Object.create(t, {
                                getRandomValues: {
                                    value: function(e) {
                                        return t.getRandomValues(e)
                                    }
                                },
                                subtle: {
                                    value: n
                                }
                            }), e.CryptoKey = T
                        }
                        s && (t.subtle = n, e.Crypto = r, e.SubtleCrypto = i, e.CryptoKey = T)
                    }
                }
            }

            function h(e) {
                return btoa(e).replace(/\=+$/, "").replace(/\+/g, "-").replace(/\//g, "_")
            }

            function p(e) {
                return e = (e += "===").slice(0, -e.length % 4), atob(e.replace(/-/g, "+").replace(/_/g, "/"))
            }

            function d(e) {
                for (var t = new Uint8Array(e.length), n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
                return t
            }

            function f(e) {
                return e instanceof ArrayBuffer && (e = new Uint8Array(e)), String.fromCharCode.apply(String, e)
            }

            function m(e) {
                var t = {
                    name: (e.name || e || "").toUpperCase().replace("V", "v")
                };
                switch (t.name) {
                    case "SHA-1":
                    case "SHA-256":
                    case "SHA-384":
                    case "SHA-512":
                        break;
                    case "AES-CBC":
                    case "AES-GCM":
                    case "AES-KW":
                        e.length && (t.length = e.length);
                        break;
                    case "HMAC":
                        e.hash && (t.hash = m(e.hash)), e.length && (t.length = e.length);
                        break;
                    case "RSAES-PKCS1-v1_5":
                        e.publicExponent && (t.publicExponent = new Uint8Array(e.publicExponent)), e.modulusLength && (t.modulusLength = e.modulusLength);
                        break;
                    case "RSASSA-PKCS1-v1_5":
                    case "RSA-OAEP":
                        e.hash && (t.hash = m(e.hash)), e.publicExponent && (t.publicExponent = new Uint8Array(e.publicExponent)), e.modulusLength && (t.modulusLength = e.modulusLength);
                        break;
                    default:
                        throw new SyntaxError("Bad algorithm name")
                }
                return t
            }

            function g(e) {
                return {
                    HMAC: {
                        "SHA-1": "HS1",
                        "SHA-256": "HS256",
                        "SHA-384": "HS384",
                        "SHA-512": "HS512"
                    },
                    "RSASSA-PKCS1-v1_5": {
                        "SHA-1": "RS1",
                        "SHA-256": "RS256",
                        "SHA-384": "RS384",
                        "SHA-512": "RS512"
                    },
                    "RSAES-PKCS1-v1_5": {
                        "": "RSA1_5"
                    },
                    "RSA-OAEP": {
                        "SHA-1": "RSA-OAEP",
                        "SHA-256": "RSA-OAEP-256"
                    },
                    "AES-KW": {
                        128: "A128KW",
                        192: "A192KW",
                        256: "A256KW"
                    },
                    "AES-GCM": {
                        128: "A128GCM",
                        192: "A192GCM",
                        256: "A256GCM"
                    },
                    "AES-CBC": {
                        128: "A128CBC",
                        192: "A192CBC",
                        256: "A256CBC"
                    }
                }[e.name][(e.hash || {}).name || e.length || ""]
            }

            function y(e) {
                (e instanceof ArrayBuffer || e instanceof Uint8Array) && (e = JSON.parse(decodeURIComponent(escape(f(e)))));
                var t = {
                    kty: e.kty,
                    alg: e.alg,
                    ext: e.ext || e.extractable
                };
                switch (t.kty) {
                    case "oct":
                        t.k = e.k;
                    case "RSA":
                        ["n", "e", "d", "p", "q", "dp", "dq", "qi", "oth"].forEach((function(n) {
                            n in e && (t[n] = e[n])
                        }));
                        break;
                    default:
                        throw new TypeError("Unsupported key type")
                }
                return t
            }

            function V(e) {
                var t = y(e);
                return a && (t.extractable = t.ext, delete t.ext), d(unescape(encodeURIComponent(JSON.stringify(t)))).buffer
            }

            function v(e) {
                var t = R(e),
                    n = !1;
                t.length > 2 && (n = !0, t.shift());
                var r = {
                    ext: !0
                };
                if ("1.2.840.113549.1.1.1" !== t[0][0]) throw new TypeError("Unsupported key type");
                var i = ["n", "e", "d", "p", "q", "dp", "dq", "qi"],
                    o = R(t[1]);
                n && o.shift();
                for (var a = 0; a < o.length; a++) o[a][0] || (o[a] = o[a].subarray(1)), r[i[a]] = h(f(o[a]));
                return r.kty = "RSA", r
            }

            function b(e) {
                var t, n = [
                        ["", null]
                    ],
                    r = !1;
                if ("RSA" !== e.kty) throw new TypeError("Unsupported key type");
                for (var i = ["n", "e", "d", "p", "q", "dp", "dq", "qi"], o = [], a = 0; a < i.length && i[a] in e; a++) {
                    var s = o[a] = d(p(e[i[a]]));
                    128 & s[0] && (o[a] = new Uint8Array(s.length + 1), o[a].set(s, 1))
                }
                return o.length > 2 && (r = !0, o.unshift(new Uint8Array([0]))), n[0][0] = "1.2.840.113549.1.1.1", t = o, n.push(new Uint8Array(w(t)).buffer), r ? n.unshift(new Uint8Array([0])) : n[1] = {
                    tag: 3,
                    value: n[1]
                }, new Uint8Array(w(n)).buffer
            }

            function R(e, t) {
                if (e instanceof ArrayBuffer && (e = new Uint8Array(e)), t || (t = {
                        pos: 0,
                        end: e.length
                    }), t.end - t.pos < 2 || t.end > e.length) throw new RangeError("Malformed DER");
                var n, r = e[t.pos++],
                    i = e[t.pos++];
                if (i >= 128) {
                    if (i &= 127, t.end - t.pos < i) throw new RangeError("Malformed DER");
                    for (var o = 0; i--;) o <<= 8, o |= e[t.pos++];
                    i = o
                }
                if (t.end - t.pos < i) throw new RangeError("Malformed DER");
                switch (r) {
                    case 2:
                        n = e.subarray(t.pos, t.pos += i);
                        break;
                    case 3:
                        if (e[t.pos++]) throw new Error("Unsupported bit string");
                        i--;
                    case 4:
                        n = new Uint8Array(e.subarray(t.pos, t.pos += i)).buffer;
                        break;
                    case 5:
                        n = null;
                        break;
                    case 6:
                        var a = btoa(f(e.subarray(t.pos, t.pos += i)));
                        if (!(a in l)) throw new Error("Unsupported OBJECT ID " + a);
                        n = l[a];
                        break;
                    case 48:
                        n = [];
                        for (var s = t.pos + i; t.pos < s;) n.push(R(e, t));
                        break;
                    default:
                        throw new Error("Unsupported DER tag 0x" + r.toString(16))
                }
                return n
            }

            function w(e, t) {
                t || (t = []);
                var n = 0,
                    r = 0,
                    i = t.length + 2;
                if (t.push(0, 0), e instanceof Uint8Array) {
                    n = 2, r = e.length;
                    for (var o = 0; o < r; o++) t.push(e[o])
                } else if (e instanceof ArrayBuffer) {
                    n = 4, r = e.byteLength, e = new Uint8Array(e);
                    for (o = 0; o < r; o++) t.push(e[o])
                } else if (null === e) n = 5, r = 0;
                else if ("string" == typeof e && e in c) {
                    var a = d(atob(c[e]));
                    n = 6, r = a.length;
                    for (o = 0; o < r; o++) t.push(a[o])
                } else if (e instanceof Array) {
                    for (o = 0; o < e.length; o++) w(e[o], t);
                    n = 48, r = t.length - i
                } else {
                    if (!("object" == typeof e && 3 === e.tag && e.value instanceof ArrayBuffer)) throw new Error("Unsupported DER value " + e);
                    n = 3, r = (e = new Uint8Array(e.value)).byteLength, t.push(0);
                    for (o = 0; o < r; o++) t.push(e[o]);
                    r++
                }
                if (r >= 128) {
                    var s = r;
                    r = 4;
                    for (t.splice(i, 0, s >> 24 & 255, s >> 16 & 255, s >> 8 & 255, 255 & s); r > 1 && !(s >> 24);) s <<= 8, r--;
                    r < 4 && t.splice(i, 4 - r), r |= 128
                }
                return t.splice(i - 2, 2, n, r), t
            }

            function T(e, t, n, r) {
                Object.defineProperties(this, {
                    _key: {
                        value: e
                    },
                    type: {
                        value: e.type,
                        enumerable: !0
                    },
                    extractable: {
                        value: n === undefined ? e.extractable : n,
                        enumerable: !0
                    },
                    algorithm: {
                        value: t === undefined ? e.algorithm : t,
                        enumerable: !0
                    },
                    usages: {
                        value: r === undefined ? e.usages : r,
                        enumerable: !0
                    }
                })
            }

            function S(e) {
                return "verify" === e || "encrypt" === e || "wrapKey" === e
            }

            function E(e) {
                return "sign" === e || "decrypt" === e || "unwrapKey" === e
            }
        }(window), Array.prototype.indexOf || (Array.prototype.indexOf = function(e) {
            return function(t, n) {
                if (null === this || this === undefined) throw TypeError("Array.prototype.indexOf called on null or undefined");
                var r = e(this),
                    i = r.length >>> 0,
                    o = Math.min(0 | n, i);
                if (o < 0) o = Math.max(0, i + o);
                else if (o >= i) return -1;
                if (void 0 === t) {
                    for (; o !== i; ++o)
                        if (void 0 === r[o] && o in r) return o
                } else if (t != t) {
                    for (; o !== i; ++o)
                        if (r[o] != r[o]) return o
                } else
                    for (; o !== i; ++o)
                        if (r[o] === t) return o;
                return -1
            }
        }(Object)), Array.isArray || (Array.isArray = function(e) {
            return "[object Array]" === Object.prototype.toString.call(e)
        }), document.getElementsByClassName || (window.Element.prototype.getElementsByClassName = document.constructor.prototype.getElementsByClassName = function(e) {
            if (document.querySelectorAll) return document.querySelectorAll("." + e);
            for (var t = document.getElementsByTagName("*"), n = new RegExp("(^|\\s)" + e + "(\\s|$)"), r = [], i = 0; i < t.length; i++) n.test(t[i].className) && r.push(t[i]);
            return r
        }), String.prototype.startsWith || (String.prototype.startsWith = function(e, t) {
            return this.substr(!t || t < 0 ? 0 : +t, e.length) === e
        }), String.prototype.endsWith || (String.prototype.endsWith = function(e, t) {
            return (t === undefined || t > this.length) && (t = this.length), this.substring(t - e.length, t) === e
        });
    try {
        if (Object.defineProperty && Object.getOwnPropertyDescriptor && Object.getOwnPropertyDescriptor(Element.prototype, "textContent") && !Object.getOwnPropertyDescriptor(Element.prototype, "textContent").get) {
            var M = Object.getOwnPropertyDescriptor(Element.prototype, "innerText");
            Object.defineProperty(Element.prototype, "textContent", {
                get: function() {
                    return M.get.call(this)
                },
                set: function(e) {
                    M.set.call(this, e)
                }
            })
        }
    } catch (pr) {}
    Function.prototype.bind || (Function.prototype.bind = function(e) {
        if ("function" != typeof this) throw new TypeError("Function.prototype.bind: Item Can Not Be Bound.");
        var t = Array.prototype.slice.call(arguments, 1),
            n = this,
            r = function() {},
            i = function() {
                return n.apply(this instanceof r ? this : e, t.concat(Array.prototype.slice.call(arguments)))
            };
        return this.prototype && (r.prototype = this.prototype), i.prototype = new r, i
    }), "function" != typeof Object.create && (Object.create = function(e, t) {
        function n() {}
        if (n.prototype = e, "object" == typeof t)
            for (var r in t) t.hasOwnProperty(r) && (n[r] = t[r]);
        return new n
    }), Date.now || (Date.now = function() {
        return (new Date).getTime()
    }), window.console || (window.console = {});
    for (var F, N, P, Z, O = ["error", "info", "log", "show", "table", "trace", "warn"], j = function(e) {}, C = O.length; --C > -1;) T = O[C], window.console[T] || (window.console[T] = j);
    if (window.atob) try {
        window.atob(" ")
    } catch (dr) {
        window.atob = function(e) {
            var t = function(t) {
                return e(String(t).replace(/[\t\n\f\r ]+/g, ""))
            };
            return t.original = e, t
        }(window.atob)
    } else {
        var B = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            D = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/;
        window.atob = function(e) {
            if (e = String(e).replace(/[\t\n\f\r ]+/g, ""), !D.test(e)) throw new TypeError("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
            var t, n, r;
            e += "==".slice(2 - (3 & e.length));
            for (var i = "", o = 0; o < e.length;) t = B.indexOf(e.charAt(o++)) << 18 | B.indexOf(e.charAt(o++)) << 12 | (n = B.indexOf(e.charAt(o++))) << 6 | (r = B.indexOf(e.charAt(o++))), i += 64 === n ? String.fromCharCode(t >> 16 & 255) : 64 === r ? String.fromCharCode(t >> 16 & 255, t >> 8 & 255) : String.fromCharCode(t >> 16 & 255, t >> 8 & 255, 255 & t);
            return i
        }
    }
    if (Event.prototype.preventDefault || (Event.prototype.preventDefault = function() {
            this.returnValue = !1
        }), Event.prototype.stopPropagation || (Event.prototype.stopPropagation = function() {
            this.cancelBubble = !0
        }), window.Prototype && Array.prototype.toJSON) {
        console.error("[hCaptcha] Custom JSON polyfill detected, please remove to ensure hCaptcha works properly");
        var A = Array.prototype.toJSON,
            G = JSON.stringify;
        JSON.stringify = function(e) {
            try {
                return delete Array.prototype.toJSON, G(e)
            } finally {
                Array.prototype.toJSON = A
            }
        }
    }
    if (Object.keys || (Object.keys = (F = Object.prototype.hasOwnProperty, N = !Object.prototype.propertyIsEnumerable.call({
            toString: null
        }, "toString"), Z = (P = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"]).length, function(e) {
            if ("function" != typeof e && ("object" != typeof e || null === e)) throw new TypeError("Object.keys called on non-object");
            var t, n, r = [];
            for (t in e) F.call(e, t) && r.push(t);
            if (N)
                for (n = 0; n < Z; n++) F.call(e, P[n]) && r.push(P[n]);
            return r
        })), !Uint8Array.prototype.slice) try {
            Object.defineProperty(Uint8Array.prototype, "slice", {
                value: function(e, t) {
                    return new Uint8Array(Array.prototype.slice.call(this, e, t))
                },
                writable: !0
            })
        } catch (dr) {
            if ("function" != typeof Uint8Array.prototype.slice) try {
                Uint8Array.prototype.slice = function(e, t) {
                    return new Uint8Array(Array.prototype.slice.call(this, e, t))
                }
            } catch (fr) {}
        }
        /*! Raven.js 3.27.2 (6d91db933) | github.com/getsentry/raven-js */
        ! function(e) {
            if ("object" == typeof exports && "undefined" != typeof module) module.exports = e();
            else if ("function" == typeof define && define.amd) define("raven-js", e);
            else {
                ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).Raven = e()
            }
        }((function() {
            return function e(t, n, r) {
                function i(a, s) {
                    if (!n[a]) {
                        if (!t[a]) {
                            var l = "function" == typeof require && require;
                            if (!s && l) return l(a, !0);
                            if (o) return o(a, !0);
                            var c = new Error("Cannot find module '" + a + "'");
                            throw c.code = "MODULE_NOT_FOUND", c
                        }
                        var u = n[a] = {
                            exports: {}
                        };
                        t[a][0].call(u.exports, (function(e) {
                            var n = t[a][1][e];
                            return i(n || e)
                        }), u, u.exports, e, t, n, r)
                    }
                    return n[a].exports
                }
                for (var o = "function" == typeof require && require, a = 0; a < r.length; a++) i(r[a]);
                return i
            }({
                1: [function(e, t, n) {
                    function r(e) {
                        this.name = "RavenConfigError", this.message = e
                    }
                    r.prototype = new Error, r.prototype.constructor = r, t.exports = r
                }, {}],
                2: [function(e, t, n) {
                    var r = e(5);
                    t.exports = {
                        wrapMethod: function(e, t, n) {
                            var i = e[t],
                                o = e;
                            if (t in e) {
                                var a = "warn" === t ? "warning" : t;
                                e[t] = function() {
                                    var e = [].slice.call(arguments),
                                        s = r.safeJoin(e, " "),
                                        l = {
                                            level: a,
                                            logger: "console",
                                            extra: {
                                                arguments: e
                                            }
                                        };
                                    "assert" === t ? !1 === e[0] && (s = "Assertion failed: " + (r.safeJoin(e.slice(1), " ") || "console.assert"), l.extra.arguments = e.slice(1), n && n(s, l)) : n && n(s, l), i && Function.prototype.apply.call(i, o, e)
                                }
                            }
                        }
                    }
                }, {
                    5: 5
                }],
                3: [function(e, t, n) {
                    (function(n) {
                        function r() {
                            return +new Date
                        }

                        function i(e, t) {
                            return V(t) ? function(n) {
                                return t(n, e)
                            } : t
                        }

                        function o() {
                            for (var e in this.a = !("object" != typeof JSON || !JSON.stringify), this.b = !y(z), this.c = !y(X), this.d = null, this.e = null, this.f = null, this.g = null, this.h = null, this.i = null, this.j = {}, this.k = {
                                    release: J.SENTRY_RELEASE && J.SENTRY_RELEASE.id,
                                    logger: "javascript",
                                    ignoreErrors: [],
                                    ignoreUrls: [],
                                    whitelistUrls: [],
                                    includePaths: [],
                                    headers: null,
                                    collectWindowErrors: !0,
                                    captureUnhandledRejections: !0,
                                    maxMessageLength: 0,
                                    maxUrlLength: 250,
                                    stackTraceLimit: 50,
                                    autoBreadcrumbs: !0,
                                    instrument: !0,
                                    sampleRate: 1,
                                    sanitizeKeys: []
                                }, this.l = {
                                    method: "POST",
                                    referrerPolicy: O() ? "origin" : ""
                                }, this.m = 0, this.n = !1, this.o = Error.stackTraceLimit, this.p = J.console || {}, this.q = {}, this.r = [], this.s = r(), this.t = [], this.u = [], this.v = null, this.w = J.location, this.x = this.w && this.w.href, this.y(), this.p) this.q[e] = this.p[e]
                        }
                        var a = e(6),
                            s = e(7),
                            l = e(8),
                            c = e(1),
                            u = e(5),
                            h = u.isErrorEvent,
                            p = u.isDOMError,
                            d = u.isDOMException,
                            f = u.isError,
                            m = u.isObject,
                            g = u.isPlainObject,
                            y = u.isUndefined,
                            V = u.isFunction,
                            v = u.isString,
                            b = u.isArray,
                            R = u.isEmptyObject,
                            w = u.each,
                            T = u.objectMerge,
                            S = u.truncate,
                            E = u.objectFrozen,
                            _ = u.hasKey,
                            k = u.joinRegExp,
                            U = u.urlencode,
                            x = u.uuid4,
                            W = u.htmlTreeAsString,
                            M = u.isSameException,
                            F = u.isSameStacktrace,
                            N = u.parseUrl,
                            P = u.fill,
                            Z = u.supportsFetch,
                            O = u.supportsReferrerPolicy,
                            j = u.serializeKeysForMessage,
                            C = u.serializeException,
                            B = u.sanitize,
                            D = e(2).wrapMethod,
                            A = "source protocol user pass host port path".split(" "),
                            G = /^(?:(\w+):)?\/\/(?:(\w+)(:\w+)?@)?([\w\.-]+)(?::(\d+))?(\/.*)/,
                            J = "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : {},
                            z = J.document,
                            X = J.navigator;
                        o.prototype = {
                            VERSION: "3.27.2",
                            debug: !1,
                            TraceKit: a,
                            config: function(e, t) {
                                var n = this;
                                if (n.g) return this.z("error", "Error: Raven has already been configured"), n;
                                if (!e) return n;
                                var r = n.k;
                                t && w(t, (function(e, t) {
                                    "tags" === e || "extra" === e || "user" === e ? n.j[e] = t : r[e] = t
                                })), n.setDSN(e), r.ignoreErrors.push(/^Script error\.?$/), r.ignoreErrors.push(/^Javascript error: Script error\.? on line 0$/), r.ignoreErrors = k(r.ignoreErrors), r.ignoreUrls = !!r.ignoreUrls.length && k(r.ignoreUrls), r.whitelistUrls = !!r.whitelistUrls.length && k(r.whitelistUrls), r.includePaths = k(r.includePaths), r.maxBreadcrumbs = Math.max(0, Math.min(r.maxBreadcrumbs || 100, 100));
                                var i = {
                                        xhr: !0,
                                        console: !0,
                                        dom: !0,
                                        location: !0,
                                        sentry: !0
                                    },
                                    o = r.autoBreadcrumbs;
                                "[object Object]" === {}.toString.call(o) ? o = T(i, o) : !1 !== o && (o = i), r.autoBreadcrumbs = o;
                                var s = {
                                        tryCatch: !0
                                    },
                                    l = r.instrument;
                                return "[object Object]" === {}.toString.call(l) ? l = T(s, l) : !1 !== l && (l = s), r.instrument = l, a.collectWindowErrors = !!r.collectWindowErrors, n
                            },
                            install: function() {
                                var e = this;
                                return e.isSetup() && !e.n && (a.report.subscribe((function() {
                                    e.A.apply(e, arguments)
                                })), e.k.captureUnhandledRejections && e.B(), e.C(), e.k.instrument && e.k.instrument.tryCatch && e.D(), e.k.autoBreadcrumbs && e.E(), e.F(), e.n = !0), Error.stackTraceLimit = e.k.stackTraceLimit, this
                            },
                            setDSN: function(e) {
                                var t = this,
                                    n = t.G(e),
                                    r = n.path.lastIndexOf("/"),
                                    i = n.path.substr(1, r);
                                t.H = e, t.h = n.user, t.I = n.pass && n.pass.substr(1), t.i = n.path.substr(r + 1), t.g = t.J(n), t.K = t.g + "/" + i + "api/" + t.i + "/store/", this.y()
                            },
                            context: function(e, t, n) {
                                return V(e) && (n = t || [], t = e, e = {}), this.wrap(e, t).apply(this, n)
                            },
                            wrap: function(e, t, n) {
                                function r() {
                                    var r = [],
                                        o = arguments.length,
                                        a = !e || e && !1 !== e.deep;
                                    for (n && V(n) && n.apply(this, arguments); o--;) r[o] = a ? i.wrap(e, arguments[o]) : arguments[o];
                                    try {
                                        return t.apply(this, r)
                                    } catch (s) {
                                        throw i.L(), i.captureException(s, e), s
                                    }
                                }
                                var i = this;
                                if (y(t) && !V(e)) return e;
                                if (V(e) && (t = e, e = void 0), !V(t)) return t;
                                try {
                                    if (t.M) return t;
                                    if (t.N) return t.N
                                } catch (o) {
                                    return t
                                }
                                for (var a in t) _(t, a) && (r[a] = t[a]);
                                return r.prototype = t.prototype, t.N = r, r.M = !0, r.O = t, r
                            },
                            uninstall: function() {
                                return a.report.uninstall(), this.P(), this.Q(), this.R(), this.S(), Error.stackTraceLimit = this.o, this.n = !1, this
                            },
                            T: function(e) {
                                this.z("debug", "Raven caught unhandled promise rejection:", e), this.captureException(e.reason, {
                                    mechanism: {
                                        type: "onunhandledrejection",
                                        handled: !1
                                    }
                                })
                            },
                            B: function() {
                                return this.T = this.T.bind(this), J.addEventListener && J.addEventListener("unhandledrejection", this.T), this
                            },
                            P: function() {
                                return J.removeEventListener && J.removeEventListener("unhandledrejection", this.T), this
                            },
                            captureException: function(e, t) {
                                if (t = T({
                                        trimHeadFrames: 0
                                    }, t || {}), h(e) && e.error) e = e.error;
                                else {
                                    if (p(e) || d(e)) {
                                        var n = e.name || (p(e) ? "DOMError" : "DOMException"),
                                            r = e.message ? n + ": " + e.message : n;
                                        return this.captureMessage(r, T(t, {
                                            stacktrace: !0,
                                            trimHeadFrames: t.trimHeadFrames + 1
                                        }))
                                    }
                                    if (f(e)) e = e;
                                    else {
                                        if (!g(e)) return this.captureMessage(e, T(t, {
                                            stacktrace: !0,
                                            trimHeadFrames: t.trimHeadFrames + 1
                                        }));
                                        t = this.U(t, e), e = new Error(t.message)
                                    }
                                }
                                this.d = e;
                                try {
                                    var i = a.computeStackTrace(e);
                                    this.V(i, t)
                                } catch (o) {
                                    if (e !== o) throw o
                                }
                                return this
                            },
                            U: function(e, t) {
                                var n = Object.keys(t).sort(),
                                    r = T(e, {
                                        message: "Non-Error exception captured with keys: " + j(n),
                                        fingerprint: [l(n)],
                                        extra: e.extra || {}
                                    });
                                return r.extra.W = C(t), r
                            },
                            captureMessage: function(e, t) {
                                if (!this.k.ignoreErrors.test || !this.k.ignoreErrors.test(e)) {
                                    var n, r = T({
                                        message: e += ""
                                    }, t = t || {});
                                    try {
                                        throw new Error(e)
                                    } catch (i) {
                                        n = i
                                    }
                                    n.name = null;
                                    var o = a.computeStackTrace(n),
                                        s = b(o.stack) && o.stack[1];
                                    s && "Raven.captureException" === s.func && (s = o.stack[2]);
                                    var l = s && s.url || "";
                                    if ((!this.k.ignoreUrls.test || !this.k.ignoreUrls.test(l)) && (!this.k.whitelistUrls.test || this.k.whitelistUrls.test(l))) {
                                        if (this.k.stacktrace || t.stacktrace || "" === r.message) {
                                            r.fingerprint = null == r.fingerprint ? e : r.fingerprint, (t = T({
                                                trimHeadFrames: 0
                                            }, t)).trimHeadFrames += 1;
                                            var c = this.X(o, t);
                                            r.stacktrace = {
                                                frames: c.reverse()
                                            }
                                        }
                                        return r.fingerprint && (r.fingerprint = b(r.fingerprint) ? r.fingerprint : [r.fingerprint]), this.Y(r), this
                                    }
                                }
                            },
                            captureBreadcrumb: function(e) {
                                var t = T({
                                    timestamp: r() / 1e3
                                }, e);
                                if (V(this.k.breadcrumbCallback)) {
                                    var n = this.k.breadcrumbCallback(t);
                                    if (m(n) && !R(n)) t = n;
                                    else if (!1 === n) return this
                                }
                                return this.u.push(t), this.u.length > this.k.maxBreadcrumbs && this.u.shift(), this
                            },
                            addPlugin: function(e) {
                                var t = [].slice.call(arguments, 1);
                                return this.r.push([e, t]), this.n && this.F(), this
                            },
                            setUserContext: function(e) {
                                return this.j.user = e, this
                            },
                            setExtraContext: function(e) {
                                return this.Z("extra", e), this
                            },
                            setTagsContext: function(e) {
                                return this.Z("tags", e), this
                            },
                            clearContext: function() {
                                return this.j = {}, this
                            },
                            getContext: function() {
                                return JSON.parse(s(this.j))
                            },
                            setEnvironment: function(e) {
                                return this.k.environment = e, this
                            },
                            setRelease: function(e) {
                                return this.k.release = e, this
                            },
                            setDataCallback: function(e) {
                                var t = this.k.dataCallback;
                                return this.k.dataCallback = i(t, e), this
                            },
                            setBreadcrumbCallback: function(e) {
                                var t = this.k.breadcrumbCallback;
                                return this.k.breadcrumbCallback = i(t, e), this
                            },
                            setShouldSendCallback: function(e) {
                                var t = this.k.shouldSendCallback;
                                return this.k.shouldSendCallback = i(t, e), this
                            },
                            setTransport: function(e) {
                                return this.k.transport = e, this
                            },
                            lastException: function() {
                                return this.d
                            },
                            lastEventId: function() {
                                return this.f
                            },
                            isSetup: function() {
                                return !(!this.a || !this.g && (this.ravenNotConfiguredError || (this.ravenNotConfiguredError = !0, this.z("error", "Error: Raven has not been configured.")), 1))
                            },
                            afterLoad: function() {
                                var e = J.RavenConfig;
                                e && this.config(e.dsn, e.config).install()
                            },
                            showReportDialog: function(e) {
                                if (z) {
                                    if (!(e = T({
                                            eventId: this.lastEventId(),
                                            dsn: this.H,
                                            user: this.j.user || {}
                                        }, e)).eventId) throw new c("Missing eventId");
                                    if (!e.dsn) throw new c("Missing DSN");
                                    var t = encodeURIComponent,
                                        n = [];
                                    for (var r in e)
                                        if ("user" === r) {
                                            var i = e.user;
                                            i.name && n.push("name=" + t(i.name)), i.email && n.push("email=" + t(i.email))
                                        } else n.push(t(r) + "=" + t(e[r]));
                                    var o = this.J(this.G(e.dsn)),
                                        a = z.createElement("script");
                                    a.async = !0, a.src = o + "/api/embed/error-page/?" + n.join("&"), (z.head || z.body).appendChild(a)
                                }
                            },
                            L: function() {
                                var e = this;
                                this.m += 1, setTimeout((function() {
                                    e.m -= 1
                                }))
                            },
                            $: function(e, t) {
                                var n, r;
                                if (this.b) {
                                    for (r in t = t || {}, e = "raven" + e.substr(0, 1).toUpperCase() + e.substr(1), z.createEvent ? (n = z.createEvent("HTMLEvents")).initEvent(e, !0, !0) : (n = z.createEventObject()).eventType = e, t) _(t, r) && (n[r] = t[r]);
                                    if (z.createEvent) z.dispatchEvent(n);
                                    else try {
                                        z.fireEvent("on" + n.eventType.toLowerCase(), n)
                                    } catch (i) {}
                                }
                            },
                            _: function(e) {
                                var t = this;
                                return function(n) {
                                    if (t.aa = null, t.v !== n) {
                                        var r;
                                        t.v = n;
                                        try {
                                            r = W(n.target)
                                        } catch (i) {
                                            r = "<unknown>"
                                        }
                                        t.captureBreadcrumb({
                                            category: "ui." + e,
                                            message: r
                                        })
                                    }
                                }
                            },
                            ba: function() {
                                var e = this;
                                return function(t) {
                                    var n;
                                    try {
                                        n = t.target
                                    } catch (i) {
                                        return
                                    }
                                    var r = n && n.tagName;
                                    if (r && ("INPUT" === r || "TEXTAREA" === r || n.isContentEditable)) {
                                        var o = e.aa;
                                        o || e._("input")(t), clearTimeout(o), e.aa = setTimeout((function() {
                                            e.aa = null
                                        }), 1e3)
                                    }
                                }
                            },
                            ca: function(e, t) {
                                var n = N(this.w.href),
                                    r = N(t),
                                    i = N(e);
                                this.x = t, n.protocol === r.protocol && n.host === r.host && (t = r.relative), n.protocol === i.protocol && n.host === i.host && (e = i.relative), this.captureBreadcrumb({
                                    category: "navigation",
                                    data: {
                                        to: t,
                                        from: e
                                    }
                                })
                            },
                            C: function() {
                                var e = this;
                                e.da = Function.prototype.toString, Function.prototype.toString = function() {
                                    return "function" == typeof this && this.M ? e.da.apply(this.O, arguments) : e.da.apply(this, arguments)
                                }
                            },
                            Q: function() {
                                this.da && (Function.prototype.toString = this.da)
                            },
                            D: function() {
                                function e(e) {
                                    return function(t, r) {
                                        for (var i = new Array(arguments.length), o = 0; o < i.length; ++o) i[o] = arguments[o];
                                        var a = i[0];
                                        return V(a) && (i[0] = n.wrap({
                                            mechanism: {
                                                type: "instrument",
                                                data: {
                                                    "function": e.name || "<anonymous>"
                                                }
                                            }
                                        }, a)), e.apply ? e.apply(this, i) : e(i[0], i[1])
                                    }
                                }

                                function t(e) {
                                    var t = J[e] && J[e].prototype;
                                    t && t.hasOwnProperty && t.hasOwnProperty("addEventListener") && (P(t, "addEventListener", (function(t) {
                                        return function(r, o, a, s) {
                                            try {
                                                o && o.handleEvent && (o.handleEvent = n.wrap({
                                                    mechanism: {
                                                        type: "instrument",
                                                        data: {
                                                            target: e,
                                                            "function": "handleEvent",
                                                            handler: o && o.name || "<anonymous>"
                                                        }
                                                    }
                                                }, o.handleEvent))
                                            } catch (l) {}
                                            var c, u, h;
                                            return i && i.dom && ("EventTarget" === e || "Node" === e) && (u = n._("click"), h = n.ba(), c = function(e) {
                                                if (e) {
                                                    var t;
                                                    try {
                                                        t = e.type
                                                    } catch (n) {
                                                        return
                                                    }
                                                    return "click" === t ? u(e) : "keypress" === t ? h(e) : void 0
                                                }
                                            }), t.call(this, r, n.wrap({
                                                mechanism: {
                                                    type: "instrument",
                                                    data: {
                                                        target: e,
                                                        "function": "addEventListener",
                                                        handler: o && o.name || "<anonymous>"
                                                    }
                                                }
                                            }, o, c), a, s)
                                        }
                                    }), r), P(t, "removeEventListener", (function(e) {
                                        return function(t, n, r, i) {
                                            try {
                                                n = n && (n.N ? n.N : n)
                                            } catch (o) {}
                                            return e.call(this, t, n, r, i)
                                        }
                                    }), r))
                                }
                                var n = this,
                                    r = n.t,
                                    i = this.k.autoBreadcrumbs;
                                P(J, "setTimeout", e, r), P(J, "setInterval", e, r), J.requestAnimationFrame && P(J, "requestAnimationFrame", (function(e) {
                                    return function(t) {
                                        return e(n.wrap({
                                            mechanism: {
                                                type: "instrument",
                                                data: {
                                                    "function": "requestAnimationFrame",
                                                    handler: e && e.name || "<anonymous>"
                                                }
                                            }
                                        }, t))
                                    }
                                }), r);
                                for (var o = ["EventTarget", "Window", "Node", "ApplicationCache", "AudioTrackList", "ChannelMergerNode", "CryptoOperation", "EventSource", "FileReader", "HTMLUnknownElement", "IDBDatabase", "IDBRequest", "IDBTransaction", "KeyOperation", "MediaController", "MessagePort", "ModalWindow", "Notification", "SVGElementInstance", "Screen", "TextTrack", "TextTrackCue", "TextTrackList", "WebSocket", "WebSocketWorker", "Worker", "XMLHttpRequest", "XMLHttpRequestEventTarget", "XMLHttpRequestUpload"], a = 0; a < o.length; a++) t(o[a])
                            },
                            E: function() {
                                function e(e, n) {
                                    e in n && V(n[e]) && P(n, e, (function(n) {
                                        return t.wrap({
                                            mechanism: {
                                                type: "instrument",
                                                data: {
                                                    "function": e,
                                                    handler: n && n.name || "<anonymous>"
                                                }
                                            }
                                        }, n)
                                    }))
                                }
                                var t = this,
                                    n = this.k.autoBreadcrumbs,
                                    r = t.t;
                                if (n.xhr && "XMLHttpRequest" in J) {
                                    var i = J.XMLHttpRequest && J.XMLHttpRequest.prototype;
                                    P(i, "open", (function(e) {
                                        return function(n, r) {
                                            return v(r) && -1 === r.indexOf(t.h) && (this.ea = {
                                                method: n,
                                                url: r,
                                                status_code: null
                                            }), e.apply(this, arguments)
                                        }
                                    }), r), P(i, "send", (function(n) {
                                        return function() {
                                            function r() {
                                                if (i.ea && 4 === i.readyState) {
                                                    try {
                                                        i.ea.status_code = i.status
                                                    } catch (e) {}
                                                    t.captureBreadcrumb({
                                                        type: "http",
                                                        category: "xhr",
                                                        data: i.ea
                                                    })
                                                }
                                            }
                                            for (var i = this, o = ["onload", "onerror", "onprogress"], a = 0; a < o.length; a++) e(o[a], i);
                                            return "onreadystatechange" in i && V(i.onreadystatechange) ? P(i, "onreadystatechange", (function(e) {
                                                return t.wrap({
                                                    mechanism: {
                                                        type: "instrument",
                                                        data: {
                                                            "function": "onreadystatechange",
                                                            handler: e && e.name || "<anonymous>"
                                                        }
                                                    }
                                                }, e, r)
                                            })) : i.onreadystatechange = r, n.apply(this, arguments)
                                        }
                                    }), r)
                                }
                                n.xhr && Z() && P(J, "fetch", (function(e) {
                                    return function() {
                                        for (var n = new Array(arguments.length), r = 0; r < n.length; ++r) n[r] = arguments[r];
                                        var i, o = n[0],
                                            a = "GET";
                                        if ("string" == typeof o ? i = o : "Request" in J && o instanceof J.Request ? (i = o.url, o.method && (a = o.method)) : i = "" + o, -1 !== i.indexOf(t.h)) return e.apply(this, n);
                                        n[1] && n[1].method && (a = n[1].method);
                                        var s = {
                                            method: a,
                                            url: i,
                                            status_code: null
                                        };
                                        return e.apply(this, n).then((function(e) {
                                            return s.status_code = e.status, t.captureBreadcrumb({
                                                type: "http",
                                                category: "fetch",
                                                data: s
                                            }), e
                                        }))["catch"]((function(e) {
                                            throw t.captureBreadcrumb({
                                                type: "http",
                                                category: "fetch",
                                                data: s,
                                                level: "error"
                                            }), e
                                        }))
                                    }
                                }), r), n.dom && this.b && (z.addEventListener ? (z.addEventListener("click", t._("click"), !1), z.addEventListener("keypress", t.ba(), !1)) : z.attachEvent && (z.attachEvent("onclick", t._("click")), z.attachEvent("onkeypress", t.ba())));
                                var o = J.chrome,
                                    a = !(o && o.app && o.app.runtime) && J.history && J.history.pushState && J.history.replaceState;
                                if (n.location && a) {
                                    var s = J.onpopstate;
                                    J.onpopstate = function() {
                                        var e = t.w.href;
                                        if (t.ca(t.x, e), s) return s.apply(this, arguments)
                                    };
                                    var l = function(e) {
                                        return function() {
                                            var n = arguments.length > 2 ? arguments[2] : void 0;
                                            return n && t.ca(t.x, n + ""), e.apply(this, arguments)
                                        }
                                    };
                                    P(J.history, "pushState", l, r), P(J.history, "replaceState", l, r)
                                }
                                if (n.console && "console" in J && console.log) {
                                    var c = function(e, n) {
                                        t.captureBreadcrumb({
                                            message: e,
                                            level: n.level,
                                            category: "console"
                                        })
                                    };
                                    w(["debug", "info", "warn", "error", "log"], (function(e, t) {
                                        D(console, t, c)
                                    }))
                                }
                            },
                            R: function() {
                                for (var e; this.t.length;) {
                                    var t = (e = this.t.shift())[0],
                                        n = e[1],
                                        r = e[2];
                                    t[n] = r
                                }
                            },
                            S: function() {
                                for (var e in this.q) this.p[e] = this.q[e]
                            },
                            F: function() {
                                var e = this;
                                w(this.r, (function(t, n) {
                                    var r = n[0],
                                        i = n[1];
                                    r.apply(e, [e].concat(i))
                                }))
                            },
                            G: function(e) {
                                var t = G.exec(e),
                                    n = {},
                                    r = 7;
                                try {
                                    for (; r--;) n[A[r]] = t[r] || ""
                                } catch (i) {
                                    throw new c("Invalid DSN: " + e)
                                }
                                if (n.pass && !this.k.allowSecretKey) throw new c("Do not specify your secret key in the DSN. See: http://bit.ly/raven-secret-key");
                                return n
                            },
                            J: function(e) {
                                var t = "//" + e.host + (e.port ? ":" + e.port : "");
                                return e.protocol && (t = e.protocol + ":" + t), t
                            },
                            A: function(e, t) {
                                (t = t || {}).mechanism = t.mechanism || {
                                    type: "onerror",
                                    handled: !1
                                }, this.m || this.V(e, t)
                            },
                            V: function(e, t) {
                                var n = this.X(e, t);
                                this.$("handle", {
                                    stackInfo: e,
                                    options: t
                                }), this.fa(e.name, e.message, e.url, e.lineno, n, t)
                            },
                            X: function(e, t) {
                                var n = this,
                                    r = [];
                                if (e.stack && e.stack.length && (w(e.stack, (function(t, i) {
                                        var o = n.ga(i, e.url);
                                        o && r.push(o)
                                    })), t && t.trimHeadFrames))
                                    for (var i = 0; i < t.trimHeadFrames && i < r.length; i++) r[i].in_app = !1;
                                return r = r.slice(0, this.k.stackTraceLimit)
                            },
                            ga: function(e, t) {
                                var n = {
                                    filename: e.url,
                                    lineno: e.line,
                                    colno: e.column,
                                    "function": e.func || "?"
                                };
                                return e.url || (n.filename = t), n.in_app = !(this.k.includePaths.test && !this.k.includePaths.test(n.filename) || /(Raven|TraceKit)\./.test(n["function"]) || /raven\.(min\.)?js$/.test(n.filename)), n
                            },
                            fa: function(e, t, n, r, i, o) {
                                var a, s = (e ? e + ": " : "") + (t || "");
                                if ((!this.k.ignoreErrors.test || !this.k.ignoreErrors.test(t) && !this.k.ignoreErrors.test(s)) && (i && i.length ? (n = i[0].filename || n, i.reverse(), a = {
                                        frames: i
                                    }) : n && (a = {
                                        frames: [{
                                            filename: n,
                                            lineno: r,
                                            in_app: !0
                                        }]
                                    }), (!this.k.ignoreUrls.test || !this.k.ignoreUrls.test(n)) && (!this.k.whitelistUrls.test || this.k.whitelistUrls.test(n)))) {
                                    var l = T({
                                            exception: {
                                                values: [{
                                                    type: e,
                                                    value: t,
                                                    stacktrace: a
                                                }]
                                            },
                                            transaction: n
                                        }, o),
                                        c = l.exception.values[0];
                                    null == c.type && "" === c.value && (c.value = "Unrecoverable error caught"), !l.exception.mechanism && l.mechanism && (l.exception.mechanism = l.mechanism, delete l.mechanism), l.exception.mechanism = T({
                                        type: "generic",
                                        handled: !0
                                    }, l.exception.mechanism || {}), this.Y(l)
                                }
                            },
                            ha: function(e) {
                                var t = this.k.maxMessageLength;
                                if (e.message && (e.message = S(e.message, t)), e.exception) {
                                    var n = e.exception.values[0];
                                    n.value = S(n.value, t)
                                }
                                var r = e.request;
                                return r && (r.url && (r.url = S(r.url, this.k.maxUrlLength)), r.Referer && (r.Referer = S(r.Referer, this.k.maxUrlLength))), e.breadcrumbs && e.breadcrumbs.values && this.ia(e.breadcrumbs), e
                            },
                            ia: function(e) {
                                for (var t, n, r, i = ["to", "from", "url"], o = 0; o < e.values.length; ++o)
                                    if ((n = e.values[o]).hasOwnProperty("data") && m(n.data) && !E(n.data)) {
                                        r = T({}, n.data);
                                        for (var a = 0; a < i.length; ++a) t = i[a], r.hasOwnProperty(t) && r[t] && (r[t] = S(r[t], this.k.maxUrlLength));
                                        e.values[o].data = r
                                    }
                            },
                            ja: function() {
                                if (this.c || this.b) {
                                    var e = {};
                                    return this.c && X.userAgent && (e.headers = {
                                        "User-Agent": X.userAgent
                                    }), J.location && J.location.href && (e.url = J.location.href), this.b && z.referrer && (e.headers || (e.headers = {}), e.headers.Referer = z.referrer), e
                                }
                            },
                            y: function() {
                                this.ka = 0, this.la = null
                            },
                            ma: function() {
                                return this.ka && r() - this.la < this.ka
                            },
                            na: function(e) {
                                var t = this.e;
                                return !(!t || e.message !== t.message || e.transaction !== t.transaction) && (e.stacktrace || t.stacktrace ? F(e.stacktrace, t.stacktrace) : e.exception || t.exception ? M(e.exception, t.exception) : !e.fingerprint && !t.fingerprint || Boolean(e.fingerprint && t.fingerprint) && JSON.stringify(e.fingerprint) === JSON.stringify(t.fingerprint))
                            },
                            oa: function(e) {
                                if (!this.ma()) {
                                    var t = e.status;
                                    if (400 === t || 401 === t || 429 === t) {
                                        var n;
                                        try {
                                            n = Z() ? e.headers.get("Retry-After") : e.getResponseHeader("Retry-After"), n = 1e3 * parseInt(n, 10)
                                        } catch (i) {}
                                        this.ka = n || (2 * this.ka || 1e3), this.la = r()
                                    }
                                }
                            },
                            Y: function(e) {
                                var t = this.k,
                                    n = {
                                        project: this.i,
                                        logger: t.logger,
                                        platform: "javascript"
                                    },
                                    i = this.ja();
                                if (i && (n.request = i), e.trimHeadFrames && delete e.trimHeadFrames, (e = T(n, e)).tags = T(T({}, this.j.tags), e.tags), e.extra = T(T({}, this.j.extra), e.extra), e.extra["session:duration"] = r() - this.s, this.u && this.u.length > 0 && (e.breadcrumbs = {
                                        values: [].slice.call(this.u, 0)
                                    }), this.j.user && (e.user = this.j.user), t.environment && (e.environment = t.environment), t.release && (e.release = t.release), t.serverName && (e.server_name = t.serverName), e = this.pa(e), Object.keys(e).forEach((function(t) {
                                        (null == e[t] || "" === e[t] || R(e[t])) && delete e[t]
                                    })), V(t.dataCallback) && (e = t.dataCallback(e) || e), e && !R(e) && (!V(t.shouldSendCallback) || t.shouldSendCallback(e))) return this.ma() ? void this.z("warn", "Raven dropped error due to backoff: ", e) : void("number" == typeof t.sampleRate ? Math.random() < t.sampleRate && this.qa(e) : this.qa(e))
                            },
                            pa: function(e) {
                                return B(e, this.k.sanitizeKeys)
                            },
                            ra: function() {
                                return x()
                            },
                            qa: function(e, t) {
                                var n = this,
                                    r = this.k;
                                if (this.isSetup()) {
                                    if (e = this.ha(e), !this.k.allowDuplicates && this.na(e)) return void this.z("warn", "Raven dropped repeat event: ", e);
                                    this.f = e.event_id || (e.event_id = this.ra()), this.e = e, this.z("debug", "Raven about to send:", e);
                                    var i = {
                                        sentry_version: "7",
                                        sentry_client: "raven-js/" + this.VERSION,
                                        sentry_key: this.h
                                    };
                                    this.I && (i.sentry_secret = this.I);
                                    var o = e.exception && e.exception.values[0];
                                    this.k.autoBreadcrumbs && this.k.autoBreadcrumbs.sentry && this.captureBreadcrumb({
                                        category: "sentry",
                                        message: o ? (o.type ? o.type + ": " : "") + o.value : e.message,
                                        event_id: e.event_id,
                                        level: e.level || "error"
                                    });
                                    var a = this.K;
                                    (r.transport || this._makeRequest).call(this, {
                                        url: a,
                                        auth: i,
                                        data: e,
                                        options: r,
                                        onSuccess: function() {
                                            n.y(), n.$("success", {
                                                data: e,
                                                src: a
                                            }), t && t()
                                        },
                                        onError: function(r) {
                                            n.z("error", "Raven transport failed to send: ", r), r.request && n.oa(r.request), n.$("failure", {
                                                data: e,
                                                src: a
                                            }), r = r || new Error("Raven send failed (no additional details provided)"), t && t(r)
                                        }
                                    })
                                }
                            },
                            _makeRequest: function(e) {
                                var t = e.url + "?" + U(e.auth),
                                    n = null,
                                    r = {};
                                if (e.options.headers && (n = this.sa(e.options.headers)), e.options.fetchParameters && (r = this.sa(e.options.fetchParameters)), Z()) {
                                    r.body = s(e.data);
                                    var i = T({}, this.l),
                                        o = T(i, r);
                                    return n && (o.headers = n), J.fetch(t, o).then((function(t) {
                                        if (t.ok) e.onSuccess && e.onSuccess();
                                        else {
                                            var n = new Error("Sentry error code: " + t.status);
                                            n.request = t, e.onError && e.onError(n)
                                        }
                                    }))["catch"]((function() {
                                        e.onError && e.onError(new Error("Sentry error code: network unavailable"))
                                    }))
                                }
                                var a = J.XMLHttpRequest && new J.XMLHttpRequest;
                                a && (("withCredentials" in a || "undefined" != typeof XDomainRequest) && ("withCredentials" in a ? a.onreadystatechange = function() {
                                    if (4 === a.readyState)
                                        if (200 === a.status) e.onSuccess && e.onSuccess();
                                        else if (e.onError) {
                                        var t = new Error("Sentry error code: " + a.status);
                                        t.request = a, e.onError(t)
                                    }
                                } : (a = new XDomainRequest, t = t.replace(/^https?:/, ""), e.onSuccess && (a.onload = e.onSuccess), e.onError && (a.onerror = function() {
                                    var t = new Error("Sentry error code: XDomainRequest");
                                    t.request = a, e.onError(t)
                                })), a.open("POST", t), n && w(n, (function(e, t) {
                                    a.setRequestHeader(e, t)
                                })), a.send(s(e.data))))
                            },
                            sa: function(e) {
                                var t = {};
                                for (var n in e)
                                    if (e.hasOwnProperty(n)) {
                                        var r = e[n];
                                        t[n] = "function" == typeof r ? r() : r
                                    }
                                return t
                            },
                            z: function(e) {
                                this.q[e] && (this.debug || this.k.debug) && Function.prototype.apply.call(this.q[e], this.p, [].slice.call(arguments, 1))
                            },
                            Z: function(e, t) {
                                y(t) ? delete this.j[e] : this.j[e] = T(this.j[e] || {}, t)
                            }
                        }, o.prototype.setUser = o.prototype.setUserContext, o.prototype.setReleaseContext = o.prototype.setRelease, t.exports = o
                    }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
                }, {
                    1: 1,
                    2: 2,
                    5: 5,
                    6: 6,
                    7: 7,
                    8: 8
                }],
                4: [function(e, t, n) {
                    (function(n) {
                        var r = e(3),
                            i = "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : {},
                            o = i.Raven,
                            a = new r;
                        a.noConflict = function() {
                            return i.Raven = o, a
                        }, a.afterLoad(), t.exports = a, t.exports.Client = r
                    }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
                }, {
                    3: 3
                }],
                5: [function(e, t, n) {
                    (function(n) {
                        function r(e) {
                            switch (Object.prototype.toString.call(e)) {
                                case "[object Error]":
                                case "[object Exception]":
                                case "[object DOMException]":
                                    return !0;
                                default:
                                    return e instanceof Error
                            }
                        }

                        function i(e) {
                            return "[object DOMError]" === Object.prototype.toString.call(e)
                        }

                        function o(e) {
                            return void 0 === e
                        }

                        function a(e) {
                            return "[object Object]" === Object.prototype.toString.call(e)
                        }

                        function s(e) {
                            return "[object String]" === Object.prototype.toString.call(e)
                        }

                        function l(e) {
                            return "[object Array]" === Object.prototype.toString.call(e)
                        }

                        function c() {
                            if (!("fetch" in R)) return !1;
                            try {
                                return new Headers, new Request(""), new Response, !0
                            } catch (e) {
                                return !1
                            }
                        }

                        function u(e, t) {
                            var n, r;
                            if (o(e.length))
                                for (n in e) p(e, n) && t.call(null, n, e[n]);
                            else if (r = e.length)
                                for (n = 0; n < r; n++) t.call(null, n, e[n])
                        }

                        function h(e, t) {
                            if ("number" != typeof t) throw new Error("2nd argument to `truncate` function should be a number");
                            return "string" != typeof e || 0 === t || e.length <= t ? e : e.substr(0, t) + "…"
                        }

                        function p(e, t) {
                            return Object.prototype.hasOwnProperty.call(e, t)
                        }

                        function d(e) {
                            for (var t, n = [], r = 0, i = e.length; r < i; r++) s(t = e[r]) ? n.push(t.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1")) : t && t.source && n.push(t.source);
                            return new RegExp(n.join("|"), "i")
                        }

                        function f(e) {
                            var t, n, r, i, o, a = [];
                            if (!e || !e.tagName) return "";
                            if (a.push(e.tagName.toLowerCase()), e.id && a.push("#" + e.id), (t = e.className) && s(t))
                                for (n = t.split(/\s+/), o = 0; o < n.length; o++) a.push("." + n[o]);
                            var l = ["type", "name", "title", "alt"];
                            for (o = 0; o < l.length; o++) r = l[o], (i = e.getAttribute(r)) && a.push("[" + r + '="' + i + '"]');
                            return a.join("")
                        }

                        function m(e, t) {
                            return !!(!!e ^ !!t)
                        }

                        function g(e, t) {
                            if (m(e, t)) return !1;
                            var n = e.frames,
                                r = t.frames;
                            if (void 0 === n || void 0 === r) return !1;
                            if (n.length !== r.length) return !1;
                            for (var i, o, a = 0; a < n.length; a++)
                                if (i = n[a], o = r[a], i.filename !== o.filename || i.lineno !== o.lineno || i.colno !== o.colno || i["function"] !== o["function"]) return !1;
                            return !0
                        }

                        function y(e) {
                            return function(e) {
                                return ~-encodeURI(e).split(/%..|./).length
                            }(JSON.stringify(e))
                        }

                        function V(e) {
                            if ("string" == typeof e) {
                                return h(e, 40)
                            }
                            if ("number" == typeof e || "boolean" == typeof e || void 0 === e) return e;
                            var t = Object.prototype.toString.call(e);
                            return "[object Object]" === t ? "[Object]" : "[object Array]" === t ? "[Array]" : "[object Function]" === t ? e.name ? "[Function: " + e.name + "]" : "[Function]" : e
                        }

                        function v(e, t) {
                            return 0 === t ? V(e) : a(e) ? Object.keys(e).reduce((function(n, r) {
                                return n[r] = v(e[r], t - 1), n
                            }), {}) : Array.isArray(e) ? e.map((function(e) {
                                return v(e, t - 1)
                            })) : V(e)
                        }
                        var b = e(7),
                            R = "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : {},
                            w = 3,
                            T = 51200,
                            S = 40;
                        t.exports = {
                            isObject: function(e) {
                                return "object" == typeof e && null !== e
                            },
                            isError: r,
                            isErrorEvent: function(e) {
                                return "[object ErrorEvent]" === Object.prototype.toString.call(e)
                            },
                            isDOMError: i,
                            isDOMException: function(e) {
                                return "[object DOMException]" === Object.prototype.toString.call(e)
                            },
                            isUndefined: o,
                            isFunction: function(e) {
                                return "function" == typeof e
                            },
                            isPlainObject: a,
                            isString: s,
                            isArray: l,
                            isEmptyObject: function(e) {
                                if (!a(e)) return !1;
                                for (var t in e)
                                    if (e.hasOwnProperty(t)) return !1;
                                return !0
                            },
                            supportsErrorEvent: function() {
                                try {
                                    return new ErrorEvent(""), !0
                                } catch (e) {
                                    return !1
                                }
                            },
                            supportsDOMError: function() {
                                try {
                                    return new DOMError(""), !0
                                } catch (e) {
                                    return !1
                                }
                            },
                            supportsDOMException: function() {
                                try {
                                    return new DOMException(""), !0
                                } catch (e) {
                                    return !1
                                }
                            },
                            supportsFetch: c,
                            supportsReferrerPolicy: function() {
                                if (!c()) return !1;
                                try {
                                    return new Request("pickleRick", {
                                        referrerPolicy: "origin"
                                    }), !0
                                } catch (e) {
                                    return !1
                                }
                            },
                            supportsPromiseRejectionEvent: function() {
                                return "function" == typeof PromiseRejectionEvent
                            },
                            wrappedCallback: function(e) {
                                return function(t, n) {
                                    var r = e(t) || t;
                                    return n && n(r) || r
                                }
                            },
                            each: u,
                            objectMerge: function(e, t) {
                                return t ? (u(t, (function(t, n) {
                                    e[t] = n
                                })), e) : e
                            },
                            truncate: h,
                            objectFrozen: function(e) {
                                return !!Object.isFrozen && Object.isFrozen(e)
                            },
                            hasKey: p,
                            joinRegExp: d,
                            urlencode: function(e) {
                                var t = [];
                                return u(e, (function(e, n) {
                                    t.push(encodeURIComponent(e) + "=" + encodeURIComponent(n))
                                })), t.join("&")
                            },
                            uuid4: function() {
                                var e = R.crypto || R.msCrypto;
                                if (!o(e) && e.getRandomValues) {
                                    var t = new Uint16Array(8);
                                    e.getRandomValues(t), t[3] = 4095 & t[3] | 16384, t[4] = 16383 & t[4] | 32768;
                                    var n = function(e) {
                                        for (var t = e.toString(16); t.length < 4;) t = "0" + t;
                                        return t
                                    };
                                    return n(t[0]) + n(t[1]) + n(t[2]) + n(t[3]) + n(t[4]) + n(t[5]) + n(t[6]) + n(t[7])
                                }
                                return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                                    var t = 16 * Math.random() | 0;
                                    return ("x" === e ? t : 3 & t | 8).toString(16)
                                }))
                            },
                            htmlTreeAsString: function(e) {
                                for (var t, n = [], r = 0, i = 0, o = " > ".length; e && r++ < 5 && !("html" === (t = f(e)) || r > 1 && i + n.length * o + t.length >= 80);) n.push(t), i += t.length, e = e.parentNode;
                                return n.reverse().join(" > ")
                            },
                            htmlElementAsString: f,
                            isSameException: function(e, t) {
                                return !m(e, t) && (e = e.values[0], t = t.values[0], e.type === t.type && e.value === t.value && ! function(e, t) {
                                    return o(e) && o(t)
                                }(e.stacktrace, t.stacktrace) && g(e.stacktrace, t.stacktrace))
                            },
                            isSameStacktrace: g,
                            parseUrl: function(e) {
                                if ("string" != typeof e) return {};
                                var t = e.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/),
                                    n = t[6] || "",
                                    r = t[8] || "";
                                return {
                                    protocol: t[2],
                                    host: t[4],
                                    path: t[5],
                                    relative: t[5] + n + r
                                }
                            },
                            fill: function(e, t, n, r) {
                                if (null != e) {
                                    var i = e[t];
                                    e[t] = n(i), e[t].M = !0, e[t].O = i, r && r.push([e, t, i])
                                }
                            },
                            safeJoin: function(e, t) {
                                if (!l(e)) return "";
                                for (var n = [], i = 0; i < e.length; i++) try {
                                    n.push(String(e[i]))
                                } catch (r) {
                                    n.push("[value cannot be serialized]")
                                }
                                return n.join(t)
                            },
                            serializeException: function E(e, t, n) {
                                if (!a(e)) return e;
                                n = "number" != typeof(t = "number" != typeof t ? w : t) ? T : n;
                                var r = v(e, t);
                                return y(b(r)) > n ? E(e, t - 1) : r
                            },
                            serializeKeysForMessage: function(e, t) {
                                if ("number" == typeof e || "string" == typeof e) return e.toString();
                                if (!Array.isArray(e)) return "";
                                if (0 === (e = e.filter((function(e) {
                                        return "string" == typeof e
                                    }))).length) return "[object has no keys]";
                                if (t = "number" != typeof t ? S : t, e[0].length >= t) return e[0];
                                for (var n = e.length; n > 0; n--) {
                                    var r = e.slice(0, n).join(", ");
                                    if (!(r.length > t)) return n === e.length ? r : r + "…"
                                }
                                return ""
                            },
                            sanitize: function(e, t) {
                                if (!l(t) || l(t) && 0 === t.length) return e;
                                var n, r = d(t),
                                    o = "********";
                                try {
                                    n = JSON.parse(b(e))
                                } catch (i) {
                                    return e
                                }
                                return function s(e) {
                                    return l(e) ? e.map((function(e) {
                                        return s(e)
                                    })) : a(e) ? Object.keys(e).reduce((function(t, n) {
                                        return t[n] = r.test(n) ? o : s(e[n]), t
                                    }), {}) : e
                                }(n)
                            }
                        }
                    }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
                }, {
                    7: 7
                }],
                6: [function(e, t, n) {
                    (function(n) {
                        function r() {
                            return "undefined" == typeof document || null == document.location ? "" : document.location.href
                        }
                        var i = e(5),
                            o = {
                                collectWindowErrors: !0,
                                debug: !1
                            },
                            a = "undefined" != typeof window ? window : void 0 !== n ? n : "undefined" != typeof self ? self : {},
                            s = [].slice,
                            l = "?",
                            c = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/;
                        o.report = function() {
                            function e(t, n) {
                                var r = null;
                                if (!n || o.collectWindowErrors) {
                                    for (var i in d)
                                        if (d.hasOwnProperty(i)) try {
                                            d[i].apply(null, [t].concat(s.call(arguments, 2)))
                                        } catch (e) {
                                            r = e
                                        }
                                    if (r) throw r
                                }
                            }

                            function t(t, a, s, u, p) {
                                var d = i.isErrorEvent(p) ? p.error : p,
                                    f = i.isErrorEvent(t) ? t.message : t;
                                if (g) o.computeStackTrace.augmentStackTraceWithInitialElement(g, a, s, f), n();
                                else if (d && i.isError(d)) e(o.computeStackTrace(d), !0);
                                else {
                                    var m, y = {
                                            url: a,
                                            line: s,
                                            column: u
                                        },
                                        V = void 0;
                                    if ("[object String]" === {}.toString.call(f))(m = f.match(c)) && (V = m[1], f = m[2]);
                                    y.func = l, e({
                                        name: V,
                                        message: f,
                                        url: r(),
                                        stack: [y]
                                    }, !0)
                                }
                                return !!h && h.apply(this, arguments)
                            }

                            function n() {
                                var t = g,
                                    n = f;
                                f = null, g = null, m = null, e.apply(null, [t, !1].concat(n))
                            }

                            function u(e, t) {
                                var r = s.call(arguments, 1);
                                if (g) {
                                    if (m === e) return;
                                    n()
                                }
                                var i = o.computeStackTrace(e);
                                if (g = i, m = e, f = r, setTimeout((function() {
                                        m === e && n()
                                    }), i.incomplete ? 2e3 : 0), !1 !== t) throw e
                            }
                            var h, p, d = [],
                                f = null,
                                m = null,
                                g = null;
                            return u.subscribe = function(e) {
                                p || (h = a.onerror, a.onerror = t, p = !0), d.push(e)
                            }, u.unsubscribe = function(e) {
                                for (var t = d.length - 1; t >= 0; --t) d[t] === e && d.splice(t, 1)
                            }, u.uninstall = function() {
                                p && (a.onerror = h, p = !1, h = void 0), d = []
                            }, u
                        }(), o.computeStackTrace = function() {
                            function e(e) {
                                if ("undefined" != typeof e.stack && e.stack) {
                                    for (var t, n, i, o = /^\s*at (?:(.*?) ?\()?((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|[a-z]:|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, a = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx(?:-web)|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i, s = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|moz-extension).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js))(?::(\d+))?(?::(\d+))?\s*$/i, c = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, u = /\((\S*)(?::(\d+))(?::(\d+))\)/, h = e.stack.split("\n"), p = [], d = (/^(.*) is undefined$/.exec(e.message), 0), f = h.length; d < f; ++d) {
                                        if (n = o.exec(h[d])) {
                                            var m = n[2] && 0 === n[2].indexOf("native");
                                            n[2] && 0 === n[2].indexOf("eval") && (t = u.exec(n[2])) && (n[2] = t[1], n[3] = t[2], n[4] = t[3]), i = {
                                                url: m ? null : n[2],
                                                func: n[1] || l,
                                                args: m ? [n[2]] : [],
                                                line: n[3] ? +n[3] : null,
                                                column: n[4] ? +n[4] : null
                                            }
                                        } else if (n = a.exec(h[d])) i = {
                                            url: n[2],
                                            func: n[1] || l,
                                            args: [],
                                            line: +n[3],
                                            column: n[4] ? +n[4] : null
                                        };
                                        else {
                                            if (!(n = s.exec(h[d]))) continue;
                                            n[3] && n[3].indexOf(" > eval") > -1 && (t = c.exec(n[3])) ? (n[3] = t[1], n[4] = t[2], n[5] = null) : 0 !== d || n[5] || "undefined" == typeof e.columnNumber || (p[0].column = e.columnNumber + 1), i = {
                                                url: n[3],
                                                func: n[1] || l,
                                                args: n[2] ? n[2].split(",") : [],
                                                line: n[4] ? +n[4] : null,
                                                column: n[5] ? +n[5] : null
                                            }
                                        }
                                        if (!i.func && i.line && (i.func = l), i.url && "blob:" === i.url.substr(0, 5)) {
                                            var g = new XMLHttpRequest;
                                            if (g.open("GET", i.url, !1), g.send(null), 200 === g.status) {
                                                var y = g.responseText || "",
                                                    V = (y = y.slice(-300)).match(/\/\/# sourceMappingURL=(.*)$/);
                                                if (V) {
                                                    var v = V[1];
                                                    "~" === v.charAt(0) && (v = ("undefined" == typeof document || null == document.location ? "" : document.location.origin ? document.location.origin : document.location.protocol + "//" + document.location.hostname + (document.location.port ? ":" + document.location.port : "")) + v.slice(1)), i.url = v.slice(0, -4)
                                                }
                                            }
                                        }
                                        p.push(i)
                                    }
                                    return p.length ? {
                                        name: e.name,
                                        message: e.message,
                                        url: r(),
                                        stack: p
                                    } : null
                                }
                            }

                            function t(e, t, n, r) {
                                var i = {
                                    url: t,
                                    line: n
                                };
                                if (i.url && i.line) {
                                    if (e.incomplete = !1, i.func || (i.func = l), e.stack.length > 0 && e.stack[0].url === i.url) {
                                        if (e.stack[0].line === i.line) return !1;
                                        if (!e.stack[0].line && e.stack[0].func === i.func) return e.stack[0].line = i.line, !1
                                    }
                                    return e.stack.unshift(i), e.partial = !0, !0
                                }
                                return e.incomplete = !0, !1
                            }

                            function n(e, a) {
                                for (var s, c, u = /function\s+([_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)?\s*\(/i, h = [], p = {}, d = !1, f = n.caller; f && !d; f = f.caller)
                                    if (f !== i && f !== o.report) {
                                        if (c = {
                                                url: null,
                                                func: l,
                                                line: null,
                                                column: null
                                            }, f.name ? c.func = f.name : (s = u.exec(f.toString())) && (c.func = s[1]), "undefined" == typeof c.func) try {
                                            c.func = s.input.substring(0, s.input.indexOf("{"))
                                        } catch (g) {}
                                        p["" + f] ? d = !0 : p["" + f] = !0, h.push(c)
                                    }
                                a && h.splice(0, a);
                                var m = {
                                    name: e.name,
                                    message: e.message,
                                    url: r(),
                                    stack: h
                                };
                                return t(m, e.sourceURL || e.fileName, e.line || e.lineNumber, e.message || e.description), m
                            }

                            function i(t, i) {
                                var s = null;
                                i = null == i ? 0 : +i;
                                try {
                                    if (s = e(t)) return s
                                } catch (a) {
                                    if (o.debug) throw a
                                }
                                try {
                                    if (s = n(t, i + 1)) return s
                                } catch (a) {
                                    if (o.debug) throw a
                                }
                                return {
                                    name: t.name,
                                    message: t.message,
                                    url: r()
                                }
                            }
                            return i.augmentStackTraceWithInitialElement = t, i.computeStackTraceFromStackProp = e, i
                        }(), t.exports = o
                    }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
                }, {
                    5: 5
                }],
                7: [function(e, t, n) {
                    function r(e, t) {
                        for (var n = 0; n < e.length; ++n)
                            if (e[n] === t) return n;
                        return -1
                    }

                    function i(e, t) {
                        var n = [],
                            i = [];
                        return null == t && (t = function(e, t) {
                                return n[0] === t ? "[Circular ~]" : "[Circular ~." + i.slice(0, r(n, t)).join(".") + "]"
                            }),
                            function(o, a) {
                                if (n.length > 0) {
                                    var s = r(n, this);
                                    ~s ? n.splice(s + 1) : n.push(this), ~s ? i.splice(s, 1 / 0, o) : i.push(o), ~r(n, a) && (a = t.call(this, o, a))
                                } else n.push(a);
                                return null == e ? a instanceof Error ? function(e) {
                                    var t = {
                                        stack: e.stack,
                                        message: e.message,
                                        name: e.name
                                    };
                                    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
                                    return t
                                }(a) : a : e.call(this, o, a)
                            }
                    }
                    n = t.exports = function(e, t, n, r) {
                        return JSON.stringify(e, i(t, r), n)
                    }, n.getSerialize = i
                }, {}],
                8: [function(e, t, n) {
                    function r(e, t) {
                        var n = (65535 & e) + (65535 & t);
                        return (e >> 16) + (t >> 16) + (n >> 16) << 16 | 65535 & n
                    }

                    function i(e, t, n, i, o, a) {
                        return r(function(e, t) {
                            return e << t | e >>> 32 - t
                        }(r(r(t, e), r(i, a)), o), n)
                    }

                    function o(e, t, n, r, o, a, s) {
                        return i(t & n | ~t & r, e, t, o, a, s)
                    }

                    function a(e, t, n, r, o, a, s) {
                        return i(t & r | n & ~r, e, t, o, a, s)
                    }

                    function s(e, t, n, r, o, a, s) {
                        return i(t ^ n ^ r, e, t, o, a, s)
                    }

                    function l(e, t, n, r, o, a, s) {
                        return i(n ^ (t | ~r), e, t, o, a, s)
                    }

                    function c(e, t) {
                        e[t >> 5] |= 128 << t % 32, e[14 + (t + 64 >>> 9 << 4)] = t;
                        var n, i, c, u, h, p = 1732584193,
                            d = -271733879,
                            f = -1732584194,
                            m = 271733878;
                        for (n = 0; n < e.length; n += 16) i = p, c = d, u = f, h = m, p = o(p, d, f, m, e[n], 7, -680876936), m = o(m, p, d, f, e[n + 1], 12, -389564586), f = o(f, m, p, d, e[n + 2], 17, 606105819), d = o(d, f, m, p, e[n + 3], 22, -1044525330), p = o(p, d, f, m, e[n + 4], 7, -176418897), m = o(m, p, d, f, e[n + 5], 12, 1200080426), f = o(f, m, p, d, e[n + 6], 17, -1473231341), d = o(d, f, m, p, e[n + 7], 22, -45705983), p = o(p, d, f, m, e[n + 8], 7, 1770035416), m = o(m, p, d, f, e[n + 9], 12, -1958414417), f = o(f, m, p, d, e[n + 10], 17, -42063), d = o(d, f, m, p, e[n + 11], 22, -1990404162), p = o(p, d, f, m, e[n + 12], 7, 1804603682), m = o(m, p, d, f, e[n + 13], 12, -40341101), f = o(f, m, p, d, e[n + 14], 17, -1502002290), p = a(p, d = o(d, f, m, p, e[n + 15], 22, 1236535329), f, m, e[n + 1], 5, -165796510), m = a(m, p, d, f, e[n + 6], 9, -1069501632), f = a(f, m, p, d, e[n + 11], 14, 643717713), d = a(d, f, m, p, e[n], 20, -373897302), p = a(p, d, f, m, e[n + 5], 5, -701558691), m = a(m, p, d, f, e[n + 10], 9, 38016083), f = a(f, m, p, d, e[n + 15], 14, -660478335), d = a(d, f, m, p, e[n + 4], 20, -405537848), p = a(p, d, f, m, e[n + 9], 5, 568446438), m = a(m, p, d, f, e[n + 14], 9, -1019803690), f = a(f, m, p, d, e[n + 3], 14, -187363961), d = a(d, f, m, p, e[n + 8], 20, 1163531501), p = a(p, d, f, m, e[n + 13], 5, -1444681467), m = a(m, p, d, f, e[n + 2], 9, -51403784), f = a(f, m, p, d, e[n + 7], 14, 1735328473), p = s(p, d = a(d, f, m, p, e[n + 12], 20, -1926607734), f, m, e[n + 5], 4, -378558), m = s(m, p, d, f, e[n + 8], 11, -2022574463), f = s(f, m, p, d, e[n + 11], 16, 1839030562), d = s(d, f, m, p, e[n + 14], 23, -35309556), p = s(p, d, f, m, e[n + 1], 4, -1530992060), m = s(m, p, d, f, e[n + 4], 11, 1272893353), f = s(f, m, p, d, e[n + 7], 16, -155497632), d = s(d, f, m, p, e[n + 10], 23, -1094730640), p = s(p, d, f, m, e[n + 13], 4, 681279174), m = s(m, p, d, f, e[n], 11, -358537222), f = s(f, m, p, d, e[n + 3], 16, -722521979), d = s(d, f, m, p, e[n + 6], 23, 76029189), p = s(p, d, f, m, e[n + 9], 4, -640364487), m = s(m, p, d, f, e[n + 12], 11, -421815835), f = s(f, m, p, d, e[n + 15], 16, 530742520), p = l(p, d = s(d, f, m, p, e[n + 2], 23, -995338651), f, m, e[n], 6, -198630844), m = l(m, p, d, f, e[n + 7], 10, 1126891415), f = l(f, m, p, d, e[n + 14], 15, -1416354905), d = l(d, f, m, p, e[n + 5], 21, -57434055), p = l(p, d, f, m, e[n + 12], 6, 1700485571), m = l(m, p, d, f, e[n + 3], 10, -1894986606), f = l(f, m, p, d, e[n + 10], 15, -1051523), d = l(d, f, m, p, e[n + 1], 21, -2054922799), p = l(p, d, f, m, e[n + 8], 6, 1873313359), m = l(m, p, d, f, e[n + 15], 10, -30611744), f = l(f, m, p, d, e[n + 6], 15, -1560198380), d = l(d, f, m, p, e[n + 13], 21, 1309151649), p = l(p, d, f, m, e[n + 4], 6, -145523070), m = l(m, p, d, f, e[n + 11], 10, -1120210379), f = l(f, m, p, d, e[n + 2], 15, 718787259), d = l(d, f, m, p, e[n + 9], 21, -343485551), p = r(p, i), d = r(d, c), f = r(f, u), m = r(m, h);
                        return [p, d, f, m]
                    }

                    function u(e) {
                        var t, n = "",
                            r = 32 * e.length;
                        for (t = 0; t < r; t += 8) n += String.fromCharCode(e[t >> 5] >>> t % 32 & 255);
                        return n
                    }

                    function h(e) {
                        var t, n = [];
                        for (n[(e.length >> 2) - 1] = void 0, t = 0; t < n.length; t += 1) n[t] = 0;
                        var r = 8 * e.length;
                        for (t = 0; t < r; t += 8) n[t >> 5] |= (255 & e.charCodeAt(t / 8)) << t % 32;
                        return n
                    }

                    function p(e) {
                        var t, n, r = "0123456789abcdef",
                            i = "";
                        for (n = 0; n < e.length; n += 1) t = e.charCodeAt(n), i += r.charAt(t >>> 4 & 15) + r.charAt(15 & t);
                        return i
                    }

                    function d(e) {
                        return unescape(encodeURIComponent(e))
                    }

                    function f(e) {
                        return function(e) {
                            return u(c(h(e), 8 * e.length))
                        }(d(e))
                    }

                    function m(e, t) {
                        return function(e, t) {
                            var n, r, i = h(e),
                                o = [],
                                a = [];
                            for (o[15] = a[15] = void 0, i.length > 16 && (i = c(i, 8 * e.length)), n = 0; n < 16; n += 1) o[n] = 909522486 ^ i[n], a[n] = 1549556828 ^ i[n];
                            return r = c(o.concat(h(t)), 512 + 8 * t.length), u(c(a.concat(r), 640))
                        }(d(e), d(t))
                    }
                    t.exports = function(e, t, n) {
                        return t ? n ? m(t, e) : function(e, t) {
                            return p(m(e, t))
                        }(t, e) : n ? f(e) : function(e) {
                            return p(f(e))
                        }(e)
                    }
                }, {}]
            }, {}, [4])(4)
        }));
    var J = [{
            family: "UC Browser",
            patterns: ["(UC? ?Browser|UCWEB|U3)[ /]?(\\d+)\\.(\\d+)\\.(\\d+)"]
        }, {
            family: "Opera",
            name_replace: "Opera Mobile",
            patterns: ["(Opera)/.+Opera Mobi.+Version/(\\d+)\\.(\\d+)", "(Opera)/(\\d+)\\.(\\d+).+Opera Mobi", "Opera Mobi.+(Opera)(?:/|\\s+)(\\d+)\\.(\\d+)", "Opera Mobi", "(?:Mobile Safari).*(OPR)/(\\d+)\\.(\\d+)\\.(\\d+)"]
        }, {
            family: "Opera",
            name_replace: "Opera Mini",
            patterns: ["(Opera Mini)(?:/att|)/?(\\d+|)(?:\\.(\\d+)|)(?:\\.(\\d+)|)", "(OPiOS)/(\\d+).(\\d+).(\\d+)"]
        }, {
            family: "Opera",
            name_replace: "Opera Neon",
            patterns: ["Chrome/.+( MMS)/(\\d+).(\\d+).(\\d+)"]
        }, {
            name_replace: "Opera",
            patterns: ["(Opera)/9.80.*Version/(\\d+)\\.(\\d+)(?:\\.(\\d+)|)", "(?:Chrome).*(OPR)/(\\d+)\\.(\\d+)\\.(\\d+)"]
        }, {
            family: "Firefox",
            name_replace: "Firefox Mobile",
            patterns: ["(Fennec)/(\\d+)\\.(\\d+)\\.?([ab]?\\d+[a-z]*)", "(Fennec)/(\\d+)\\.(\\d+)(pre)", "(Fennec)/(\\d+)\\.(\\d+)", "(?:Mobile|Tablet);.*(Firefox)/(\\d+)\\.(\\d+)", "(FxiOS)/(\\d+)\\.(\\d+)(\\.(\\d+)|)(\\.(\\d+)|)"]
        }, {
            name_replace: "Coc Coc",
            patterns: ["(coc_coc_browser)/(\\d+)\\.(\\d+)(?:\\.(\\d+)|)"]
        }, {
            family: "QQ",
            name_replace: "QQ Mini",
            patterns: ["(MQQBrowser/Mini)(?:(\\d+)(?:\\.(\\d+)|)(?:\\.(\\d+)|)|)"]
        }, {
            family: "QQ",
            name_replace: "QQ Mobile",
            patterns: ["(MQQBrowser)(?:/(\\d+)(?:\\.(\\d+)|)(?:\\.(\\d+)|)|)"]
        }, {
            name_replace: "QQ",
            patterns: ["(QQBrowser)(?:/(\\d+)(?:\\.(\\d+)\\.(\\d+)(?:\\.(\\d+)|)|)|)"]
        }, {
            family: "Edge",
            name: "Edge Mobile",
            patterns: ["Windows Phone .*(Edge)/(\\d+)\\.(\\d+)", "(EdgiOS|EdgA)/(\\d+)\\.(\\d+).(\\d+).(\\d+)"]
        }, {
            name_replace: "Edge",
            patterns: ["(Edge|Edg)/(\\d+)(?:\\.(\\d+)|)"]
        }, {
            patterns: ["(Puffin)/(\\d+)\\.(\\d+)(?:\\.(\\d+)|)"]
        }, {
            family: "Chrome",
            name_replace: "Chrome Mobile",
            patterns: ["Version/.+(Chrome)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)", "; wv\\).+(Chrome)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)", "(CriOS)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)", "(CrMo)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)", "(Chrome)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+) Mobile(?:[ /]|$)", " Mobile .*(Chrome)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)"]
        }, {
            family: "Yandex",
            name_replace: "Yandex Mobile",
            patterns: ["(YaBrowser)/(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+).*Mobile"]
        }, {
            name_replace: "Yandex",
            patterns: ["(YaBrowser)/(\\d+)\\.(\\d+)\\.(\\d+)"]
        }, {
            patterns: ["(Vivaldi)/(\\d+)\\.(\\d+)", "(Vivaldi)/(\\d+)\\.(\\d+)\\.(\\d+)"]
        }, {
            name_replace: "Brave",
            patterns: ["(brave)/(\\d+)\\.(\\d+)\\.(\\d+) Chrome"]
        }, {
            family: "Chrome",
            patterns: ["(Chromium|Chrome)/(\\d+)\\.(\\d+)(?:\\.(\\d+)|)(?:\\.(\\d+)|)"]
        }, {
            name_replace: "Internet Explorer Mobile",
            patterns: ["(IEMobile)[ /](\\d+)\\.(\\d+)"]
        }, {
            family: "Safari",
            name_replace: "Safari Mobile",
            patterns: ["(iPod|iPhone|iPad).+Version/(d+).(d+)(?:.(d+)|).*[ +]Safari", "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|).* AppleNews\\/\\d+\\.\\d+\\.\\d+?", "(iPod|iPhone|iPad).+Version/(\\d+)\\.(\\d+)(?:\\.(\\d+)|)", "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|).*Mobile.*[ +]Safari", "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|).*Mobile", "(iPod|iPod touch|iPhone|iPad).* Safari", "(iPod|iPod touch|iPhone|iPad)"]
        }, {
            name_replace: "Safari",
            patterns: ["(Version)/(\\d+)\\.(\\d+)(?:\\.(\\d+)|).*Safari/"]
        }, {
            name_replace: "Internet Explorer",
            patterns: ["(Trident)/(7|8).(0)"],
            major_replace: "11"
        }, {
            name_replace: "Internet Explorer",
            patterns: ["(Trident)/(6)\\.(0)"],
            major_replace: "10"
        }, {
            name_replace: "Internet Explorer",
            patterns: ["(Trident)/(5)\\.(0)"],
            major_replace: "9"
        }, {
            name_replace: "Internet Explorer",
            patterns: ["(Trident)/(4)\\.(0)"],
            major_replace: "8"
        }, {
            family: "Firefox",
            patterns: ["(Firefox)/(\\d+)\\.(\\d+)\\.(\\d+)", "(Firefox)/(\\d+)\\.(\\d+)(pre|[ab]\\d+[a-z]*|)"]
        }],
        z = [{
            family: "Windows",
            name_replace: "Windows Phone",
            patterns: ["(Windows Phone) (?:OS[ /])?(\\d+)\\.(\\d+)", "^UCWEB.*; (wds) (\\d+)\\.(d+)(?:\\.(\\d+)|);", "^UCWEB.*; (wds) (\\d+)\\.(\\d+)(?:\\.(\\d+)|);"]
        }, {
            family: "Windows",
            name_replace: "Windows Mobile",
            patterns: ["(Windows ?Mobile)"]
        }, {
            name_replace: "Android",
            patterns: ["(Android)[ \\-/](\\d+)(?:\\.(\\d+)|)(?:[.\\-]([a-z0-9]+)|)", "(Android) (d+);", "^UCWEB.*; (Adr) (\\d+)\\.(\\d+)(?:[.\\-]([a-z0-9]+)|);", "^(JUC).*; ?U; ?(?:Android|)(\\d+)\\.(\\d+)(?:[\\.\\-]([a-z0-9]+)|)", "(android)\\s(?:mobile\\/)(\\d+)(?:\\.(\\d+)(?:\\.(\\d+)|)|)", "(Silk-Accelerated=[a-z]{4,5})", "Puffin/[\\d\\.]+AT", "Puffin/[\\d\\.]+AP"]
        }, {
            name_replace: "Chrome OS",
            patterns: ["(x86_64|aarch64)\\ (\\d+)\\.(\\d+)\\.(\\d+).*Chrome.*(?:CitrixChromeApp)$", "(CrOS) [a-z0-9_]+ (\\d+)\\.(\\d+)(?:\\.(\\d+)|)"]
        }, {
            name_replace: "Windows",
            patterns: ["(Windows 10)", "(Windows NT 6\\.4)", "(Windows NT 10\\.0)"],
            major_replace: "10"
        }, {
            name_replace: "Windows",
            patterns: ["(Windows NT 6\\.3; ARM;)", "(Windows NT 6.3)"],
            major_replace: "8",
            minor_replace: "1"
        }, {
            name_replace: "Windows",
            patterns: ["(Windows NT 6\\.2)"],
            major_replace: "8"
        }, {
            name_replace: "Windows",
            patterns: ["(Windows NT 6\\.1)"],
            major_replace: "7"
        }, {
            name_replace: "Windows",
            patterns: ["(Windows NT 6\\.0)"],
            major_replace: "Vista"
        }, {
            name_replace: "Windows",
            patterns: ["(Windows (?:NT 5\\.2|NT 5\\.1))"],
            major_replace: "XP"
        }, {
            name_replace: "Mac OS X",
            patterns: ["((?:Mac[ +]?|; )OS[ +]X)[\\s+/](?:(\\d+)[_.](\\d+)(?:[_.](\\d+)|)|Mach-O)", "\\w+\\s+Mac OS X\\s+\\w+\\s+(\\d+).(\\d+).(\\d+).*", "(?:PPC|Intel) (Mac OS X)"]
        }, {
            name_replace: "Mac OS X",
            patterns: [" (Dar)(win)/(10).(d+).*((?:i386|x86_64))"],
            major_replace: "10",
            minor_replace: "6"
        }, {
            name_replace: "Mac OS X",
            patterns: [" (Dar)(win)/(11).(\\d+).*\\((?:i386|x86_64)\\)"],
            major_replace: "10",
            minor_replace: "7"
        }, {
            name_replace: "Mac OS X",
            patterns: [" (Dar)(win)/(12).(\\d+).*\\((?:i386|x86_64)\\)"],
            major_replace: "10",
            minor_replace: "8"
        }, {
            name_replace: "Mac OS X",
            patterns: [" (Dar)(win)/(13).(\\d+).*\\((?:i386|x86_64)\\)"],
            major_replace: "10",
            minor_replace: "9"
        }, {
            name_replace: "iOS",
            patterns: ["^UCWEB.*; (iPad|iPh|iPd) OS (\\d+)_(\\d+)(?:_(\\d+)|);", "(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS)[ +]+(\\d+)[_\\.](\\d+)(?:[_\\.](\\d+)|)", "(iPhone|iPad|iPod); Opera", "(iPhone|iPad|iPod).*Mac OS X.*Version/(\\d+)\\.(\\d+)", "\\b(iOS[ /]|iOS; |iPhone(?:/| v|[ _]OS[/,]|; | OS : |\\d,\\d/|\\d,\\d; )|iPad/)(\\d{1,2})[_\\.](\\d{1,2})(?:[_\\.](\\d+)|)", "\\((iOS);", "(iPod|iPhone|iPad)", "Puffin/[\\d\\.]+IT", "Puffin/[\\d\\.]+IP"]
        }, {
            family: "Chrome",
            name_replace: "Chromecast",
            patterns: ["(CrKey -)(?:[ /](\\d+)\\.(\\d+)(?:\\.(\\d+)|)|)", "(CrKey[ +]armv7l)(?:[ /](\\d+)\\.(\\d+)(?:\\.(\\d+)|)|)", "(CrKey)(?:[/](\\d+)\\.(\\d+)(?:\\.(\\d+)|)|)"]
        }, {
            name_replace: "Debian",
            patterns: ["([Dd]ebian)"]
        }, {
            family: "Linux",
            name_replace: "Linux",
            patterns: ["(Linux Mint)(?:/(\\d+)|)"]
        }, {
            family: "Linux",
            patterns: ["(Ubuntu|Kubuntu|Arch Linux|CentOS|Slackware|Gentoo|openSUSE|SUSE|Red Hat|Fedora|PCLinuxOS|Mageia|(?:Free|Open|Net|\\b)BSD)", "(Mandriva)(?: Linux|)/(?:[\\d.-]+m[a-z]{2}(\\d+).(\\d)|)", "(Linux)(?:[ /](\\d+)\\.(\\d+)(?:\\.(\\d+)|)|)", "\\(linux-gnu\\)"]
        }, {
            family: "BlackBerry",
            name_replace: "BlackBerry OS",
            patterns: ["(BB10);.+Version/(\\d+)\\.(\\d+)\\.(\\d+)", "(Black[Bb]erry)[0-9a-z]+/(\\d+)\\.(\\d+)\\.(\\d+)(?:\\.(\\d+)|)", "(Black[Bb]erry).+Version/(\\d+)\\.(\\d+)\\.(\\d+)(?:\\.(\\d+)|)", "(Black[Bb]erry)"]
        }, {
            patterns: ["(Fedora|Red Hat|PCLinuxOS|Puppy|Ubuntu|Kindle|Bada|Sailfish|Lubuntu|BackTrack|Slackware|(?:Free|Open|Net|\\b)BSD)[/ ](\\d+)\\.(\\d+)(?:\\.(\\d+)|)(?:\\.(\\d+)|)"]
        }],
        X = navigator.userAgent,
        I = function() {
            return X
        },
        K = function(e) {
            return H(e || X, J)
        },
        Y = function(e) {
            return H(e || X, z)
        };

    function L(e, t) {
        try {
            var n = new RegExp(t).exec(e);
            return n ? {
                name: n[1] || "Other",
                major: n[2] || "0",
                minor: n[3] || "0",
                patch: n[4] || "0"
            } : null
        } catch (dr) {
            return null
        }
    }

    function H(e, t) {
        for (var n = null, r = null, i = -1, o = !1; ++i < t.length && !o;) {
            n = t[i];
            for (var a = -1; ++a < n.patterns.length && !o;) o = null !== (r = L(e, n.patterns[a]))
        }
        return o ? (r.family = n.family || n.name_replace || r.name, n.name_replace && (r.name = n.name_replace), n.major_replace && (r.major = n.major_replace), n.minor_replace && (r.minor = n.minor_replace), n.patch_replace && (r.minor = n.patch_replace), r) : {
            family: "Other",
            name: "Other",
            major: "0",
            minor: "0",
            patch: "0"
        }
    }

    function Q() {
        var e = this,
            t = K(),
            n = I();
        this.agent = n.toLowerCase(), this.language = window.navigator.userLanguage || window.navigator.language, this.isCSS1 = "CSS1Compat" === (document.compatMode || ""), this.width = function() {
            return window.innerWidth && window.document.documentElement.clientWidth ? Math.min(window.innerWidth, document.documentElement.clientWidth) : window.innerWidth || window.document.documentElement.clientWidth || document.body.clientWidth
        }, this.height = function() {
            return window.innerHeight || window.document.documentElement.clientHeight || document.body.clientHeight
        }, this.scrollX = function() {
            return window.pageXOffset !== undefined ? window.pageXOffset : e.isCSS1 ? document.documentElement.scrollLeft : document.body.scrollLeft
        }, this.scrollY = function() {
            return window.pageYOffset !== undefined ? window.pageYOffset : e.isCSS1 ? document.documentElement.scrollTop : document.body.scrollTop
        }, this.type = "Edge" === t.family ? "edge" : "Internet Explorer" === t.family ? "ie" : "Chrome" === t.family ? "chrome" : "Safari" === t.family ? "safari" : "Firefox" === t.family ? "firefox" : t.family.toLowerCase(), this.version = 1 * (t.major + "." + t.minor) || 0, this.hasPostMessage = !!window.postMessage
    }
    Q.prototype.hasEvent = function(e, t) {
        return "on" + e in (t || document.createElement("div"))
    }, Q.prototype.getScreenDimensions = function() {
        var e = {};
        for (var t in window.screen) e[t] = window.screen[t];
        return delete e.orientation, e
    }, Q.prototype.getOrientation = function() {
        return "function" == typeof matchMedia ? matchMedia("(orientation: landscape)").matches ? "landscape" : "portrait" : window.screen.orientation ? screen.orientation.type.startsWith("landscape") ? "landscape" : "portrait" : this.width() > this.height() ? "landscape" : "portrait"
    }, Q.prototype.getWindowDimensions = function() {
        return [this.width(), this.height()]
    }, Q.prototype.interrogateNavigator = function() {
        var e = {};
        for (var t in window.navigator)
            if ("webkitPersistentStorage" !== t) try {
                e[t] = window.navigator[t]
            } catch (pr) {}
        if (delete e.plugins, delete e.mimeTypes, e.plugins = [], window.navigator.plugins)
            for (var n = 0; n < window.navigator.plugins.length; n++) e.plugins[n] = window.navigator.plugins[n].filename;
        return e
    }, Q.prototype.supportsPST = function() {
        return !(document.hasPrivateToken === undefined || !document.featurePolicy || !document.featurePolicy.allowsFeature) && document.featurePolicy.allowsFeature("private-state-token-redemption")
    }, Q.prototype.supportsCanvas = function() {
        var e = document.createElement("canvas");
        return !(!e.getContext || !e.getContext("2d"))
    }, Q.prototype.supportsWebAssembly = function() {
        try {
            if ("object" == typeof WebAssembly && "function" == typeof WebAssembly.instantiate) {
                var e = new WebAssembly.Module(Uint8Array.of(0, 97, 115, 109, 1, 0, 0, 0));
                if (e instanceof WebAssembly.Module) return new WebAssembly.Instance(e) instanceof WebAssembly.Instance
            }
        } catch (dr) {
            return !1
        }
    };
    var $ = new Q,
        q = new function() {
            var e, t, n = Y(),
                r = I();
            this.mobile = (e = !!("ontouchstart" in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0), t = !1, n && (t = ["iOS", "Windows Phone", "Windows Mobile", "Android", "BlackBerry OS"].indexOf(n.name) >= 0), e && t), this.dpr = function() {
                return window.devicePixelRatio || 1
            }, this.highContrast = !(!window.matchMedia || !window.matchMedia("(forced-colors: active)").matches) || !(!window.matchMedia || !window.matchMedia("(-ms-high-contrast: active)").matches), this.mobile && n && "Windows" === n.family && r.indexOf("touch") < 0 && (this.mobile = !1), this.os = "iOS" === n.family ? "ios" : "Android" === n.family ? "android" : "Mac OS X" === n.family ? "mac" : "Windows" === n.family ? "windows" : "Linux" === n.family ? "linux" : n.family.toLowerCase(), this.version = function() {
                if (!n) return "unknown";
                var e = n.major;
                return n.minor && (e += "." + n.minor), n.patch && (e += "." + n.patch), e
            }()
        },
        ee = {
            Browser: $,
            System: q,
            supportsPAT: function() {
                return ("mac" === q.os || "ios" === q.os) && "safari" === $.type && $.version >= 16.2
            }
        },
        te = "challenge-passed",
        ne = "challenge-escaped",
        re = "challenge-closed",
        ie = "challenge-expired",
        oe = "invalid-data",
        ae = "invalid-mfa-data",
        se = "bundle-error",
        le = "rate-limited",
        ce = "network-error",
        ue = "challenge-error",
        he = "incomplete-answer",
        pe = "missing-captcha",
        de = "missing-sitekey",
        fe = "invalid-captcha-id",
        me = "https://api.hcaptcha.com",
        ge = "https://api2.hcaptcha.com",
        ye = "auto",
        Ve = {
            host: null,
            file: null,
            sitekey: null,
            a11y_tfe: null,
            pingdom: "safari" === ee.Browser.type && "windows" !== ee.System.os && "mac" !== ee.System.os && "ios" !== ee.System.os && "android" !== ee.System.os,
            assetDomain: "https://newassets.hcaptcha.com",
            assetUrl: "https://newassets.hcaptcha.com/captcha/v1/5ea3feff9cf1292d7051510930d98c4719f64575/static",
            width: null,
            height: null,
            mobile: null,
            orientation: "portrait",
            challenge_type: null,
            mfaData: {},
            prevSmsinEkey: null
        },
        ve = {
            se: null,
            custom: !1,
            tplinks: "on",
            language: null,
            reportapi: "https://accounts.hcaptcha.com",
            endpoint: me,
            pstIssuer: "https://pst-issuer.hcaptcha.com",
            isSecure: !1,
            size: "normal",
            theme: "light",
            mode: undefined,
            assethost: null,
            imghost: null,
            recaptchacompat: "true",
            pat: "on",
            andint: "off",
            confirmNav: !1
        },
        be = "https://30910f52569b4c17b1081ead2dae43b4@sentry.hcaptcha.com/6",
        Re = "5ea3feff9cf1292d7051510930d98c4719f64575",
        we = "prod";

    function Te(e, t) {
        try {
            e.style.width = "302px", e.style.height = "76px", e.style.backgroundColor = "#f9e5e5", e.style.position = "relative", e.innerHTML = "";
            var n = document.createElement("div");
            n.style.width = "284px", n.style.position = "absolute", n.style.top = "12px", n.style.left = "10px", n.style.color = "#7c0a06", n.style.fontSize = "14px", n.style.fontWeight = "normal", n.style.lineHeight = "18px", n.innerHTML = t || "Please <a style='color:inherit;text-decoration:underline; font: inherit' target='_blank' href='https://www.whatismybrowser.com/guides/how-to-update-your-browser/auto'>upgrade your browser</a> to complete this captcha.", e.appendChild(n)
        } catch (r) {
            console.error("[hCaptcha] Error while rendering in the provided container.", {
                container: e
            }, r)
        }
    }

    function Se(e) {
        for (var t = document.getElementsByClassName("h-captcha"), n = [], r = 0; r < t.length; r++) n.push(t[r]);
        var i = [];
        if ("off" !== ve.recaptchacompat)
            for (var o = document.getElementsByClassName("g-recaptcha"), a = 0; a < o.length; a++) i.push(o[a]);
        for (var s = [].concat(n, i), l = 0; l < s.length; l++) e(s[l])
    }
    var Ee = "The captcha failed to load.",
        _e = [],
        ke = /(https?|wasm):\/\//,
        Ue = /^at\s/,
        xe = /:\d+:\d+/g,
        We = ["Rate limited or network error. Please retry.", "Unreachable code should not be executed", "Out of bounds memory access"];

    function Me(e) {
        return ke.test(e) ? null : e.trim().replace(Ue, "").replace(xe, "")
    }

    function Fe(e) {
        for (var t = [], n = 0, r = e.length; n < r; n++) {
            var i = Me(e[n]);
            null !== i && t.push(i)
        }
        return t.join("\n").trim()
    }

    function Ne(e) {
        if (e && "string" == typeof e && -1 === _e.indexOf(e) && !(_e.length >= 10)) {
            var t = Fe(e.trim().split("\n").slice(0, 2));
            _e.push(t)
        }
    }

    function Pe(e) {
        try {
            e && "object" == typeof e || (e = {
                name: "error",
                message: "",
                stack: ""
            });
            var t = {
                message: e.name + ": " + e.message
            };
            e.stack && (t.stack_trace = {
                trace: e.stack
            }), Ae("report error", "internal", "debug", t), Be(e.message || "internal error", "error", Ve.file, e)
        } catch (n) {}
    }

    function Ze(e) {
        return function() {
            try {
                return e.apply(this, arguments)
            } catch (pr) {
                throw Pe(pr), Se((function(e) {
                    Te(e, Ee)
                })), pr
            }
        }
    }

    function Oe(e) {
        return -1 !== e.indexOf("hsw.js") || -1 !== e.indexOf("/1/api.js") || -1 !== e.indexOf("newassets.hcaptcha.com") || -1 !== e.indexOf("hcaptcha.html")
    }

    function je(e) {
        return "string" == typeof e && (-1 !== e.indexOf("chrome-extension://") || -1 !== e.indexOf("safari-extension://") || -1 !== e.indexOf("moz-extension://") || -1 !== e.indexOf("chrome://internal-") || -1 !== e.indexOf("/hammerhead.js") || -1 !== e.indexOf("eval at buildCode") || -1 !== e.indexOf("u.c.b.r.o.w.s.e.r/ucbrowser_script.js"))
    }

    function Ce(e, t) {
        if (void 0 === t && (t = !0), ve.sentry) try {
            if (window.Raven && Raven.config(be, {
                    release: Re,
                    environment: we,
                    autoBreadcrumbs: {
                        xhr: !0,
                        dom: !0,
                        sentry: !0
                    },
                    tags: {
                        "site-host": Ve.host,
                        "site-key": Ve.sitekey,
                        "endpoint-url": ve.endpoint,
                        "asset-url": Ve.assetUrl
                    },
                    sampleRate: .01,
                    ignoreErrors: ["Cannot set properties of undefined (setting 'data')", "canvas.contentDocument", "Can't find variable: ZiteReader", "Cannot redefine property: hcaptcha", "Cannot redefine property: BetterJsPop", "grecaptcha is not defined", "jQuery is not defined", "$ is not defined", "Script is not a function"]
                }), window.Raven && Raven.setUserContext({
                    "Browser-Agent": ee.Browser.agent,
                    "Browser-Type": ee.Browser.type,
                    "Browser-Version": ee.Browser.version,
                    "System-OS": ee.System.os,
                    "System-Version": ee.System.version,
                    "Is-Mobile": ee.System.mobile
                }), Ae(Ve.file + "_internal", "setup", "info"), e) {
                var n = function(e, n, r, i, o, a) {
                        o && "object" == typeof o || (o = {});
                        var s = o.name || "Error",
                            l = o.stack || "";
                        (Oe(l) || t) && (Ze(Ne)(l), je(l) || je(n) || (Ae(e, "global", "debug", {
                            crossOrigin: a,
                            name: s,
                            url: n,
                            line: r,
                            column: i,
                            stack: l
                        }), De("global", o, {
                            message: e
                        })))
                    },
                    r = function(e) {
                        var t = e.reason;
                        null == t && e.detail && e.detail.reason && (t = (e = e.detail).reason);
                        var n = "";
                        if (e.reason && "undefined" != typeof e.reason.stack && (n = e.reason.stack), Oe(n) && e.reason instanceof Error) {
                            Ze(Ne)(n);
                            var r = t.url || "";
                            je(n) || je(r) || (Ae(t.message, "global-rejection", "debug", {
                                promise: e.promise,
                                name: t.name,
                                url: r,
                                line: t.lineno,
                                column: t.columnno,
                                stack: n
                            }), De("global-rejection", t, {
                                promise: e.promise,
                                message: t.message
                            }))
                        }
                    };
                "function" == typeof window.addEventListener ? (window.addEventListener("error", (function(e) {
                    n(e.message, e.filename, e.lineno, e.colno, e.error, function(e) {
                        try {
                            return !("Script error." !== e.message || "" !== e.filename && null != e.filename || 0 !== e.lineno && null != e.lineno || 0 !== e.colno && null != e.colno || null != e.error)
                        } catch (dr) {
                            return !1
                        }
                    }(e))
                }), !0), window.addEventListener("unhandledrejection", r, !0)) : t && (window.onerror = n, window.onunhandledrejection = r)
            }
        } catch (i) {}
    }

    function Be(e, t, n, r) {
        try {
            if (t = t || "error", "string" == typeof e) {
                for (var i = We.length; i--;)
                    if (e.indexOf(We[i]) >= 0) {
                        e = We[i];
                        break
                    }
                /^self\.\w* is not a function$/.test(e) ? e = "self.X is not a function" : /^\w\._.*\[t\] is not a function/.test(e) && (e = "x._y[t] is not a function")
            }
            if (ve.sentry) {
                var o = "warn" === t ? "warning" : t;
                window.Raven && Raven.captureMessage(e, {
                    level: o,
                    logger: n,
                    extra: r
                })
            }
        } catch (a) {}
    }

    function De(e, t, n) {
        try {
            return (n = n || {}).error = t, Be(e + ":" + (("string" == typeof t ? t : t && t.message) || n.message || "missing-error"), "error", e, n)
        } catch (r) {}
    }

    function Ae(e, t, n, r) {
        try {
            ve.sentry && window.Raven && Raven.captureBreadcrumb({
                message: e,
                category: t,
                level: n,
                data: r
            })
        } catch (i) {}
    }
    var Ge = {
        __proto__: null,
        _stackTraceSet: _e,
        refineLine: Me,
        toRefinedString: Fe,
        reportError: Pe,
        errorWrapper: Ze,
        initSentry: Ce,
        sentryMessage: Be,
        sentryError: De,
        sentryBreadcrumb: Ae
    };

    function Je() {
        var e = [],
            t = null,
            n = !1,
            r = [],
            i = function(t) {
                try {
                    if (e.length >= 10) return;
                    var n = t.stack;
                    if ("string" != typeof n) return;
                    var r = n.trim().split("\n");
                    "Error" === r[0] && (r = r.slice(1));
                    for (var i = /extension/, o = r.length - 1, a = [], s = 0; o >= 0 && a.length < 6;) {
                        var l = r[o],
                            c = Me(l);
                        if (null !== c) {
                            if (i.test(l)) {
                                a = [c];
                                break
                            }
                            if (a.unshift(c), s = Math.max(s, c.length), a.length >= 2 && s >= 30) break;
                            o--
                        } else o--
                    }
                    var u = a.join("\n").trim();
                    u && -1 === e.indexOf(u) && e.push(u)
                } catch (t) {
                    return
                }
            },
            o = function() {
                if (n) try {
                    for (var e = 0, o = r.length; e < o; e++) r[e]();
                    null !== t && clearTimeout(t)
                } catch (a) {
                    i(a)
                } finally {
                    r = [], t = null, n = !1
                }
            },
            a = function(t, a) {
                var s = Object.getOwnPropertyDescriptor(t, a);
                if (!(s && !1 === s.writable)) {
                    var l, c = Object.prototype.hasOwnProperty.call(t, a),
                        u = t[a];
                    l = "undefined" != typeof Proxy && "undefined" != typeof Reflect ? new Proxy(u, {
                        apply: function(t, r, a) {
                            return n && (e.length >= 10 && o(), i(new Error)), Reflect.apply(t, r, a)
                        }
                    }) : function() {
                        return n && (e.length >= 10 && o(), i(new Error)), u.apply(this, arguments)
                    }, Object.defineProperty(t, a, {
                        configurable: !0,
                        enumerable: !s || s.enumerable,
                        writable: !0,
                        value: l
                    }), r.push((function() {
                        c ? Object.defineProperty(t, a, {
                            configurable: !0,
                            enumerable: !s || s.enumerable,
                            writable: !0,
                            value: u
                        }) : delete t[a]
                    }))
                }
            };
        return {
            run: function(e) {
                var r = (e = e || {}).timeout,
                    s = !0 === e.topLevel && e.topLevel;
                if (!n) {
                    n = !0, "number" == typeof r && isFinite(r) && (t = setTimeout((function() {
                        o()
                    }), r));
                    try {
                        a(Document.prototype, "getElementsByClassName"), a(Document.prototype, "getElementById"), a(Document.prototype, "getElementsByTagName"), a(Document.prototype, "querySelector"), a(Document.prototype, "querySelectorAll"), a(Element.prototype, "getElementsByClassName"), a(Element.prototype, "getElementsByTagName"), a(Element.prototype, "querySelector"), a(Element.prototype, "querySelectorAll"), a(HTMLElement.prototype, "click"), a(HTMLElement.prototype, "getElementsByClassName"), a(HTMLElement.prototype, "getElementsByTagName"), a(HTMLElement.prototype, "querySelector"), a(HTMLElement.prototype, "querySelectorAll"), s || a(console, "log")
                    } catch (l) {
                        o(), i(l)
                    }
                }
            },
            collect: function() {
                return e.concat(_e)
            }
        }
    }
    var ze = {
            getCookie: function(e) {
                var t = document.cookie.replace(/ /g, "").split(";");
                try {
                    for (var n = "", r = t.length; r-- && !n;) t[r].indexOf(e) >= 0 && (n = t[r]);
                    return n
                } catch (dr) {
                    return ""
                }
            },
            hasCookie: function(e) {
                return !!ze.getCookie(e)
            },
            supportsAPI: function() {
                try {
                    return "hasStorageAccess" in document && "requestStorageAccess" in document
                } catch (dr) {
                    return !1
                }
            },
            hasAccess: function() {
                return new Promise((function(e) {
                    document.hasStorageAccess().then((function() {
                        e(!0)
                    }))["catch"]((function() {
                        e(!1)
                    }))
                }))
            },
            requestAccess: function() {
                try {
                    return document.requestStorageAccess()
                } catch (dr) {
                    return Promise.resolve()
                }
            }
        },
        Xe = {
            array: function(e) {
                if (0 === e.length) return e;
                for (var t, n, r = e.length; --r > -1;) n = Math.floor(Math.random() * (r + 1)), t = e[r], e[r] = e[n], e[n] = t;
                return e
            }
        };

    function Ie(e) {
        this.r = 255, this.g = 255, this.b = 255, this.a = 1, this.h = 1, this.s = 1, this.l = 1, this.parseString(e)
    }

    function Ke(e, t, n) {
        return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + 6 * (t - e) * n : n < .5 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e
    }
    Ie.hasAlpha = function(e) {
        return "string" == typeof e && (-1 !== e.indexOf("rgba") || 9 === e.length && "#" === e[0])
    }, Ie.prototype.parseString = function(e) {
        e && (0 === e.indexOf("#") ? this.fromHex(e) : 0 === e.indexOf("rgb") && this.fromRGBA(e))
    }, Ie.prototype.fromHex = function(e) {
        var t = 1;
        9 === e.length && (t = parseInt(e.substr(7, 2), 16) / 255);
        var n = (e = e.substr(1, 6)).replace(/^([a-f\d])([a-f\d])([a-f\d])?$/i, (function(e, t, n, r) {
                return t + t + n + n + r + r
            })),
            r = parseInt(n, 16),
            i = r >> 16,
            o = r >> 8 & 255,
            a = 255 & r;
        this.setRGBA(i, o, a, t)
    }, Ie.prototype.fromRGBA = function(e) {
        var t = e.indexOf("rgba"),
            n = e.substr(t).replace(/rgba?\(/, "").replace(/\)/, "").replace(/[\s+]/g, "").split(","),
            r = Math.floor(parseInt(n[0])),
            i = Math.floor(parseInt(n[1])),
            o = Math.floor(parseInt(n[2])),
            a = parseFloat(n[3]);
        this.setRGBA(r, i, o, a)
    }, Ie.prototype.setRGB = function(e, t, n) {
        this.setRGBA(e, t, n, 1)
    }, Ie.prototype.setRGBA = function(e, t, n, r) {
        this.r = e, this.g = t, this.b = n, this.a = isNaN(r) ? this.a : r, this.updateHSL()
    }, Ie.prototype.hsl2rgb = function(e, t, n) {
        if (0 === t) {
            var r = Math.round(255 * n);
            return this.setRGB(r, r, r), this
        }
        var i = n <= .5 ? n * (1 + t) : n + t - n * t,
            o = 2 * n - i;
        return this.r = Math.round(255 * Ke(o, i, e + 1 / 3)), this.g = Math.round(255 * Ke(o, i, e)), this.b = Math.round(255 * Ke(o, i, e - 1 / 3)), this.h = e, this.s = t, this.l = n, this
    }, Ie.prototype.updateHSL = function() {
        var e, t = this.r / 255,
            n = this.g / 255,
            r = this.b / 255,
            i = Math.max(t, n, r),
            o = Math.min(t, n, r),
            a = null,
            s = (i + o) / 2;
        if (i === o) a = e = 0;
        else {
            var l = i - o;
            switch (e = s > .5 ? l / (2 - i - o) : l / (i + o), i) {
                case t:
                    a = (n - r) / l + (n < r ? 6 : 0);
                    break;
                case n:
                    a = (r - t) / l + 2;
                    break;
                case r:
                    a = (t - n) / l + 4
            }
            a /= 6
        }
        return this.h = a, this.s = e, this.l = s, this
    }, Ie.prototype.getHex = function() {
        return "#" + ((1 << 24) + (this.r << 16) + (this.g << 8) + this.b).toString(16).slice(1)
    }, Ie.prototype.getRGBA = function() {
        return "rgba(" + this.r + "," + this.g + "," + this.b + "," + this.a + ")"
    }, Ie.prototype.clone = function() {
        var e = new Ie;
        return e.setRGBA(this.r, this.g, this.b, this.a), e
    }, Ie.prototype.mix = function(e, t) {
        e instanceof Ie || (e = new Ie(e));
        var n = new Ie,
            r = Math.round(this.r + t * (e.r - this.r)),
            i = Math.round(this.g + t * (e.g - this.g)),
            o = Math.round(this.b + t * (e.b - this.b));
        return n.setRGB(r, i, o), n
    }, Ie.prototype.blend = function(e, t) {
        var n;
        e instanceof Ie || (e = new Ie(e));
        for (var r = [], i = 0; i < t; i++) n = this.mix.call(this, e, i / t), r.push(n);
        return r
    }, Ie.prototype.lightness = function(e) {
        return e > 1 && (e /= 100), this.hsl2rgb(this.h, this.s, e), this
    }, Ie.prototype.saturation = function(e) {
        return e > 1 && (e /= 100), this.hsl2rgb(this.h, e, this.l), this
    }, Ie.prototype.hue = function(e) {
        return this.hsl2rgb(e / 360, this.s, this.l), this
    };
    var Ye = {
            decode: function(e) {
                try {
                    var t = e.split(".");
                    return {
                        header: JSON.parse(atob(t[0])),
                        payload: JSON.parse(atob(t[1])),
                        signature: atob(t[2].replace(/_/g, "/").replace(/-/g, "+")),
                        raw: {
                            header: t[0],
                            payload: t[1],
                            signature: t[2]
                        }
                    }
                } catch (dr) {
                    throw new Error("Token is invalid.")
                }
            },
            checkExpiration: function(e) {
                if (new Date(1e3 * e) <= new Date(Date.now())) throw new Error("Token is expired.");
                return !0
            }
        },
        Le = {
            _setup: !1,
            _af: null,
            _fps: 60,
            _singleFrame: 1 / 60,
            _lagThreshold: 500,
            _adjustedLag: 1 / 60 * 2,
            _startTime: 0,
            _lastTime: 0,
            _nextTime: 1 / 60,
            _elapsed: 0,
            _difference: 0,
            _renders: [],
            _paused: !1,
            _running: !1,
            _tick: !1,
            frame: 0,
            time: 0,
            requestFrame: null,
            cancelFrame: null,
            _init: function() {
                for (var e, t = window.requestAnimationFrame, n = window.cancelAnimationFrame, r = ["ms", "moz", "webkit", "o"], i = r.length; --i > -1 && !t;) t = window[r[i] + "RequestAnimationFrame"], n = window[r[i] + "CancelAnimationFrame"] || window[r[i] + "CancelRequestAnimationFrame"];
                t ? (Le.requestFrame = t.bind(window), Le.cancelFrame = n.bind(window)) : (Le.requestFrame = (e = Date.now(), function(t) {
                    window.setTimeout((function() {
                        t(Date.now() - e)
                    }), 1e3 * Le._singleFrame)
                }), Le.cancelFrame = function(e) {
                    return clearTimeout(e), null
                }), Le._setup = !0, Le._startTime = Le._lastTime = Date.now()
            },
            add: function(e, t) {
                Le._renders.push({
                    callback: e,
                    paused: !1 == !t || !1
                }), !1 == !t && Le.start()
            },
            remove: function(e) {
                for (var t = Le._renders.length; --t > -1;) Le._renders[t].callback === e && (Le._renders[t].paused = !0, Le._renders.splice(t, 1))
            },
            start: function(e) {
                if (!1 === Le._setup && Le._init(), e)
                    for (var t = Le._renders.length; --t > -1;) Le._renders[t].callback === e && (Le._renders[t].paused = !1);
                !0 !== Le._running && (Le._paused = !1, Le._running = !0, Le._af = Le.requestFrame(Le._update))
            },
            stop: function(e) {
                if (e)
                    for (var t = Le._renders.length; --t > -1;) Le._renders[t].callback === e && (Le._renders[t].paused = !0);
                else !1 !== Le._running && (Le._af = Le.cancelFrame(Le._af), Le._paused = !0, Le._running = !1)
            },
            elapsed: function() {
                return Date.now() - Le._startTime
            },
            fps: function(e) {
                return arguments.length ? (Le._fps = e, Le._singleFrame = 1 / (Le._fps || 60), Le._adjustedLag = 2 * Le._singleFrame, Le._nextTime = Le.time + Le._singleFrame, Le._fps) : Le._fps
            },
            isRunning: function() {
                return Le._running
            },
            _update: function() {
                if (!Le._paused && (Le._elapsed = Date.now() - Le._lastTime, Le._tick = !1, Le._elapsed > Le._lagThreshold && (Le._startTime += Le._elapsed - Le._adjustedLag), Le._lastTime += Le._elapsed, Le.time = (Le._lastTime - Le._startTime) / 1e3, Le._difference = Le.time - Le._nextTime, Le._difference > 0 && (Le.frame++, Le._nextTime += Le._difference + (Le._difference >= Le._singleFrame ? Le._singleFrame / 4 : Le._singleFrame - Le._difference), Le._tick = !0), Le._af = Le.requestFrame(Le._update), !0 === Le._tick && Le._renders.length > 0))
                    for (var e = Le._renders.length; --e > -1;) Le._renders[e] && !1 === Le._renders[e].paused && Le._renders[e].callback(Le.time)
            }
        };
    var He = function(e) {
            for (var t, n, r, i = {}, o = e ? e.indexOf("&") >= 0 ? e.split("&") : [e] : [], a = 0; a < o.length; a++)
                if (o[a].indexOf("=") >= 0) {
                    if (t = o[a].split("="), n = decodeURIComponent(t[0]), "false" !== (r = decodeURIComponent(t[1])) && "true" !== r || (r = "true" === r), "theme" === n || "themeConfig" === n) try {
                        r = JSON.parse(r)
                    } catch (dr) {}
                    i[n] = r
                }
            return i
        },
        Qe = function(e) {
            var t = [];
            for (var n in e) {
                var r = e[n];
                r = "object" == typeof r ? JSON.stringify(r) : r, t.push([encodeURIComponent(n), encodeURIComponent(r)].join("="))
            }
            return t.join("&")
        },
        $e = {
            __proto__: null,
            Decode: He,
            Encode: Qe
        };

    function qe(e, t, n) {
        return Math.min(Math.max(e, t), n)
    }
    var et = {
        __proto__: null,
        clamp: qe,
        range: function(e, t, n, r, i, o) {
            var a = (e - t) * (i - r) / (n - t) + r;
            return !1 === o ? a : qe(a, Math.min(r, i), Math.max(r, i))
        },
        toRadians: function(e) {
            return e * (Math.PI / 180)
        },
        toDegrees: function(e) {
            return 180 * e / Math.PI
        },
        lerp: function(e, t, n) {
            return e + (t - e) * n
        }
    };

    function tt(e, t, n, r) {
        this._period = e, this._interval = t, this._date = [], this._data = [], this._prevTimestamp = 0, this._meanPeriod = 0, this._medianPeriod = 0, this._medianMaxHeapSize = 32, this._medianMinHeap = [], this._medianMaxHeap = [], this._meanCounter = 0, this._baseTime = n || 0, this._maxEventsPerWindow = r || 128
    }

    function nt(e) {
        return new Promise((function(t, n) {
            e(t, n, (function r() {
                e(t, n, r)
            }))
        }))
    }

    function rt(e, t) {
        var n = "attempts" in (t = t || {}) ? t.attempts : 1,
            r = t.delay || 0,
            i = t.onFail;
        return nt((function(t, o, a) {
            e().then(t, (function(e) {
                var t = n-- > 0;
                if (i) {
                    var s = i(e, n);
                    s && (t = !1 !== s.retry && t, r = s.delay)
                }
                t ? setTimeout(a, r || 0) : o(e)
            }))
        }))
    }

    function it(e, t) {
        var n = "attempts" in (t = t || {}) ? t.attempts : 1,
            r = t.delay || 0,
            i = t.onFail,
            o = null,
            a = !1,
            s = nt((function(t, s, l) {
                a ? s(new Error("Request cancelled")) : e().then(t, (function(e) {
                    if (a) s(new Error("Request cancelled"));
                    else {
                        var t = n-- > 0;
                        if (i) {
                            var c = i(e, n);
                            c && (t = !1 !== c.retry && t, r = c.delay)
                        }
                        t ? o = setTimeout(l, r || 0) : s(e)
                    }
                }))
            }));
        return s.cancel = function() {
            a = !0, o && (clearTimeout(o), o = null)
        }, s
    }

    function ot(e, t) {
        return new Promise((function(n, r) {
            var i = setTimeout((function() {
                r(new Error("timeout"))
            }), t);
            e.then((function(e) {
                clearTimeout(i), n(e)
            }))["catch"]((function(e) {
                clearTimeout(i), r(e)
            }))
        }))
    }

    function at(e) {
        return e && e.split(/[?#]/)[0].split(".").pop() || ""
    }

    function st(e, t) {
        var n = (new TextEncoder).encode(e);
        return crypto.subtle.digest(t, n)
    }

    function lt(e, t) {
        return st(e, t).then((function(e) {
            for (var t = new Uint8Array(e), n = "", r = 0; r < t.length; r++) {
                var i = t[r].toString(16);
                1 === i.length && (i = "0" + i), n += i
            }
            return n
        }))
    }

    function ct(e, t) {
        for (var n = 0, r = 0; r < e.length; r++) n = (16 * n + parseInt(e.charAt(r), 16)) % t;
        return n
    }

    function ut(e) {
        var t = [].slice.call(arguments, 1);
        "string" == typeof e ? window[e] ? "function" == typeof window[e] ? window[e].apply(null, t) : console.log("[hCaptcha] Callback '" + e + "' is not a function.") : console.log("[hCaptcha] Callback '" + e + "' is not defined.") : "function" == typeof e ? e.apply(null, t) : console.log("[hcaptcha] Invalid callback '" + e + "'.")
    }

    function ht() {
        try {
            ut.apply(null, arguments)
        } catch (pr) {
            console.error("[hCaptcha] There was an error in your callback."), console.error(pr)
        }
    }

    function pt(e, t) {
        for (var n = ["hl", "custom", "andint", "tplinks", "sitekey", "theme", "type", "size", "tabindex", "callback", "expired-callback", "chalexpired-callback", "error-callback", "open-callback", "close-callback", "endpoint", "challenge-container", "confirm-nav", "orientation", "mode"], r = {}, i = 0; i < n.length; i++) {
            var o = n[i],
                a = t && t[o];
            a || (a = e.getAttribute("data-" + o)), a && (r[o] = a)
        }
        return r
    }
    tt.prototype.getMeanPeriod = function() {
        return this._meanPeriod
    }, tt.prototype.getMedianPeriod = function() {
        return this._medianPeriod
    }, tt.prototype.getData = function() {
        return this._cleanStaleData(), this._data
    }, tt.prototype.push = function(e, t) {
        this._cleanStaleData();
        var n = 0 === this._date.length;
        if (e - (this._date[this._date.length - 1] || 0) >= this._period && (this._date.push(e), this._data.push(t), this._data.length > this._maxEventsPerWindow && (this._date.shift(), this._data.shift())), !n) {
            var r = e - this._prevTimestamp;
            this._meanPeriod = (this._meanPeriod * this._meanCounter + r) / (this._meanCounter + 1), this._meanCounter++, this._medianPeriod = this._calculateMedianPeriod(r)
        }
        this._prevTimestamp = e
    }, tt.prototype._calculateMedianPeriod = function(e) {
        this._medianMaxHeap || (this._medianMaxHeap = []), this._medianMinHeap || (this._medianMinHeap = []);
        var t = this._fetchMedianPeriod();
        return 0 === this._medianMaxHeap.length && 0 === this._medianMinHeap.length ? this._medianMaxHeap.push(e) : e <= t ? (this._medianMaxHeap.push(e), this._medianMaxHeap.sort((function(e, t) {
            return t - e
        }))) : (this._medianMinHeap.push(e), this._medianMinHeap.sort((function(e, t) {
            return e - t
        }))), this._rebalanceHeaps(), this._fetchMedianPeriod()
    }, tt.prototype._rebalanceHeaps = function() {
        var e = null;
        this._medianMaxHeap.length > this._medianMinHeap.length + 1 ? (e = this._medianMaxHeap.shift(), this._medianMinHeap.push(e), this._medianMinHeap.sort((function(e, t) {
            return e - t
        }))) : this._medianMinHeap.length > this._medianMaxHeap.length + 1 && (e = this._medianMinHeap.shift(), this._medianMaxHeap.push(e), this._medianMaxHeap.sort((function(e, t) {
            return t - e
        }))), this._medianMinHeap.length == this._medianMaxHeap.length && this._medianMaxHeap.length > this._medianMaxHeapSize && (this._medianMinHeap.pop(), this._medianMaxHeap.pop())
    }, tt.prototype._fetchMedianPeriod = function() {
        return this._medianMaxHeap.length > this._medianMinHeap.length ? this._medianMaxHeap[0] : this._medianMinHeap.length > this._medianMaxHeap.length ? this._medianMinHeap[0] : 0 !== this._medianMaxHeap.length && 0 !== this._medianMinHeap.length ? (this._medianMaxHeap[0] + this._medianMinHeap[0]) / 2 : -1
    }, tt.prototype._cleanStaleData = function() {
        for (var e = Date.now() - this._baseTime, t = this._date.length - 1; t >= 0; t--) {
            if (e - this._date[t] >= this._interval) {
                this._date.splice(0, t + 1), this._data.splice(0, t + 1);
                break
            }
        }
    };
    var dt, ft = {
        UUID: function(e) {
            return /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/i.test(e) || !1
        },
        UUIDv4: function(e) {
            return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(e) || !1
        },
        URL: function(e) {
            var t = new RegExp("^(http|https)://"),
                n = new RegExp("^((?!(data|javascript):).)*$");
            return t.test(e) && n.test(e) && -1 === e.indexOf("#")
        },
        IMAGE: function(e) {
            return (0 === e.indexOf("https://") || 0 === e.indexOf("/")) && e.endsWith(".png")
        }
    };

    function mt(e) {
        var t, n, r = "string" == typeof e ? e : JSON.stringify(e),
            i = -1;
        for (dt = dt || function() {
                var e, t, n, r = [];
                for (t = 0; t < 256; t++) {
                    for (e = t, n = 0; n < 8; n++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
                    r[t] = e
                }
                return r
            }(), t = 0, n = r.length; t < n; t += 1) i = i >>> 8 ^ dt[255 & (i ^ r.charCodeAt(t))];
        return (-1 ^ i) >>> 0
    }
    var gt = {
        __proto__: null,
        createErrorsAggregator: Je,
        uuid: function() {
            return Math.random().toString(36).substr(2)
        },
        Render: Le,
        JWT: Ye,
        Color: Ie,
        Shuffle: Xe,
        MathUtil: et,
        Storage: ze,
        Query: $e,
        TimeBuffer: tt,
        PromiseUtil: {
            __proto__: null,
            promiseRecursive: nt,
            promiseRetry: rt,
            promiseRetryWithCancel: it,
            withTimeout: ot
        },
        ErrorUtil: Ge,
        UrlUtil: {
            __proto__: null,
            getFileExtension: at
        },
        HashUtil: {
            __proto__: null,
            generate: st,
            generateHex: lt,
            hexModulo: ct
        },
        _stackTraceSet: _e,
        refineLine: Me,
        toRefinedString: Fe,
        reportError: Pe,
        errorWrapper: Ze,
        initSentry: Ce,
        sentryMessage: Be,
        sentryError: De,
        sentryBreadcrumb: Ae,
        renderFallback: Te,
        forEachCaptchaNode: Se,
        callUserFunction: ht,
        composeParams: pt,
        is: ft,
        promiseRecursive: nt,
        promiseRetry: rt,
        promiseRetryWithCancel: it,
        withTimeout: ot,
        crc32: mt,
        TaskContext: {
            container: {},
            set: function(e, t) {
                this.container[e] = t
            },
            clear: function() {
                this.container = {}
            }
        },
        getFileExtension: at,
        generate: st,
        generateHex: lt,
        hexModulo: ct
    };

    function yt(e) {
        try {
            if (!e) throw new Error("Event object is required");
            if (e.touches || e.changedTouches) {
                var t = e.touches && e.touches.length >= 1 ? e.touches : e.changedTouches;
                if (t && t[0]) return t[0].x = t[0].clientX, t[0].y = t[0].clientY, t[0]
            }
            var n = "number" == typeof e.pageX && "number" == typeof e.pageY,
                r = "number" == typeof e.clientX && "number" == typeof e.clientY;
            return n ? {
                x: e.pageX,
                y: e.pageY
            } : r ? {
                x: e.clientX,
                y: e.clientY
            } : null
        } catch (pr) {
            return Be("DomEvent Coords Error", "error", "core", {
                error: pr,
                event: e
            }), null
        }
    }

    function Vt(e, t) {
        var n = e;
        "down" === e || "up" === e || "move" === e || "over" === e || "out" === e ? n = !(ee.System.mobile && "desktop" !== t || "mobile" === t) || "down" !== e && "up" !== e && "move" !== e ? "mouse" + e : "down" === e ? "touchstart" : "up" === e ? "touchend" : "touchmove" : "enter" === e && (n = "keydown");
        return n
    }

    function vt(e, t, n, r) {
        var i = Vt(t),
            o = t,
            a = 0,
            s = 0,
            l = t.indexOf("swipe") >= 0,
            c = 0;

        function u(e) {
            var t = yt(e);
            t && (a = t.pageX, s = t.pageY, c = Date.now())
        }

        function h(t) {
            var r = yt(t);
            if (r) {
                var o, l, u = r.pageX - a,
                    h = r.pageY - s,
                    p = Date.now() - c;
                if (!(p > 300) && (u <= -25 ? o = "swipeleft" : u >= 25 && (o = "swiperight"), h <= -25 ? l = "swipeup" : h >= 25 && (l = "swipedown"), i === o || i === l)) {
                    var d = o === i ? o : l;
                    t.action = d, t.targetElement = e, t.swipeSpeed = Math.sqrt(u * u + h * h) / p, t.deltaX = u, t.deltaY = h, n(t)
                }
            }
        }

        function p(r) {
            try {
                var i = function(e) {
                    var t = e ? e.type : "";
                    return "touchstart" === t || "mousedown" === t ? t = "down" : "touchmove" === t || "mousemove" === t ? t = "move" : "touchend" === t || "mouseup" === t ? t = "up" : "mouseover" === t ? t = "over" : "mouseout" === t && (t = "out"), t
                }(r);
                if ((r = r || window.event) && "object" == typeof r || Ae("DomEvent Missing.", "core", "info", r = {}), "down" === i || "move" === i || "up" === i || "over" === i || "out" === i || "click" === i) {
                    var o = yt(r);
                    if (!o) return;
                    var a = e.getBoundingClientRect();
                    r.windowX = o.x, r.windowY = o.y, r.elementX = r.windowX - (a.x || a.left), r.elementY = r.windowY - (a.y || a.top)
                }
                if (r.keyNum = r.which || r.keyCode || 0, "enter" === t && 13 !== r.keyNum && 32 !== r.keyNum) return;
                r.action = i, r.targetElement = e, n(r)
            } catch (pr) {
                Be("DomEvent Error", "error", "core", {
                    error: pr,
                    event: r
                })
            }
        }
        return r || (r = {}), l ? function() {
            if (!("addEventListener" in e)) return;
            e.addEventListener("mousedown", u, r), e.addEventListener("mouseup", h, r), e.addEventListener("touchstart", u, r), e.addEventListener("touchend", h, r)
        }() : function() {
            if (!("addEventListener" in e)) return void e.attachEvent("on" + i, p);
            e.addEventListener(i, p, r)
        }(), {
            event: i,
            rawEvent: o,
            callback: n,
            remove: function() {
                l ? (e.removeEventListener("mousedown", u, r), e.removeEventListener("mouseup", h, r), e.removeEventListener("touchstart", u, r), e.removeEventListener("touchend", h, r)) : "removeEventListener" in e ? e.removeEventListener(i, p, r) : e.detachEvent("on" + i, p)
            }
        }
    }
    var bt = ["Webkit", "Moz", "ms"],
        Rt = document.createElement("div").style,
        wt = {};

    function Tt(e) {
        var t = wt[e];
        return t || (e in Rt ? e : wt[e] = function(e) {
            for (var t = e[0].toUpperCase() + e.slice(1), n = bt.length; n--;)
                if ((e = bt[n] + t) in Rt) return e
        }(e) || e)
    }

    function St(e, t, n) {
        if (this.dom = null, this._clss = [], this._nodes = [], this._listeners = [], this._frag = null, e && "object" == typeof e) {
            this.dom = e;
            var r = [],
                i = [];
            "string" == typeof e.className && (i = e.className.split(" "));
            for (var o = 0; o < i.length; o++) "" !== i[o] && " " !== i[o] && r.push(i[o]);
            this._clss = r
        } else n !== undefined && null !== n || (n = !0), (!e || "string" == typeof e && (e.indexOf("#") >= 0 || e.indexOf(".") >= 0)) && (e && (t = e), e = "div"), this.dom = document.createElement(e), t && (t.indexOf("#") >= 0 ? this.dom.id = t.split("#")[1] : (t.indexOf(".") >= 0 && (t = t.split(".")[1]), this.addClass.call(this, t)));
        !0 === n && (this._frag = document.createDocumentFragment(), this._frag.appendChild(this.dom))
    }
    St.prototype.cloneNode = function(e) {
        try {
            return this.dom.cloneNode(e)
        } catch (dr) {
            return De("element", dr), null
        }
    }, St.prototype.createElement = function(e, t) {
        try {
            var n = new St(e, t, !1);
            return this.appendElement.call(this, n), this._nodes.push(n), n
        } catch (dr) {
            return De("element", dr), null
        }
    }, St.prototype.appendElement = function(e) {
        if (e === undefined) return Pe({
            name: "DomElement Add Child",
            message: "Child Element is undefined"
        });
        var t;
        t = e._frag !== undefined && null !== e._frag ? e._frag : e.dom !== undefined ? e.dom : e;
        try {
            e instanceof St && (e._parent = this), this.dom.appendChild(t)
        } catch (dr) {
            Pe({
                name: "DomElement Add Child",
                message: "Failed to append child."
            })
        }
        return this
    }, St.prototype.removeElement = function(e) {
        try {
            var t;
            if (e._nodes)
                for (t = e._nodes.length; t--;) e.removeElement(e._nodes[t]);
            for (t = this._nodes.length; --t > -1;) this._nodes[t] === e && this._nodes.splice(t, 1);
            var n = e instanceof St ? e.dom : e,
                r = n.parentNode === this.dom ? this.dom : n.parentNode;
            if (r.removeChild && r.removeChild(n), !r) throw new Error("Child component does not have correct setup");
            e.__destroy && e.__destroy()
        } catch (dr) {
            Pe({
                name: "DomElement Remove Child",
                message: dr.message || "Failed to remove child."
            })
        }
    }, St.prototype.addClass = function(e) {
        return !1 === this.hasClass.call(this, e) && (this._clss.push(e), this.dom.className = this._clss.join(" ")), this
    }, St.prototype.hasClass = function(e) {
        for (var t = -1 !== this.dom.className.split(" ").indexOf(e), n = this._clss.length; n-- && !t;) t = this._clss[n] === e;
        return t
    }, St.prototype.removeClass = function(e) {
        for (var t = this._clss.length; --t > -1;) this._clss[t] === e && this._clss.splice(t, 1);
        return this.dom.className = this._clss.join(" "), this
    }, St.prototype.text = function(e) {
        if (this && this.dom) {
            if (!e) return this.dom.textContent;
            for (var t, n, r, i, o = /&(.*?);/g, a = /<[a-z][\s\S]*>/i; null !== (t = o.exec(e));) {
                !1 === a.test(t[0]) ? (r = t[0], i = void 0, (i = document.createElement("div")).innerHTML = r, n = i.textContent, e = e.replace(new RegExp(t[0], "g"), n)) : e = e.replace(t[0], "")
            }
            return this.dom.textContent = e, this
        }
    }, St.prototype.content = St.prototype.text, St.prototype.css = function(e) {
        var t, n = "ie" === ee.Browser.type && 8 === ee.Browser.version,
            r = "safari" === ee.Browser.type && 12 === Math.floor(ee.Browser.version);
        for (var i in e) {
            t = e[i];
            try {
                if ("transition" === i && r) continue;
                "opacity" !== i && "zIndex" !== i && "fontWeight" !== i && isFinite(t) && parseFloat(t) === t && (t += "px");
                var o = Tt(i);
                n && "opacity" === i ? this.dom.style.filter = "alpha(opacity=" + 100 * t + ")" : n && Ie.hasAlpha(t) ? this.dom.style[o] = new Ie(t).getHex() : this.dom.style[o] = t
            } catch (pr) {}
        }
        return this
    }, St.prototype.backgroundImage = function(e, t, n, r) {
        var i = t !== undefined && n !== undefined,
            o = {
                "-ms-high-contrast-adjust": "none"
            };
        if ("object" == typeof t && (r = t), r === undefined && (r = {}), i) {
            var a = e.width / e.height,
                s = t,
                l = s / a;
            r.cover && l < n && (s = (l = n) * a), r.contain && l > n && (s = (l = n) * a), o.width = s, o.height = l, r.center && (o.marginLeft = -s / 2, o.marginTop = -l / 2, o.position = "absolute", o.left = "50%", o.top = "50%"), (r.left || r.right) && (o.left = r.left || 0, o.top = r.top || 0)
        }
        "ie" === ee.Browser.type && 8 === ee.Browser.version ? o.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + e.src + "',sizingMethod='scale')" : (o.background = "url(" + e.src + ")", o.backgroundPosition = "50% 50%", o.backgroundRepeat = "no-repeat", o.backgroundSize = i ? s + "px " + l + "px" : r.cover ? "cover" : r.contain ? "contain" : "100%"), this.css.call(this, o)
    }, St.prototype.setAttribute = function(e, t) {
        var n;
        if ("object" == typeof e)
            for (var r in e) n = e[r], this.dom.setAttribute(r, n);
        else this.dom.setAttribute(e, t)
    }, St.prototype.removeAttribute = function(e, t) {
        var n;
        if ("object" == typeof e)
            for (var r in e) n = e[r], this.dom.removeAttribute(r, n);
        else this.dom.removeAttribute(e, t)
    }, St.prototype.addEventListener = function(e, t, n) {
        var r = new vt(this.dom, e, t, n);
        if (this._listeners.push(r), e !== r.event && (r.event.indexOf("mouse") >= 0 || r.event.indexOf("touch") >= 0)) {
            var i = Vt(e, r.event.indexOf("touch") >= 0 ? "desktop" : "mobile");
            if (i === r.event) return;
            this.addEventListener.call(this, i, t, n)
        }
    }, St.prototype.removeEventListener = function(e, t, n) {
        for (var r, i = this._listeners.length, o = Vt(e); --i > -1;)(r = this._listeners[i]).event === o && r.callback === t && (this._listeners.splice(i, 1), r.remove())
    }, St.prototype.focus = function() {
        this.dom.focus()
    }, St.prototype.blur = function() {
        this.dom.blur()
    }, St.prototype.html = function(e) {
        return e && (this.dom.innerHTML = e), this.dom.innerHTML
    }, St.prototype.__destroy = function() {
        for (var e, t = this._listeners.length; --t > -1;) e = this._listeners[t], this._listeners.splice(t, 1), this.dom.removeEventListener ? this.dom.removeEventListener(e.event, e.handler) : this.dom.detachEvent("on" + e.event, e.handler);
        return this.dom = null, this._clss = [], this._nodes = [], this._listeners = [], this._frag = null, e = null, null
    }, St.prototype.isConnected = function() {
        return !!this.dom && ("isConnected" in this.dom ? this.dom.isConnected : !(this.dom.ownerDocument && this.dom.ownerDocument.compareDocumentPosition(this.dom) & this.dom.DOCUMENT_POSITION_DISCONNECTED))
    };
    var Et = {
        eventName: function(e, t) {
            var n = e;
            "down" === e || "up" === e || "move" === e || "over" === e || "out" === e ? n = !(ee.System.mobile && "desktop" !== t || "mobile" === t) || "down" !== e && "up" !== e && "move" !== e ? "mouse" + e : "down" === e ? "touchstart" : "up" === e ? "touchend" : "touchmove" : "enter" === e && (n = "keydown");
            return n
        },
        actionName: function(e) {
            var t = e;
            return "touchstart" === t || "mousedown" === t ? t = "down" : "touchmove" === t || "mousemove" === t ? t = "move" : "touchend" === t || "mouseup" === t ? t = "up" : "mouseover" === t ? t = "over" : "mouseout" === t && (t = "out"), t
        },
        eventCallback: function(e, t, n) {
            var r = Et.actionName(e);
            return function(i) {
                try {
                    if (i = i || window.event, "down" === r || "move" === r || "up" === r || "over" === r || "out" === r || "click" === r) {
                        var o = Et.eventCoords(i);
                        if (!o) return;
                        var a = n.getBoundingClientRect();
                        i.windowX = o.x, i.windowY = o.y, i.elementX = i.windowX - (a.x || a.left), i.elementY = i.windowY - (a.y || a.top)
                    }
                    if (i.keyNum = i.which || i.keyCode || 0, "enter" === e && 13 !== i.keyNum && 32 !== i.keyNum) return;
                    i.action = r, i.targetElement = n, t(i)
                } catch (pr) {
                    Be("Normalize Error", "error", "core", {
                        error: pr
                    })
                }
            }
        },
        eventCoords: function(e) {
            try {
                if (!e) throw new Error("Event object is required");
                var t = e;
                if (e.touches || e.changedTouches) {
                    var n = e.touches && e.touches.length >= 1 ? e.touches : e.changedTouches;
                    n && n[0] && (t = n[0])
                }
                return "number" == typeof t.pageX && "number" == typeof t.pageY ? {
                    x: t.pageX,
                    y: t.pageY
                } : "number" == typeof t.clientX && "number" == typeof t.clientY ? {
                    x: t.clientX,
                    y: t.clientY
                } : null
            } catch (pr) {
                return Be("Normalize Coords Error", "error", "core", {
                    error: pr,
                    event: e
                }), null
            }
        }
    };

    function _t(e) {
        if (null === e) return "";
        var t = [];
        return kt(e, t), t.join("&")
    }

    function kt(e, t) {
        var n, r;
        if ("object" == typeof e)
            for (r in e) !0 === Ut(n = e[r]) ? kt(n, t) : t[t.length] = xt(r, n);
        else if (!0 === Array.isArray(e))
            for (var i = 0; i < e.length; i++) !0 === Ut(n = e[i]) ? kt(e, t) : t[t.length] = xt(r, n);
        else t[t.length] = xt(e)
    }

    function Ut(e) {
        return !0 === Array.isArray(e) || "object" == typeof e
    }

    function xt(e, t) {
        return encodeURIComponent(e) + "=" + encodeURIComponent(null === t ? "" : t)
    }
    var Wt = {
            af: "Afrikaans",
            sq: "Albanian",
            am: "Amharic",
            ar: "Arabic",
            hy: "Armenian",
            az: "Azerbaijani",
            eu: "Basque",
            be: "Belarusian",
            bn: "Bengali",
            bg: "Bulgarian",
            bs: "Bosnian",
            my: "Burmese",
            ca: "Catalan",
            ceb: "Cebuano",
            zh: "Chinese",
            "zh-CN": "Chinese Simplified",
            "zh-TW": "Chinese Traditional",
            co: "Corsican",
            hr: "Croatian",
            cs: "Czech",
            da: "Danish",
            nl: "Dutch",
            en: "English",
            eo: "Esperanto",
            et: "Estonian",
            fi: "Finnish",
            fr: "French",
            fy: "Frisian",
            gd: "Gaelic",
            gl: "Galacian",
            ka: "Georgian",
            de: "German",
            el: "Greek",
            gu: "Gujurati",
            ht: "Haitian",
            ha: "Hausa",
            haw: "Hawaiian",
            he: "Hebrew",
            hi: "Hindi",
            hmn: "Hmong",
            hu: "Hungarian",
            is: "Icelandic",
            ig: "Igbo",
            id: "Indonesian",
            ga: "Irish",
            it: "Italian",
            ja: "Japanese",
            jw: "Javanese",
            kn: "Kannada",
            kk: "Kazakh",
            km: "Khmer",
            rw: "Kinyarwanda",
            ky: "Kirghiz",
            ko: "Korean",
            ku: "Kurdish",
            lo: "Lao",
            la: "Latin",
            lv: "Latvian",
            lt: "Lithuanian",
            lb: "Luxembourgish",
            mk: "Macedonian",
            mg: "Malagasy",
            ms: "Malay",
            ml: "Malayalam",
            mt: "Maltese",
            mi: "Maori",
            mr: "Marathi",
            mn: "Mongolian",
            ne: "Nepali",
            no: "Norwegian",
            ny: "Nyanja",
            or: "Oriya",
            fa: "Persian",
            pl: "Polish",
            "pt-BR": "Portuguese (Brazil)",
            pt: "Portuguese (Portugal)",
            ps: "Pashto",
            pa: "Punjabi",
            ro: "Romanian",
            ru: "Russian",
            sm: "Samoan",
            sn: "Shona",
            sd: "Sindhi",
            si: "Sinhalese",
            sr: "Serbian",
            sk: "Slovak",
            sl: "Slovenian",
            so: "Somali",
            st: "Southern Sotho",
            es: "Spanish",
            su: "Sundanese",
            sw: "Swahili",
            sv: "Swedish",
            tl: "Tagalog",
            tg: "Tajik",
            ta: "Tamil",
            tt: "Tatar",
            te: "Teluga",
            th: "Thai",
            tr: "Turkish",
            tk: "Turkmen",
            ug: "Uyghur",
            uk: "Ukrainian",
            ur: "Urdu",
            uz: "Uzbek",
            vi: "Vietnamese",
            cy: "Welsh",
            xh: "Xhosa",
            yi: "Yiddish",
            yo: "Yoruba",
            zu: "Zulu"
        },
        Mt = {
            zh: {
                "I am human": "我是真实访客"
            },
            ar: {
                "I am human": "أنا الإنسان"
            },
            af: {
                "I am human": "Ek is menslike"
            },
            am: {
                "I am human": "እኔ ሰው ነኝ"
            },
            hy: {
                "I am human": "Ես մարդ եմ"
            },
            az: {
                "I am human": "Mən insanam"
            },
            eu: {
                "I am human": "Gizakia naiz"
            },
            bn: {
                "I am human": "আমি মানব নই"
            },
            bg: {
                "I am human": "Аз съм човек"
            },
            ca: {
                "I am human": "Sóc humà"
            },
            hr: {
                "I am human": "Ja sam čovjek"
            },
            cs: {
                "I am human": "Jsem člověk"
            },
            da: {
                "I am human": "Jeg er et menneske"
            },
            nl: {
                "I am human": "Ik ben een mens"
            },
            et: {
                "I am human": "Ma olen inimeste"
            },
            fi: {
                "I am human": "Olen ihminen"
            },
            fr: {
                "I am human": "Je suis humain"
            },
            gl: {
                "I am human": "Eu son humano"
            },
            ka: {
                "I am human": "მე ვარ ადამიანი"
            },
            de: {
                "I am human": "Ich bin ein Mensch"
            },
            el: {
                "I am human": "Είμαι άνθρωπος"
            },
            gu: {
                "I am human": "હું માનવ છું"
            },
            iw: {
                "I am human": ". אני אנושי"
            },
            hi: {
                "I am human": "मैं मानव हूं"
            },
            hu: {
                "I am human": "Nem vagyok robot"
            },
            is: {
                "I am human": "Ég er manneskja"
            },
            id: {
                "I am human": "Aku manusia"
            },
            it: {
                "I am human": "Sono un essere umano"
            },
            ja: {
                "I am human": "私は人間です"
            },
            kn: {
                "I am human": "ನಾನು ಮಾನವನು"
            },
            ko: {
                "I am human": "사람입니다"
            },
            lo: {
                "I am human": "ຂ້ອຍເປັນມະນຸດ"
            },
            lv: {
                "I am human": "Es esmu cilvēks"
            },
            lt: {
                "I am human": "Aš esu žmogaus"
            },
            ms: {
                "I am human": "Saya manusia"
            },
            ml: {
                "I am human": "ഞാൻ മനുഷ്യനാണ്"
            },
            mr: {
                "I am human": "मी मानवी आहे"
            },
            mn: {
                "I am human": "Би бол хүн"
            },
            no: {
                "I am human": "Jeg er et menneske"
            },
            fa: {
                "I am human": "من انسانی هستم"
            },
            pl: {
                "I am human": "Jestem człowiekiem"
            },
            pt: {
                "I am human": "Sou humano"
            },
            ro: {
                "I am human": "Eu sunt om"
            },
            ru: {
                "I am human": "Я человек"
            },
            sr: {
                "I am human": "Ja sam ljudski"
            },
            si: {
                "I am human": "මම මිනිස්සු"
            },
            sk: {
                "I am human": "Ja som človek"
            },
            sl: {
                "I am human": "Jaz sem človeški"
            },
            es: {
                "I am human": "Soy humano"
            },
            sw: {
                "I am human": "Mimi ni binadamu"
            },
            sv: {
                "I am human": "Jag är människa"
            },
            ta: {
                "I am human": "நான் மனித"
            },
            te: {
                "I am human": "నేను మనిషిని"
            },
            th: {
                "I am human": "ผมมนุษย์"
            },
            tr: {
                "I am human": "Ben bir insanım"
            },
            uk: {
                "I am human": "Я людини"
            },
            ur: {
                "I am human": "میں انسان ہوں"
            },
            vi: {
                "I am human": "Tôi là con người"
            },
            zu: {
                "I am human": "Ngingumuntu"
            }
        },
        Ft = null,
        Nt = "ltr",
        Pt = {
            translate: function(e, t) {
                var n = Pt.getBestTrans(Mt),
                    r = n && n[e];
                if (r = r || e, t)
                    for (var i = Object.keys(t), o = i.length; o--;) r = r.replace(new RegExp("{{" + i[o] + "}}", "g"), t[i[o]]);
                return r
            },
            getBestTrans: function(e) {
                var t = Pt.getLocale();
                return t in e ? e[t] : Pt.getShortLocale(t) in e ? e[Pt.getShortLocale(t)] : "en" in e ? e.en : null
            },
            resolveLocale: function(e) {
                var t = Pt.getShortLocale(e);
                return "in" === t && (e = "id"), "iw" === t && (e = "he"), "nb" === t && (e = "no"), "ji" === t && (e = "yi"), "zh-CN" === e && (e = "zh"), "jv" === t && (e = "jw"), "me" === t && (e = "bs"), Wt[e] ? e : Wt[t] ? t : "en"
            },
            getLocale: function() {
                return Pt.resolveLocale(Ft || window.navigator.userLanguage || window.navigator.language)
            },
            setLocale: function(e) {
                "zh-Hans" === e ? e = "zh-CN" : "zh-Hant" === e && (e = "zh-TW"), Ft = e
            },
            getShortLocale: function(e) {
                return e.indexOf("-") >= 0 ? e.substring(0, e.indexOf("-")) : e
            },
            getLangName: function(e) {
                return Wt[e]
            },
            isShortLocale: function(e) {
                return 2 === e.length || 3 === e.length
            },
            addTable: function(e, t) {
                if (t || (t = Object.create(null)), Mt[e]) {
                    var n = Mt[e];
                    for (var r in t) n[r] = t[r]
                } else Mt[e] = t;
                return Mt[e]
            },
            getTable: function(e) {
                return Mt[e]
            },
            addTables: function(e) {
                for (var t in e) Pt.addTable(t, e[t]);
                return Mt
            },
            getTables: function() {
                return Mt
            },
            getDirection: function() {
                return Nt || "ltr"
            },
            isRTL: function() {
                return "rtl" === Nt
            },
            setDirection: function(e, t) {
                var n = t.split("-")[0];
                Nt = -1 !== ["ar", "he", "fa", "ur", "ps", "dv", "yi"].indexOf(n) ? "rtl" : "ltr", e.setAttribute("dir", Nt || "ltr"), "ltr" === Nt ? e.css({
                    direction: "ltr",
                    textAlign: "left"
                }) : e.css({
                    direction: "rtl",
                    textAlign: "right"
                })
            }
        },
        Zt = {
            400: "Rate limited or network error. Please retry.",
            429: "Your computer or network has sent too many requests.",
            500: "Cannot contact hCaptcha. Check your connection and try again."
        },
        Ot = function(e) {
            try {
                return Pt.translate(Zt[e])
            } catch (dr) {
                return !1
            }
        },
        jt = "undefined" != typeof XDomainRequest && !("withCredentials" in XMLHttpRequest.prototype);

    function Ct(e, t, n) {
        n = n || {};
        var r = {
            url: t,
            method: e.toUpperCase(),
            responseType: n.responseType || "string",
            dataType: n.dataType || null,
            withCredentials: n.withCredentials || !1,
            headers: n.headers || null,
            data: n.data || null,
            timeout: n.timeout || null,
            pst: n.pst || null
        };
        r.legacy = r.withCredentials && jt;
        var i = "fetch" in window && r.pst ? Dt : Bt;
        return n.retry ? (n.retry.cancellable || !1 ? it : rt)((function() {
            return n.data && (r.data = "function" == typeof n.data ? n.data() : n.data, "json" === r.dataType && "object" == typeof r.data ? r.data = JSON.stringify(r.data) : "query" === r.dataType && (r.data = _t(r.data))), i(r)
        }), n.retry) : (n.data && (r.data = "function" == typeof n.data ? n.data() : n.data, "json" === r.dataType && "object" == typeof r.data ? r.data = JSON.stringify(r.data) : "query" === r.dataType && (r.data = _t(r.data))), i(r))
    }

    function Bt(e) {
        var t = e.legacy ? new XDomainRequest : new XMLHttpRequest,
            n = "function" == typeof e.url ? e.url() : e.url;
        return new Promise((function(r, i) {
            var o, a = function(o) {
                return function() {
                    var a = t.response,
                        s = t.statusText || "",
                        l = t.status,
                        c = t.readyState;
                    if (a || "" !== t.responseType && "text" !== t.responseType || (a = t.responseText), 4 === c || e.legacy) {
                        try {
                            if (a) {
                                var u = t.contentType;
                                t.getResponseHeader && (u = t.getResponseHeader("content-type"));
                                var h = -1 !== (u = u ? u.toLowerCase() : "").indexOf("application/json");
                                if ("ArrayBuffer" in window && a instanceof ArrayBuffer && h && (a = (new TextDecoder).decode(new Uint8Array(a))), "string" == typeof a) try {
                                    a = JSON.parse(a)
                                } catch (p) {
                                    h && De("http", p, {
                                        url: n,
                                        config: e,
                                        responseType: t.responseType,
                                        contentType: u,
                                        response: a
                                    })
                                }
                            }
                        } catch (p) {
                            return De("http", p, {
                                contentType: u
                            }), void i({
                                event: ce,
                                endpoint: n,
                                response: a,
                                state: c,
                                status: l,
                                message: Ot(l || 400) || s
                            })
                        }
                        if ("error" === o || l >= 400 && l <= 511) return void i({
                            event: ce,
                            endpoint: n,
                            response: a,
                            state: c,
                            status: l,
                            message: 409 === l && a.error || Ot(l || 400) || s
                        });
                        r({
                            state: c,
                            status: l,
                            body: a,
                            message: s
                        })
                    }
                }
            };
            if ((t.onload = a("complete"), t.onerror = t.ontimeout = a("error"), t.open(e.method, n), "arraybuffer" === e.responseType && (!e.legacy && "TextDecoder" in window && "ArrayBuffer" in window ? t.responseType = "arraybuffer" : (e.responseType = "json", e.headers.accept = "application/json")), e.timeout && (t.timeout = "function" == typeof e.timeout ? e.timeout(n) : e.timeout), !e.legacy) && (t.withCredentials = e.withCredentials, e.headers))
                for (var s in e.headers) o = e.headers[s], t.setRequestHeader(s, o);
            setTimeout((function() {
                t.send(e.data)
            }), 0)
        }))
    }

    function Dt(e) {
        var t, n = "function" == typeof e.url ? e.url() : e.url,
            r = new Headers;
        if ("json" === e.responseType && r.set("content-type", "application/json"), e.headers)
            for (var i in e.headers) t = e.headers[i], r.set(i, t);
        var o = {
            method: e.method,
            credentials: "include",
            body: e.data,
            headers: r
        };
        if (e.pst) {
            var a = {};
            "token-request" === e.pst ? a = {
                version: 1,
                operation: "token-request"
            } : "token-redemption" === e.pst ? a = {
                version: 1,
                operation: "token-redemption",
                refreshPolicy: "refresh"
            } : "send-redemption-record" === e.pst && (a = {
                version: 1,
                operation: "send-redemption-record",
                issuers: [ve.pstIssuer]
            }), o.privateToken = a
        }
        return new Promise((function(t, r) {
            fetch(n, o).then((function(i) {
                return 200 !== i.status ? r({
                    event: ce,
                    endpoint: n,
                    response: i,
                    state: 4,
                    status: i.status,
                    message: Ot(i.status || 400)
                }) : ("arraybuffer" === e.responseType ? i.arrayBuffer() : "json" === e.responseType ? i.json() : i.text()).then((function(e) {
                    t({
                        state: 4,
                        status: i.status,
                        body: e,
                        message: Ot(i.status || 400)
                    })
                }))
            }))["catch"]((function(e) {
                r({
                    event: ce,
                    endpoint: n,
                    response: e.error,
                    state: 4,
                    status: 400,
                    message: Ot(400)
                })
            }))
        }))
    }
    var At = function(e, t) {
            if ("object" == typeof e && t === undefined && (e = (t = e).url), null === e) throw new Error("Url missing");
            return Ct("GET", e, t)
        },
        Gt = ["svg", "gif", "png"];

    function Jt(e, t) {
        t = t || {};
        var n, r = e;
        if (0 === r.indexOf("data:image"))
            for (var i = !1, o = Gt.length, a = -1; a++ < o && !i;)(i = r.indexOf(Gt[a]) >= 0) && (n = Gt[a]);
        else n = r.substr(r.lastIndexOf(".") + 1, r.length);
        !!(!document.createElementNS || !document.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect) && t.fallback && (t.fallback.indexOf(".") >= 0 ? n = (r = t.fallback).substr(r.lastIndexOf(".") + 1, r.length) : (r = e.substr(0, e.indexOf(n)) + t.fallback, n = t.fallback)), t.prefix && (r = t.prefix + "/" + r), this.attribs = {
            crossOrigin: t.crossOrigin || null
        }, this.id = r, this.src = function(e) {
            if (ve.assethost && 0 === e.indexOf(Ve.assetDomain)) return ve.assethost + e.replace(Ve.assetDomain, "");
            if (ve.imghost && e.indexOf("imgs") >= 0) {
                var t = e.indexOf(".ai") >= 0 ? e.indexOf(".ai") + 3 : e.indexOf(".com") + 4;
                return ve.imghost + e.substr(t, e.length)
            }
            return e
        }(r), this.ext = n, this.width = 0, this.height = 0, this.aspect = 0, this.loaded = !1, this.error = !1, this.element = null, this.cb = {
            load: [],
            error: []
        }
    }

    function zt(e, t, n) {
        for (var r = e[t], i = r.length, o = null; --i > -1;) o = r[i], r.splice(i, 1), o(n);
        "error" === t ? e.load = [] : e.error = []
    }

    function Xt(e, t) {
        var n = e;
        t || (t = {}), t.prefix && (n = t.prefix + "/" + e), this.attribs = {
            defer: t.defer || null,
            async: t.async || null,
            crossOrigin: t.crossOrigin || null,
            integrity: t.integrity || null
        }, this.id = n, this.src = function(e) {
            if (ve.assethost && 0 === e.indexOf(Ve.assetDomain)) return ve.assethost + e.replace(Ve.assetDomain, "");
            return e
        }(n), this.loaded = !1, this.error = !1, this.element = null, this.cb = {
            load: [],
            error: []
        }
    }

    function It(e, t, n) {
        for (var r = e[t], i = r.length, o = null; --i > -1;) o = r[i], r.splice(i, 1), o(n);
        "error" === t ? e.load = [] : e.error = []
    }

    function Kt(e, t) {
        var n = e;
        t || (t = {}), t.prefix && (n = t.prefix + "/" + e), this.responseType = t.responseType, this.id = n, this.src = function(e) {
            if (ve.assethost && 0 === e.indexOf(Ve.assetDomain)) return ve.assethost + e.replace(Ve.assetDomain, "");
            return e
        }(n), this.loaded = !1, this.error = !1, this.cb = {
            load: [],
            error: []
        }, this.data = null
    }

    function Yt(e, t, n) {
        for (var r = e[t], i = r.length, o = null; --i > -1;) o = r[i], r.splice(i, 1), o(n);
        "error" === t ? e.load = [] : e.error = []
    }

    function Lt(e, t) {
        t = t || {}, this._videoElement = document.createElement("video"), this.attribs = {
            crossOrigin: t.crossOrigin || null
        };
        var n, r = e;
        n = "probably" === this._videoElement.canPlayType('video/webm; codecs="vp9, opus"') || "probably" === this._videoElement.canPlayType('video/webm; codecs="vp8, vorbis"') ? "webm" : "mp4", t.prefix && (r = t.prefix + "/" + r), this.id = r, this.src = function(e) {
            if (ve.assethost && 0 === e.indexOf(Ve.assetDomain)) return ve.assethost + e.replace(Ve.assetDomain, "");
            if (ve.imghost && e.indexOf("imgs") >= 0) {
                var t = e.indexOf(".ai") >= 0 ? e.indexOf(".ai") + 3 : e.indexOf(".com") + 4;
                return ve.imghost + e.substr(t, e.length)
            }
            return e
        }(r), this.ext = n, this.width = 0, this.height = 0, this.aspect = 0, this.loaded = !1, this.error = !1, this.element = null, this.callbacks = {
            load: [],
            error: []
        }
    }

    function Ht(e, t, n) {
        for (var r = e[t], i = r.length, o = null; --i > -1;) o = r[i], r.splice(i, 1), o(n);
        "error" === t ? e.load = [] : e.error = []
    }
    Jt.prototype.load = function() {
        return ("svg" === this.ext ? this._loadSvg() : this._loadImg())["catch"]((function(e) {
            throw Be("Asset failed", "error", "assets", {
                error: e
            }), e
        }))
    }, Jt.prototype._loadSvg = function() {
        var e, t = this,
            n = this.src,
            r = this.id;
        if (0 === n.indexOf("data:image/svg+xml")) {
            var i = n.slice("data:image/svg+xml,".length);
            e = Promise.resolve(decodeURIComponent(i))
        } else e = At(n).then((function(e) {
            return e.body
        }));
        return e.then((function(e) {
            var n = (new DOMParser).parseFromString(e, "image/svg+xml").documentElement,
                r = parseInt(n.getAttribute("width")),
                i = parseInt(n.getAttribute("height"));
            return t._imgLoaded(n, r, i), t
        }))["catch"]((function(e) {
            t.error = !0;
            var n = (e && e.message ? e.message : e || "Loading Error") + ": " + r;
            throw zt(t.cb, "error", n), n
        }))
    }, Jt.prototype._loadImg = function() {
        var e = this,
            t = this.attribs,
            n = this.src,
            r = this.id;
        return new Promise((function(i, o) {
            function a() {
                e.loaded || (e._imgLoaded(s, s.width, s.height), s.onload = s.onerror = null, i(e))
            }
            var s = new Image;
            t.crossOrigin && (s.crossOrigin = t.crossOrigin), s.onerror = function() {
                e.error = !0, s.onload = s.onerror = null;
                var t = "Loading Error: " + r;
                zt(e.cb, "error", t), o(t)
            }, s.onload = a, s.src = n, s.complete && a()
        }))
    }, Jt.prototype._imgLoaded = function(e, t, n) {
        this.element = new St(e), this.width = t, this.height = n, this.aspect = t / n, this.loaded = !0, zt(this.cb, "load", this)
    }, Jt.prototype.onload = function(e) {
        this.error || (this.loaded ? e(this) : this.cb.load.push(e))
    }, Jt.prototype.onerror = function(e) {
        this.loaded && !this.error || (this.error ? e(this) : this.cb.error.push(e))
    }, Xt.prototype.load = function() {
        var e = this,
            t = this.attribs,
            n = this.src,
            r = this.id;
        return new Promise((function(i, o) {
            var a = document.createElement("script");
            e.element = a, a.onerror = function() {
                e.error = !0, a.onload = a.onreadystatechange = a.onerror = null;
                var t = new Error("Loading Error: " + r);
                It(e.cb, "error", t), o(t)
            }, a.onload = a.onreadystatechange = function() {
                this.loaded || a.readyState && "loaded" !== a.readyState && "complete" !== a.readyState || (e.loaded = !0, a.onload = a.onreadystatechange = a.onerror = null, document.body.removeChild(a), It(e.cb, "load", e), i(e))
            }, a.type = "text/javascript", a.src = n, t.crossOrigin && (a.crossorigin = t.crossOrigin), t.async && (a.async = !0), t.defer && (a.defer = !0), t.integrity && (a.integrity = t.integrity), document.body.appendChild(a), a.complete && a.onload()
        }))
    }, Xt.prototype.onload = function(e) {
        this.error || (this.loaded ? e(this) : this.cb.load.push(e))
    }, Xt.prototype.onerror = function(e) {
        this.loaded && !this.error || (this.error ? e(this) : this.cb.error.push(e))
    }, Kt.prototype.load = function() {
        var e = this,
            t = this.src,
            n = this.id;
        return new Promise((function(r, i) {
            var o = {};
            "arraybuffer" === e.responseType ? o.responseType = "arraybuffer" : t.indexOf("json") >= 0 && (o.responseType = "json"), At(t, o).then((function(t) {
                e.loaded = !0, e.data = t.body, Yt(e.cb, "load", e), r(e)
            }))["catch"]((function(t) {
                e.error = !0;
                var r = (t && t.message ? t.message : "Loading Error") + ": " + n;
                Yt(e.cb, "error", r), i(r)
            }))
        }))
    }, Kt.prototype.onload = function(e) {
        this.error || (this.loaded ? e(this) : this.cb.load.push(e))
    }, Kt.prototype.onerror = function(e) {
        this.loaded && !this.error || (this.error ? e(this) : this.cb.error.push(e))
    }, Lt.prototype.load = function() {
        var e = this,
            t = this.attribs,
            n = this.src,
            r = this.id;
        return new Promise((function(i, o) {
            var a = e._videoElement;
            t.crossOrigin && (a.crossOrigin = t.crossOrigin), a.playsInline = !0, a.preload = "metadata", "ios" === ee.System.os && a.setAttribute("webkit-playsinline", ""), a.src = n + "." + e.ext, a.onerror = function() {
                e.error = !0, a.onloadedmetadata = a.onerror = null;
                var t = "Loading Error: " + r;
                Ht(e.callbacks, "error", t), o(t)
            }, a.onloadedmetadata = function() {
                if (!e.loaded) {
                    var t = a.videoWidth,
                        n = a.videoHeight;
                    e.element = new St(a), e.width = t, e.height = n, e.aspect = t / n, e.loaded = !0, a.onloadedmetadata = a.onerror = null, Ht(e.callbacks, "load", e), i(e)
                }
            }, a.load()
        }))["catch"]((function(e) {
            throw Be("Asset failed", "error", "assets", {
                error: e
            }), e
        }))
    }, Lt.prototype.onload = function(e) {
        this.error || (this.loaded ? e(this) : this.callbacks.load.push(e))
    }, Lt.prototype.onerror = function(e) {
        this.loaded && !this.error || (this.error ? e(this) : this.callbacks.error.push(e))
    };
    var Qt = [],
        $t = function(e, t) {
            var n = new Kt(e, t);
            return Qt.push(n), n.load()
        },
        qt = function(e) {
            return new Promise((function(t, n) {
                for (var r = Qt.length, i = !1, o = null; --r > -1 && !i;) i = (o = Qt[r]).id === e || -1 !== o.id.indexOf("/" === e[0] ? "" : "/" + e);
                if (!i) return t(null);
                o.onload(t), o.onerror(n)
            }))
        },
        en = [],
        tn = !1,
        nn = !1;

    function rn() {
        document.addEventListener ? (document.addEventListener("DOMContentLoaded", an), window.addEventListener("load", an)) : (document.attachEvent("onreadystatechange", on), window.attachEvent("onload", an)), tn = !0
    }

    function on() {
        "interactive" !== document.readyState && "loaded" !== document.readyState && "complete" !== document.readyState || an()
    }

    function an() {
        if (!1 === nn) {
            for (var e = 0; e < en.length; e++) en[e].fn.apply(null, en[e].args);
            en = []
        }
        nn = !0, document.removeEventListener ? (document.removeEventListener("DOMContentLoaded", an), window.removeEventListener("load", an)) : (document.detachEvent("onreadystatechange", on), window.detachEvent("onload", an))
    }
    new St(document);
    var sn = new St(window),
        ln = {
            touchstart: "ts",
            touchend: "te",
            touchmove: "tm",
            touchcancel: "tc"
        },
        cn = {
            mousedown: "md",
            mouseup: "mu",
            mousemove: "mm"
        },
        un = {
            pointermove: "pm"
        },
        hn = {
            keydown: "kd",
            keyup: "ku"
        },
        pn = {
            devicemotion: "dm"
        },
        dn = function(e, t) {
            var n = cn[e],
                r = null;
            return function(e) {
                r = function(e) {
                    return [e.windowX, e.windowY, Date.now()]
                }(e), t(n, r)
            }
        },
        fn = function(e, t) {
            var n = un[e],
                r = null;
            return function(e) {
                r = function(e) {
                    var t = [],
                        n = [];
                    e.getCoalescedEvents && (n = e.getCoalescedEvents());
                    for (var r = 0; r < n.length; r++) {
                        var i = n[r];
                        t.push([i.x, i.y, Date.now()])
                    }
                    return t
                }(e);
                for (var i = 0; i < r.length; i++) t(n, r[i])
            }
        },
        mn = function(e, t) {
            var n = ln[e],
                r = null;
            return function(e) {
                r = function(e) {
                    var t = [];
                    try {
                        var n, r;
                        if (e.touches && e.touches.length >= 1 ? n = e.touches : e.changedTouches && e.changedTouches.length >= 1 && (n = e.changedTouches), n) {
                            for (var i = 0; i < n.length; i++)(r = Et.eventCoords(n[i])) && t.push([n[i].identifier, r.x, r.y]);
                            t.push(Date.now())
                        }
                        return t
                    } catch (dr) {
                        return t
                    }
                }(e), t(n, r)
            }
        },
        gn = function(e, t) {
            var n = hn[e],
                r = null;
            return function(e) {
                r = function(e) {
                    return [e.keyNum, Date.now()]
                }(e), t(n, r)
            }
        },
        yn = function(e, t) {
            var n = pn[e],
                r = null,
                i = [];
            return function(e) {
                r = function(e, t) {
                    (e.acceleration === undefined || e.acceleration && e.acceleration.x === undefined) && (e.acceleration = {
                        x: 0,
                        y: 0,
                        z: 0
                    });
                    (e.rotationRate === undefined || e.rotationRate && e.rotationRate.alpha === undefined) && (e.rotationRate = {
                        alpha: 0,
                        beta: 0,
                        gamma: 0
                    });
                    var n = [e.acceleration.x, e.acceleration.y, e.acceleration.z, e.rotationRate.alpha, e.rotationRate.beta, e.rotationRate.gamma, Date.now()],
                        r = [];
                    if (0 === t.length) t = n, r = n;
                    else {
                        for (var i, o = 0, a = 0; a < 6; a++) i = t[a] - n[a], r.push(n[a]), o += Math.abs(i);
                        if (r.push(Date.now()), t = n, o <= 0) return null
                    }
                    return {
                        motion: r,
                        prevmotion: t
                    }
                }(e, i), null !== r && (i = r.prevmotion, r = r.motion, t(n, r))
            }
        };

    function Vn() {
        this._manifest = {}, this.state = {
            timeBuffers: {},
            loadTime: Date.now(),
            recording: !1,
            initRecord: !1,
            record: {
                mouse: !0,
                touch: !0,
                keys: !1,
                motion: !1
            }
        }, this._recordEvent = this._recordEvent.bind(this)
    }
    Vn.prototype.record = function(e, t, n, r) {
        if (this._manifest.st = Date.now(), this.state.record.mouse = e === undefined ? this.state.record.mouse : e, this.state.record.touch = n === undefined ? this.state.record.touch : n, this.state.record.keys = t === undefined ? this.state.record.keys : t, this.state.record.motion = r === undefined ? this.state.record.motion : r, !1 === this.state.initRecord) {
            var i = new St(document.body);
            this.state.record.mouse && (i.addEventListener("mousedown", dn("mousedown", this._recordEvent), !0), i.addEventListener("mousemove", dn("mousemove", this._recordEvent), !0), i.addEventListener("mouseup", dn("mouseup", this._recordEvent), !0), i.addEventListener("pointermove", fn("pointermove", this._recordEvent), !0)), !0 === this.state.record.keys && (i.addEventListener("keyup", gn("keyup", this._recordEvent), !0), i.addEventListener("keydown", gn("keydown", this._recordEvent), !0)), this.state.record.touch && !0 === ee.Browser.hasEvent("touchstart", document.body) && (i.addEventListener("touchstart", mn("touchstart", this._recordEvent), !0), i.addEventListener("touchmove", mn("touchmove", this._recordEvent), !0), i.addEventListener("touchend", mn("touchend", this._recordEvent), !0)), this.state.record.motion && !0 === ee.Browser.hasEvent("devicemotion", window) && i.addEventListener("devicemotion", yn("devicemotion", this._recordEvent), !0), this.state.initRecord = !0
        }
        this.state.recording = !0
    }, Vn.prototype.stop = function() {
        this.state.recording = !1
    }, Vn.prototype.time = function() {
        return this.state.loadTime
    }, Vn.prototype.getData = function() {
        for (var e in this.state.timeBuffers) this._manifest[e] = this.state.timeBuffers[e].getData(), this._manifest[e + "-mp"] = this.state.timeBuffers[e].getMeanPeriod();
        return this._manifest
    }, Vn.prototype.setData = function(e, t) {
        this._manifest[e] = t
    }, Vn.prototype.resetData = function() {
        this._manifest = {}, this.state.timeBuffers = {}
    }, Vn.prototype.circBuffPush = function(e, t) {
        this._recordEvent(e, t)
    }, Vn.prototype._recordEvent = function(e, t) {
        if (!1 !== this.state.recording) try {
            var n = t[t.length - 1];
            if (!this.state.timeBuffers[e]) {
                var r = "mm" === e || "pm" === e ? 256 : 128;
                this.state.timeBuffers[e] = new tt(16, 15e3, 0, r)
            }
            this.state.timeBuffers[e].push(n, t)
        } catch (pr) {
            De("motion", pr)
        }
    };
    var vn, bn, Rn, wn, Tn, Sn, En = new Vn;
    try {
        vn = function() {
            var e = {
                _DmmS9Z8P: 0,
                _B1PQid: 0,
                _mMuaRS: [],
                _x9Rj: [],
                _tLdGjw6G: [],
                _q7N7R9Mdk: {},
                _FuIS: window,
                _xYwvz: [function(e) {
                    var n = e._B1PQid,
                        r = e._jok9shc71[e._DmmS9Z8P++],
                        i = e._mMuaRS.length;
                    try {
                        t(e)
                    } catch (o) {
                        e._mMuaRS.length = i, e._mMuaRS.push(o), e._DmmS9Z8P = r, t(e)
                    }
                    e._B1PQid = n
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n in t)
                }, function(e) {
                    var t = e._mMuaRS.pop();
                    e._mMuaRS.push(!t)
                }, function(e) {
                    e._q7N7R9Mdk[e._mMuaRS[e._mMuaRS.length - 1]] = e._mMuaRS[e._mMuaRS.length - 2]
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n <= t)
                }, function(e) {
                    var t = e._jok9shc71[e._DmmS9Z8P++];
                    e._B1PQid = t
                }, function(e) {
                    var t = e._jok9shc71[e._DmmS9Z8P++],
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = -1 == t ? e._x9Rj : e._tLdGjw6G[t];
                    e._mMuaRS.push(r[n])
                }, function(e) {
                    for (var t = e._jok9shc71[e._DmmS9Z8P++], n = {}, r = 0; r < t; r++) {
                        var i = e._mMuaRS.pop();
                        n[e._mMuaRS.pop()] = i
                    }
                    e._mMuaRS.push(n)
                }, function(e) {
                    var t = e._mMuaRS.pop();
                    e._mMuaRS.push(+t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++];
                    t || (e._DmmS9Z8P = n)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n !== t)
                }, function(e) {
                    e._mMuaRS.push(Be)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n < t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n + t)
                }, function(e) {
                    var t = e._mMuaRS.pop();
                    e._mMuaRS.push(-t)
                }, function(e) {
                    e._mMuaRS.push(e._jok9shc71[e._DmmS9Z8P++])
                }, function(e) {
                    e._mMuaRS.push(e._mMuaRS[e._mMuaRS.length - 1])
                }, function(e) {
                    e._mMuaRS.push(gt)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n === t)
                }, function(e) {
                    e._DmmS9Z8P = e._mMuaRS.splice(e._mMuaRS.length - 4, 1)[0], e._FuIS = e._mMuaRS.splice(e._mMuaRS.length - 3, 1)[0], e._x9Rj = e._mMuaRS.splice(e._mMuaRS.length - 2, 1)[0]
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++],
                        i = -1 == n ? e._x9Rj : e._tLdGjw6G[n];
                    e._mMuaRS.push(i[r] ^= t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++],
                        i = -1 == n ? e._x9Rj : e._tLdGjw6G[n];
                    e._mMuaRS.push(i[r] += t)
                }, function(e) {
                    for (var t = e._jok9shc71[e._DmmS9Z8P++], n = [], r = 0; r < t; r++) n.push(e._mMuaRS.pop());
                    e._mMuaRS.push(n)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n * t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n & t)
                }, function() {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++];
                    e._tLdGjw6G[n] ? e._x9Rj = e._tLdGjw6G[n] : (e._x9Rj = t, e._tLdGjw6G[n] = t)
                }, function(e) {
                    e._mMuaRS.push(gt)
                }, function() {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++];
                    e._x9Rj = t, e._tLdGjw6G[n] = t
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n >= t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    if (t && t._l !== undefined) n.splice(0, 0, {
                        _l: {}
                    }), t.apply(e._FuIS, n);
                    else {
                        var r = t.apply(e._FuIS, n);
                        e._mMuaRS.push(r)
                    }
                }, function(e) {
                    e._mMuaRS.push(sentryError)
                }, function(e) {
                    e._mMuaRS.push(e._FuIS)
                }, function(e) {
                    e._mMuaRS.push(mt)
                }, function(e) {
                    var t = e._mMuaRS.pop();
                    e._mMuaRS.push(typeof t)
                }, function(e) {
                    e._mMuaRS.push(null)
                }, function(e) {
                    e._mMuaRS.push(undefined)
                }, function(e) {
                    e._mMuaRS.push(gt)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n - t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(delete n[t])
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++];
                    e._x9Rj[r] = t;
                    for (var i = 0; i < n; i++) e._x9Rj[e._jok9shc71[e._DmmS9Z8P++]] = t[i]
                }, function(e) {
                    var t = e._mMuaRS.pop();
                    e._mMuaRS.push(window[t])
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n > t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n != t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++],
                        i = -1 == n ? e._x9Rj : e._tLdGjw6G[n];
                    e._mMuaRS.push(i[r] = t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n | t)
                }, function(e) {
                    var n = e._mMuaRS.pop(),
                        r = function() {
                            var i = !1,
                                o = Array.prototype.slice.call(arguments);
                            o.length > 0 && o[0] && o[0]._l ? o = o.splice(1, o.length - 1) : i = !0;
                            var a = e._FuIS,
                                s = e._B1PQid,
                                l = e._tLdGjw6G;
                            if (e._mMuaRS.push(e._DmmS9Z8P), e._mMuaRS.push(e._FuIS), e._mMuaRS.push(e._x9Rj), e._mMuaRS.push(o), e._mMuaRS.push(r), e._B1PQid = e._DmmS9Z8P, e._DmmS9Z8P = n, e._FuIS = this, e._tLdGjw6G = r._r, t(e), e._FuIS = a, e._B1PQid = s, e._tLdGjw6G = l, i) return e._mMuaRS.pop()
                        };
                    r._l = {}, r._r = Array.prototype.slice.call(e._tLdGjw6G), e._mMuaRS.push(r)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n >>> t)
                }, function(e) {
                    var t = e._jok9shc71[e._DmmS9Z8P++],
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++],
                        i = -1 == t ? e._x9Rj : e._tLdGjw6G[t];
                    r ? e._mMuaRS.push(++i[n]) : e._mMuaRS.push(i[n]++)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop(),
                        r = e._mMuaRS.pop();
                    e._mMuaRS.push(n[t] += r)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n << t)
                }, function(e) {
                    e._mMuaRS.push(Et)
                }, function(e) {
                    e._mMuaRS.pop(), e._mMuaRS.push(void 0)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n == t)
                }, function() {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop(),
                        r = !1;
                    t._l !== undefined && (r = !0, n.splice(0, 0, {
                        _l: {}
                    }));
                    var i = new(Function.prototype.bind.apply(t, [null].concat(n)));
                    r && e._mMuaRS.pop(), e._mMuaRS.push(i)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop(),
                        r = n[t];
                    "function" == typeof r && Object.getPrototypeOf(n) !== Object.prototype && (r = r.bind(n)), e._mMuaRS.push(r)
                }, function(e) {
                    e._mMuaRS.pop()
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop(),
                        r = e._mMuaRS.pop();
                    e._mMuaRS.push(n[t] = r)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++],
                        i = -1 == n ? e._x9Rj : e._tLdGjw6G[n];
                    e._mMuaRS.push(i[r] |= t)
                }, function(e) {
                    e._mMuaRS.push(gt)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n instanceof t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n / t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._mMuaRS.pop();
                    e._mMuaRS.push(n ^ t)
                }, function(e) {
                    var t = e._mMuaRS.pop(),
                        n = e._jok9shc71[e._DmmS9Z8P++],
                        r = e._jok9shc71[e._DmmS9Z8P++];
                    (-1 == n ? e._x9Rj : e._tLdGjw6G[n])[r] = t
                }, function(e) {
                    e._mMuaRS.push(St)
                }, function(e) {
                    for (var t = e._jok9shc71[e._DmmS9Z8P++], n = e._jok9shc71[e._DmmS9Z8P++], r = e._jok9shc71[e._DmmS9Z8P++], i = decodeURIComponent(atob(e._VXR9QNym.slice(t, t + n))), o = "", a = 0; a < i.length; a++) o += String.fromCharCode((256 + i.charCodeAt(a) + r) % 256);
                    e._mMuaRS.push(o)
                }, function(e) {
                    e._mMuaRS.push(!!e._jok9shc71[e._DmmS9Z8P++])
                }, function(e) {
                    throw e._mMuaRS.pop()
                }],
                _jok9shc71: [22, 0, 25, 0, 15, 14, 45, 62, -1, 0, 65, 0, 9, 113, 22, 0, 27, 1, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9764, 16, -1, 18, 9, 44, 6, 0, 127, 65, 0, 9, 112, 65, 0, 9, 54, 6, -1, 1, 64, 4740, 40, -18, 18, 9, 65, 6, 0, 128, 65, 0, 9, 112, 65, 0, 9, 75, 6, -1, 1, 64, 5484, 40, -12, 18, 9, 86, 6, 0, 129, 65, 0, 9, 112, 65, 0, 9, 90, 65, 0, 9, 99, 34, 65, 0, 9, 112, 65, 0, 9, 103, 65, 0, 9, 90, 64, 1172, 24, 7, 40, 65, 0, 9, 112, 19, 15, 123, 45, 62, -1, 1, 65, 0, 9, 222, 22, 0, 27, 2, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9744, 20, 21, 18, 9, 153, 6, 0, 130, 65, 0, 9, 221, 65, 0, 9, 163, 6, -1, 1, 64, 11356, 16, 16, 18, 9, 174, 6, 0, 131, 65, 0, 9, 221, 65, 0, 9, 184, 6, -1, 1, 64, 1940, 48, -17, 18, 9, 195, 6, 0, 132, 65, 0, 9, 221, 65, 0, 9, 199, 65, 0, 9, 208, 34, 65, 0, 9, 221, 65, 0, 9, 212, 65, 0, 9, 199, 64, 1172, 24, 7, 40, 65, 0, 9, 221, 19, 15, 232, 45, 62, -1, 2, 65, 0, 9, 310, 22, 0, 27, 3, 55, 39, 1, 0, 1, 6, -1, 1, 64, 6644, 40, -18, 18, 9, 262, 6, 0, 134, 65, 0, 9, 309, 65, 0, 9, 272, 6, -1, 1, 64, 6720, 20, -14, 18, 9, 283, 6, 0, 135, 65, 0, 9, 309, 65, 0, 9, 287, 65, 0, 9, 296, 34, 65, 0, 9, 309, 65, 0, 9, 300, 65, 0, 9, 287, 64, 1172, 24, 7, 40, 65, 0, 9, 309, 19, 15, 320, 45, 62, -1, 3, 65, 0, 9, 377, 22, 0, 27, 4, 55, 39, 1, 0, 1, 6, -1, 1, 64, 5728, 28, 17, 18, 9, 350, 6, 0, 136, 65, 0, 9, 376, 65, 0, 9, 354, 65, 0, 9, 363, 34, 65, 0, 9, 376, 65, 0, 9, 367, 65, 0, 9, 354, 64, 1172, 24, 7, 40, 65, 0, 9, 376, 19, 15, 387, 45, 62, -1, 4, 65, 0, 9, 427, 22, 0, 27, 5, 55, 39, 1, 0, 1, 6, -1, 1, 64, 10332, 16, 1, 18, 9, 417, 6, 0, 142, 65, 0, 9, 426, 65, 0, 9, 417, 64, 1172, 24, 7, 40, 65, 0, 9, 426, 19, 15, 437, 45, 62, -1, 5, 65, 0, 9, 788, 22, 0, 27, 6, 55, 39, 1, 0, 1, 6, -1, 1, 64, 8712, 4, 4, 18, 9, 467, 6, 0, 139, 65, 0, 9, 787, 65, 0, 9, 477, 6, -1, 1, 64, 1100, 4, 10, 18, 9, 488, 6, 0, 140, 65, 0, 9, 787, 65, 0, 9, 498, 6, -1, 1, 64, 2340, 12, -14, 18, 9, 509, 6, 0, 141, 65, 0, 9, 787, 65, 0, 9, 519, 6, -1, 1, 64, 7628, 16, -21, 18, 9, 530, 6, 0, 138, 65, 0, 9, 787, 65, 0, 9, 540, 6, -1, 1, 64, 5476, 8, 15, 18, 9, 551, 6, 0, 147, 65, 0, 9, 787, 65, 0, 9, 561, 6, -1, 1, 64, 1668, 8, 10, 18, 9, 572, 6, 0, 148, 65, 0, 9, 787, 65, 0, 9, 582, 6, -1, 1, 64, 772, 8, 8, 18, 9, 593, 6, 0, 149, 65, 0, 9, 787, 65, 0, 9, 603, 6, -1, 1, 64, 6180, 24, -21, 18, 9, 614, 6, 0, 150, 65, 0, 9, 787, 65, 0, 9, 624, 6, -1, 1, 64, 10348, 8, -5, 18, 9, 635, 6, 0, 151, 65, 0, 9, 787, 65, 0, 9, 645, 6, -1, 1, 64, 348, 8, 21, 18, 9, 656, 6, 0, 144, 65, 0, 9, 787, 65, 0, 9, 666, 6, -1, 1, 64, 4500, 12, -18, 18, 9, 677, 6, 0, 145, 65, 0, 9, 787, 65, 0, 9, 687, 6, -1, 1, 64, 9872, 4, 22, 18, 9, 698, 6, 0, 146, 65, 0, 9, 787, 65, 0, 9, 708, 6, -1, 1, 64, 7680, 12, -16, 18, 9, 719, 6, 0, 143, 65, 0, 9, 787, 65, 0, 9, 729, 6, -1, 1, 64, 8436, 8, -18, 18, 9, 740, 6, 0, 152, 65, 0, 9, 787, 65, 0, 9, 750, 6, -1, 1, 64, 1916, 4, 2, 18, 9, 761, 6, 0, 153, 65, 0, 9, 787, 65, 0, 9, 765, 65, 0, 9, 774, 34, 65, 0, 9, 787, 65, 0, 9, 778, 65, 0, 9, 765, 64, 1172, 24, 7, 40, 65, 0, 9, 787, 19, 15, 798, 45, 62, -1, 6, 65, 0, 9, 884, 22, 0, 27, 7, 55, 39, 2, 0, 1, 2, 15, 815, 45, 65, 0, 9, 879, 22, 0, 27, 8, 62, -1, 0, 39, 2, 1, 2, 3, 15, 834, 45, 65, 0, 9, 874, 22, 0, 27, 9, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 6, 7, 2, 29, 6, 8, 2, 22, 1, 6, 7, 1, 29, 22, 2, 6, 8, 3, 29, 65, 0, 9, 873, 19, 65, 0, 9, 878, 19, 65, 0, 9, 883, 19, 15, 894, 45, 62, -1, 7, 65, 0, 9, 1034, 22, 0, 27, 10, 55, 39, 2, 0, 1, 2, 15, 911, 45, 65, 0, 9, 1029, 22, 0, 27, 11, 62, -1, 0, 39, 2, 1, 2, 3, 15, 930, 45, 65, 0, 9, 1024, 22, 0, 27, 12, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 6, 10, 2, 29, 62, -1, 3, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 1014, 6, -1, 3, 6, -1, 5, 54, 6, 11, 2, 22, 1, 6, 10, 1, 29, 22, 2, 6, 11, 3, 29, 65, 0, 9, 1023, 15, 1, 21, -1, 5, 55, 65, 0, 9, 969, 64, 1172, 24, 7, 40, 65, 0, 9, 1023, 19, 65, 0, 9, 1028, 19, 65, 0, 9, 1033, 19, 15, 1044, 45, 62, -1, 8, 65, 0, 9, 1161, 22, 0, 27, 13, 55, 39, 1, 0, 1, 6, -1, 1, 64, 3800, 16, -21, 54, 6, -1, 1, 64, 9192, 12, -11, 54, 52, 16, 9, 1091, 55, 6, -1, 1, 64, 5564, 16, -19, 54, 6, -1, 1, 64, 8424, 12, -2, 54, 52, 62, -1, 2, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 2, 9, 1118, 15, 1, 65, 0, 9, 1120, 15, 0, 6, -1, 1, 64, 3716, 12, -2, 54, 9, 1136, 15, 1, 65, 0, 9, 1138, 15, 0, 6, -1, 1, 64, 6320, 12, 13, 54, 6, -1, 1, 64, 10092, 12, 4, 54, 22, 5, 65, 0, 9, 1160, 19, 15, 1171, 45, 62, -1, 9, 65, 0, 9, 1330, 22, 0, 27, 14, 55, 39, 1, 0, 1, 22, 0, 62, -1, 2, 22, 0, 62, -1, 3, 6, -1, 1, 64, 6916, 32, 4, 54, 9, 1215, 22, 0, 6, -1, 1, 64, 6916, 32, 4, 54, 29, 43, -1, 3, 55, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 3, 64, 3156, 16, 16, 54, 12, 9, 1322, 6, -1, 3, 6, -1, 4, 54, 62, -1, 5, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 5, 64, 4528, 4, 20, 54, 22, 1, 64, 11032, 8, -8, 40, 64, 1280, 16, -12, 54, 29, 6, -1, 5, 64, 10784, 4, 16, 54, 22, 1, 64, 11032, 8, -8, 40, 64, 1280, 16, -12, 54, 29, 22, 3, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 4, 0, 55, 65, 0, 9, 1220, 6, -1, 2, 65, 0, 9, 1329, 19, 15, 1340, 45, 62, -1, 10, 65, 0, 9, 1371, 22, 0, 27, 15, 55, 39, 1, 0, 1, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 15, 0, 22, 2, 65, 0, 9, 1370, 19, 15, 1381, 45, 62, -1, 11, 65, 0, 9, 1669, 22, 0, 27, 16, 55, 39, 1, 0, 1, 22, 0, 62, -1, 2, 0, 1649, 6, -1, 1, 64, 2244, 32, -15, 54, 16, 9, 1425, 55, 6, -1, 1, 64, 2244, 32, -15, 54, 64, 3156, 16, 16, 54, 15, 1, 28, 9, 1443, 6, -1, 1, 64, 2244, 32, -15, 54, 43, -1, 3, 55, 65, 0, 9, 1485, 6, -1, 1, 64, 1648, 20, -1, 54, 16, 9, 1471, 55, 6, -1, 1, 64, 1648, 20, -1, 54, 64, 3156, 16, 16, 54, 15, 1, 28, 9, 1485, 6, -1, 1, 64, 1648, 20, -1, 54, 43, -1, 3, 55, 6, -1, 3, 9, 1636, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 3, 64, 3156, 16, 16, 54, 12, 9, 1611, 6, -1, 3, 6, -1, 5, 54, 22, 1, 50, 64, 6088, 28, 20, 54, 29, 43, -1, 4, 55, 6, -1, 4, 9, 1602, 6, -1, 4, 64, 4528, 4, 20, 54, 22, 1, 64, 11032, 8, -8, 40, 64, 1280, 16, -12, 54, 29, 6, -1, 4, 64, 10784, 4, 16, 54, 22, 1, 64, 11032, 8, -8, 40, 64, 1280, 16, -12, 54, 29, 6, -1, 3, 6, -1, 5, 54, 64, 2352, 24, 12, 54, 22, 3, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 5, 0, 55, 65, 0, 9, 1495, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 2, 65, 0, 9, 1668, 5, 1645, 65, 0, 9, 1659, 62, -1, 6, 6, -1, 2, 65, 0, 9, 1668, 64, 1172, 24, 7, 40, 65, 0, 9, 1668, 19, 15, 1679, 45, 62, -1, 12, 65, 0, 9, 1962, 22, 0, 27, 17, 55, 39, 1, 0, 1, 6, -1, 1, 64, 7584, 16, 0, 54, 15, 0, 51, 18, 16, 2, 9, 1734, 55, 6, -1, 1, 64, 7584, 16, 0, 54, 16, 9, 1734, 55, 6, -1, 1, 64, 7584, 16, 0, 54, 64, 10784, 4, 16, 54, 15, 0, 51, 18, 9, 1765, 64, 9824, 4, 1, 15, 0, 64, 4528, 4, 20, 15, 0, 64, 10784, 4, 16, 15, 0, 7, 3, 6, -1, 1, 64, 7584, 16, 0, 56, 55, 6, -1, 1, 64, 1196, 44, -12, 54, 15, 0, 51, 18, 16, 2, 9, 1811, 55, 6, -1, 1, 64, 1196, 44, -12, 54, 16, 9, 1811, 55, 6, -1, 1, 64, 1196, 44, -12, 54, 64, 3012, 12, -13, 54, 15, 0, 51, 18, 9, 1842, 64, 10116, 8, 14, 15, 0, 64, 3644, 8, 17, 15, 0, 64, 3012, 12, -13, 15, 0, 7, 3, 6, -1, 1, 64, 1196, 44, -12, 56, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 11208, 16, 17, 54, 16, 2, 9, 1871, 55, 15, 2, 14, 6, -1, 1, 64, 1196, 44, -12, 54, 64, 10116, 8, 14, 54, 6, -1, 1, 64, 1196, 44, -12, 54, 64, 3644, 8, 17, 54, 6, -1, 1, 64, 1196, 44, -12, 54, 64, 3012, 12, -13, 54, 6, -1, 1, 64, 7584, 16, 0, 54, 64, 9824, 4, 1, 54, 6, -1, 1, 64, 7584, 16, 0, 54, 64, 4528, 4, 20, 54, 6, -1, 1, 64, 7584, 16, 0, 54, 64, 10784, 4, 16, 54, 22, 8, 62, -1, 2, 6, -1, 2, 65, 0, 9, 1961, 19, 15, 1972, 45, 62, -1, 13, 65, 0, 9, 2187, 22, 0, 27, 18, 55, 39, 0, 0, 7, 0, 31, 64, 11328, 12, -5, 56, 55, 64, 11404, 24, 4, 22, 0, 64, 204, 16, 21, 64, 2148, 20, 17, 65, 1, 64, 6520, 12, -11, 65, 1, 64, 5464, 12, -10, 65, 1, 64, 3040, 24, -15, 65, 1, 7, 4, 64, 6472, 24, 9, 65, 0, 64, 8940, 20, 12, 65, 0, 64, 8716, 16, 18, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 64, 1808, 28, -11, 7, 0, 7, 6, 31, 64, 3032, 8, 16, 56, 55, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 163, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 164, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 165, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 166, 56, 55, 31, 22, 1, 31, 64, 4316, 32, 22, 54, 64, 2900, 8, -13, 54, 29, 31, 64, 4316, 32, 22, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 2186, 19, 15, 2197, 45, 62, -1, 14, 65, 0, 9, 2446, 22, 0, 27, 19, 55, 39, 1, 0, 1, 6, 0, 170, 9, 2244, 6, -1, 1, 22, 1, 6, 0, 170, 64, 2332, 8, -7, 54, 29, 62, -1, 2, 6, -1, 2, 15, 0, 51, 10, 9, 2244, 6, -1, 2, 65, 0, 9, 2445, 22, 0, 6, -1, 1, 64, 6740, 24, -14, 54, 64, 2980, 24, -8, 54, 29, 62, -1, 3, 6, -1, 1, 64, 9864, 8, -19, 54, 16, 2, 9, 2280, 55, 64, 6088, 0, 2, 62, -1, 4, 6, -1, 1, 64, 1904, 12, 18, 54, 16, 2, 9, 2300, 55, 64, 6088, 0, 2, 62, -1, 5, 6, -1, 1, 64, 480, 12, -10, 54, 16, 2, 9, 2320, 55, 64, 6088, 0, 2, 62, -1, 6, 6, -1, 1, 64, 7188, 20, 22, 54, 16, 2, 9, 2340, 55, 64, 6088, 0, 2, 62, -1, 7, 6, -1, 1, 64, 11440, 24, -14, 54, 16, 2, 9, 2360, 55, 64, 6088, 0, 2, 62, -1, 8, 6, -1, 1, 22, 1, 6, 0, 15, 29, 62, -1, 9, 6, -1, 3, 6, -1, 4, 13, 6, -1, 5, 13, 6, -1, 6, 13, 6, -1, 7, 13, 6, -1, 8, 13, 6, -1, 9, 13, 62, -1, 10, 6, -1, 10, 22, 1, 32, 29, 62, -1, 11, 6, 0, 170, 9, 2438, 6, -1, 11, 6, -1, 1, 22, 2, 6, 0, 170, 64, 4888, 4, 13, 54, 29, 55, 6, -1, 11, 65, 0, 9, 2445, 19, 15, 2456, 45, 62, -1, 15, 65, 0, 9, 2873, 22, 0, 27, 20, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9864, 8, -19, 54, 64, 6088, 0, 2, 10, 9, 2502, 64, 6376, 20, 2, 6, -1, 1, 64, 9864, 8, -19, 54, 13, 64, 10016, 4, -20, 13, 65, 0, 9, 2872, 6, -1, 1, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 18, 9, 2526, 64, 6764, 20, 8, 65, 0, 9, 2872, 64, 6088, 0, 2, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 1, 64, 9948, 20, 14, 54, 9, 2865, 6, -1, 3, 6, 0, 168, 41, 9, 2561, 65, 0, 9, 2865, 15, 0, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 1, 64, 9948, 20, 14, 54, 64, 428, 32, -17, 54, 64, 3156, 16, 16, 54, 62, -1, 6, 6, 0, 169, 6, -1, 6, 22, 2, 64, 11032, 8, -8, 40, 64, 3320, 4, 21, 54, 29, 62, -1, 7, 15, 0, 62, -1, 8, 6, -1, 8, 6, -1, 7, 12, 9, 2700, 6, -1, 1, 64, 9948, 20, 14, 54, 64, 428, 32, -17, 54, 6, -1, 8, 54, 62, -1, 9, 6, -1, 9, 64, 4532, 32, -21, 54, 6, -1, 1, 64, 4532, 32, -21, 54, 18, 9, 2691, 6, -1, 9, 6, -1, 1, 18, 9, 2686, 6, -1, 4, 15, 1, 13, 43, -1, 5, 55, 47, -1, 4, 0, 55, 47, -1, 8, 0, 55, 65, 0, 9, 2619, 64, 1904, 12, 18, 22, 1, 6, -1, 1, 64, 10752, 24, 6, 54, 29, 16, 9, 2739, 55, 64, 1904, 12, 18, 22, 1, 6, -1, 1, 64, 10356, 56, -16, 54, 29, 64, 6088, 0, 2, 10, 9, 2800, 64, 10976, 4, -1, 22, 0, 6, -1, 1, 64, 4532, 32, -21, 54, 64, 2980, 24, -8, 54, 29, 13, 64, 7692, 24, 0, 13, 64, 1904, 12, 18, 22, 1, 6, -1, 1, 64, 10356, 56, -16, 54, 29, 13, 64, 10016, 4, -20, 13, 6, -1, 2, 13, 43, -1, 2, 55, 65, 0, 9, 2843, 64, 10976, 4, -1, 22, 0, 6, -1, 1, 64, 4532, 32, -21, 54, 64, 2980, 24, -8, 54, 29, 13, 64, 424, 4, 5, 13, 6, -1, 5, 13, 64, 9424, 4, -8, 13, 6, -1, 2, 13, 43, -1, 2, 55, 6, -1, 1, 64, 9948, 20, 14, 54, 43, -1, 1, 55, 15, 1, 21, -1, 3, 55, 65, 0, 9, 2538, 6, -1, 2, 65, 0, 9, 2872, 19, 15, 2883, 45, 62, -1, 16, 65, 0, 9, 2905, 22, 0, 27, 21, 55, 39, 2, 0, 1, 2, 6, -1, 1, 6, -1, 2, 44, 65, 0, 9, 2904, 19, 15, 2915, 45, 62, -1, 17, 65, 0, 9, 3095, 22, 0, 27, 22, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 14, 29, 62, -1, 2, 6, -1, 2, 22, 1, 6, 0, 182, 64, 2332, 8, -7, 54, 29, 62, -1, 3, 6, -1, 3, 9, 2965, 6, -1, 3, 65, 0, 9, 3094, 6, -1, 1, 64, 9736, 8, 21, 54, 9, 2981, 15, 1, 65, 0, 9, 2983, 15, 0, 6, -1, 1, 64, 6028, 28, -16, 54, 9, 2999, 15, 1, 65, 0, 9, 3001, 15, 0, 6, -1, 1, 64, 7372, 12, 20, 54, 9, 3017, 15, 1, 65, 0, 9, 3019, 15, 0, 6, -1, 1, 64, 9332, 16, 12, 54, 9, 3035, 15, 1, 65, 0, 9, 3037, 15, 0, 6, -1, 1, 22, 1, 6, 0, 20, 29, 6, -1, 1, 22, 1, 6, 0, 19, 29, 6, -1, 1, 22, 1, 6, 0, 18, 29, 22, 7, 62, -1, 4, 6, -1, 4, 6, -1, 2, 22, 2, 6, 0, 182, 64, 4888, 4, 13, 54, 29, 55, 6, -1, 4, 65, 0, 9, 3094, 19, 15, 3105, 45, 62, -1, 18, 65, 0, 9, 3674, 22, 0, 27, 23, 55, 39, 1, 0, 1, 6, -1, 1, 64, 5940, 12, 16, 54, 64, 2856, 8, -3, 54, 9, 3136, 6, 0, 181, 65, 0, 9, 3673, 6, -1, 1, 64, 4636, 12, -17, 54, 9, 3153, 6, 0, 179, 65, 0, 9, 3673, 22, 0, 6, -1, 1, 64, 6740, 24, -14, 54, 64, 2980, 24, -8, 54, 29, 62, -1, 2, 6, -1, 2, 64, 11340, 16, 4, 18, 9, 3189, 6, 0, 173, 65, 0, 9, 3673, 6, -1, 1, 64, 480, 12, -10, 54, 9, 3219, 22, 0, 6, -1, 1, 64, 480, 12, -10, 54, 64, 2980, 24, -8, 54, 29, 65, 0, 9, 3223, 64, 6088, 0, 2, 62, -1, 3, 6, -1, 2, 64, 9204, 12, 4, 18, 16, 2, 9, 3247, 55, 6, -1, 3, 64, 9204, 12, 4, 18, 9, 3256, 6, 0, 180, 65, 0, 9, 3673, 6, -1, 3, 64, 6364, 12, 4, 18, 9, 3277, 6, 0, 171, 65, 0, 9, 3673, 65, 0, 9, 3287, 6, -1, 3, 64, 6008, 20, -8, 18, 9, 3298, 6, 0, 172, 65, 0, 9, 3673, 65, 0, 9, 3308, 6, -1, 3, 64, 10292, 12, 13, 18, 9, 3319, 6, 0, 174, 65, 0, 9, 3673, 65, 0, 9, 3329, 6, -1, 3, 64, 11284, 4, -4, 18, 9, 3340, 6, 0, 176, 65, 0, 9, 3673, 65, 0, 9, 3350, 6, -1, 3, 64, 5840, 8, -7, 18, 9, 3361, 6, 0, 177, 65, 0, 9, 3673, 65, 0, 9, 3371, 6, -1, 3, 64, 4952, 12, 9, 18, 9, 3382, 6, 0, 175, 65, 0, 9, 3673, 65, 0, 9, 3386, 65, 0, 9, 3660, 6, -1, 1, 64, 1904, 12, 18, 54, 16, 2, 9, 3403, 55, 64, 6088, 0, 2, 64, 8488, 4, -19, 13, 6, -1, 1, 64, 9864, 8, -19, 54, 16, 2, 9, 3425, 55, 64, 6088, 0, 2, 13, 64, 8488, 4, -19, 13, 6, -1, 1, 64, 11440, 24, -14, 54, 16, 2, 9, 3448, 55, 64, 6088, 0, 2, 13, 64, 8488, 4, -19, 13, 6, -1, 1, 64, 7188, 20, 22, 54, 16, 2, 9, 3471, 55, 64, 6088, 0, 2, 13, 62, -1, 4, 22, 0, 6, -1, 4, 64, 2980, 24, -8, 54, 29, 62, -1, 5, 6, 0, 176, 64, 3888, 8, -6, 22, 2, 6, 0, 172, 64, 6008, 20, -8, 22, 2, 6, 0, 171, 64, 6364, 12, 4, 22, 2, 22, 3, 62, -1, 6, 15, 0, 62, -1, 7, 6, -1, 6, 64, 3156, 16, 16, 54, 62, -1, 8, 6, -1, 7, 6, -1, 8, 12, 9, 3596, 6, -1, 6, 6, -1, 7, 54, 15, 0, 54, 22, 1, 6, -1, 5, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 10, 9, 3587, 6, -1, 6, 6, -1, 7, 54, 15, 1, 54, 65, 0, 9, 3673, 47, -1, 7, 0, 55, 65, 0, 9, 3537, 6, -1, 4, 22, 1, 64, 4900, 4, 13, 64, 6336, 12, 3, 22, 2, 64, 6168, 12, -5, 40, 53, 64, 2856, 8, -3, 54, 29, 9, 3632, 6, 0, 176, 65, 0, 9, 3673, 6, -1, 3, 64, 3468, 28, -12, 18, 9, 3649, 6, 0, 173, 65, 0, 9, 3652, 6, 0, 178, 65, 0, 9, 3673, 65, 0, 9, 3664, 65, 0, 9, 3386, 64, 1172, 24, 7, 40, 65, 0, 9, 3673, 19, 15, 3684, 45, 62, -1, 19, 65, 0, 9, 3830, 22, 0, 27, 24, 55, 39, 1, 0, 1, 64, 1676, 12, -17, 64, 5580, 8, 6, 64, 11440, 24, -14, 64, 7148, 8, -2, 64, 1904, 12, 18, 64, 9864, 8, -19, 22, 6, 62, -1, 2, 22, 0, 62, -1, 3, 6, -1, 2, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 3822, 6, -1, 2, 6, -1, 5, 54, 62, -1, 6, 6, -1, 6, 22, 1, 6, -1, 1, 64, 10752, 24, 6, 54, 29, 9, 3800, 6, -1, 6, 22, 1, 6, -1, 1, 64, 10356, 56, -16, 54, 29, 22, 1, 32, 29, 65, 0, 9, 3801, 34, 22, 1, 6, -1, 3, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 5, 0, 55, 65, 0, 9, 3743, 6, -1, 3, 65, 0, 9, 3829, 19, 15, 3840, 45, 62, -1, 20, 65, 0, 9, 4311, 22, 0, 27, 25, 55, 39, 1, 0, 1, 0, 4292, 65, 1, 9, 3861, 22, 0, 65, 0, 9, 4310, 6, -1, 1, 64, 9808, 16, 1, 54, 62, -1, 2, 6, -1, 2, 64, 3156, 16, 16, 54, 62, -1, 3, 22, 0, 62, -1, 4, 22, 0, 62, -1, 5, 15, 5, 62, -1, 6, 15, 0, 62, -1, 7, 15, 0, 62, -1, 8, 6, -1, 8, 6, -1, 3, 12, 9, 4067, 6, -1, 7, 6, -1, 6, 28, 16, 2, 9, 3941, 55, 6, -1, 5, 64, 3156, 16, 16, 54, 6, -1, 6, 28, 9, 3947, 65, 0, 9, 4067, 6, -1, 2, 6, -1, 8, 54, 62, -1, 9, 6, -1, 9, 64, 1904, 12, 18, 54, 62, -1, 10, 64, 9936, 12, 14, 22, 1, 6, -1, 10, 64, 3588, 12, 4, 54, 29, 15, 0, 18, 9, 4022, 6, -1, 9, 64, 1904, 12, 18, 54, 22, 1, 32, 29, 22, 1, 6, -1, 4, 64, 4628, 8, 2, 54, 29, 55, 15, 1, 21, -1, 7, 55, 65, 0, 9, 4057, 64, 9828, 16, 6, 22, 1, 6, -1, 10, 64, 3588, 12, 4, 54, 29, 15, 0, 18, 9, 4057, 6, -1, 9, 22, 1, 6, -1, 5, 64, 4628, 8, 2, 54, 29, 55, 15, 1, 21, -1, 8, 55, 65, 0, 9, 3908, 6, -1, 5, 64, 3156, 16, 16, 54, 62, -1, 11, 15, 0, 62, -1, 12, 6, -1, 12, 6, -1, 11, 12, 9, 4149, 6, -1, 7, 6, -1, 6, 28, 9, 4105, 65, 0, 9, 4149, 6, -1, 5, 6, -1, 12, 54, 64, 1904, 12, 18, 54, 22, 1, 32, 29, 22, 1, 6, -1, 4, 64, 4628, 8, 2, 54, 29, 55, 15, 1, 21, -1, 7, 55, 15, 1, 21, -1, 12, 55, 65, 0, 9, 4083, 15, 0, 62, -1, 13, 6, -1, 13, 6, -1, 3, 12, 9, 4279, 6, -1, 7, 6, -1, 6, 28, 9, 4176, 65, 0, 9, 4279, 6, -1, 2, 6, -1, 13, 54, 43, -1, 9, 55, 64, 9936, 12, 14, 22, 1, 6, -1, 9, 64, 1904, 12, 18, 54, 64, 3588, 12, 4, 54, 29, 15, 0, 10, 16, 9, 4237, 55, 64, 9828, 16, 6, 22, 1, 6, -1, 9, 64, 1904, 12, 18, 54, 64, 3588, 12, 4, 54, 29, 15, 0, 10, 9, 4269, 6, -1, 9, 64, 1904, 12, 18, 54, 22, 1, 32, 29, 22, 1, 6, -1, 4, 64, 4628, 8, 2, 54, 29, 55, 15, 1, 21, -1, 7, 55, 15, 1, 21, -1, 13, 55, 65, 0, 9, 4154, 6, -1, 4, 65, 0, 9, 4310, 5, 4288, 65, 0, 9, 4301, 62, -1, 14, 22, 0, 65, 0, 9, 4310, 64, 1172, 24, 7, 40, 65, 0, 9, 4310, 19, 15, 4321, 45, 62, -1, 21, 65, 0, 9, 4441, 22, 0, 27, 26, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9764, 16, -1, 18, 9, 4351, 6, 0, 183, 65, 0, 9, 4440, 65, 0, 9, 4361, 6, -1, 1, 64, 4740, 40, -18, 18, 9, 4372, 6, 0, 184, 65, 0, 9, 4440, 65, 0, 9, 4382, 6, -1, 1, 64, 5484, 40, -12, 18, 9, 4393, 6, 0, 185, 65, 0, 9, 4440, 65, 0, 9, 4403, 6, -1, 1, 64, 10056, 36, -13, 18, 9, 4414, 6, 0, 186, 65, 0, 9, 4440, 65, 0, 9, 4418, 65, 0, 9, 4427, 34, 65, 0, 9, 4440, 65, 0, 9, 4431, 65, 0, 9, 4418, 64, 1172, 24, 7, 40, 65, 0, 9, 4440, 19, 15, 4451, 45, 62, -1, 22, 65, 0, 9, 4571, 22, 0, 27, 27, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9744, 20, 21, 18, 9, 4481, 6, 0, 187, 65, 0, 9, 4570, 65, 0, 9, 4491, 6, -1, 1, 64, 11356, 16, 16, 18, 9, 4502, 6, 0, 188, 65, 0, 9, 4570, 65, 0, 9, 4512, 6, -1, 1, 64, 1940, 48, -17, 18, 9, 4523, 6, 0, 189, 65, 0, 9, 4570, 65, 0, 9, 4533, 6, -1, 1, 64, 5756, 20, -16, 18, 9, 4544, 6, 0, 190, 65, 0, 9, 4570, 65, 0, 9, 4548, 65, 0, 9, 4557, 34, 65, 0, 9, 4570, 65, 0, 9, 4561, 65, 0, 9, 4548, 64, 1172, 24, 7, 40, 65, 0, 9, 4570, 19, 15, 4581, 45, 62, -1, 23, 65, 0, 9, 4659, 22, 0, 27, 28, 55, 39, 1, 0, 1, 6, -1, 1, 64, 6644, 40, -18, 18, 9, 4611, 6, 0, 191, 65, 0, 9, 4658, 65, 0, 9, 4621, 6, -1, 1, 64, 6720, 20, -14, 18, 9, 4632, 6, 0, 192, 65, 0, 9, 4658, 65, 0, 9, 4636, 65, 0, 9, 4645, 34, 65, 0, 9, 4658, 65, 0, 9, 4649, 65, 0, 9, 4636, 64, 1172, 24, 7, 40, 65, 0, 9, 4658, 19, 15, 4669, 45, 62, -1, 24, 65, 0, 9, 4701, 22, 0, 27, 29, 55, 39, 1, 0, 1, 6, -1, 1, 64, 976, 12, 16, 18, 9, 4695, 6, 0, 193, 65, 0, 9, 4700, 34, 65, 0, 9, 4700, 19, 15, 4711, 45, 62, -1, 25, 65, 0, 9, 4789, 22, 0, 27, 30, 55, 39, 1, 0, 1, 6, -1, 1, 64, 4192, 8, 17, 18, 9, 4741, 6, 0, 194, 65, 0, 9, 4788, 65, 0, 9, 4751, 6, -1, 1, 64, 6204, 8, 12, 18, 9, 4762, 6, 0, 195, 65, 0, 9, 4788, 65, 0, 9, 4766, 65, 0, 9, 4775, 34, 65, 0, 9, 4788, 65, 0, 9, 4779, 65, 0, 9, 4766, 64, 1172, 24, 7, 40, 65, 0, 9, 4788, 19, 15, 4799, 45, 62, -1, 26, 65, 0, 9, 4919, 22, 0, 27, 31, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9324, 8, 12, 18, 9, 4829, 6, 0, 196, 65, 0, 9, 4918, 65, 0, 9, 4839, 6, -1, 1, 64, 96, 8, -4, 18, 9, 4850, 6, 0, 197, 65, 0, 9, 4918, 65, 0, 9, 4860, 6, -1, 1, 64, 9156, 20, -7, 18, 9, 4871, 6, 0, 198, 65, 0, 9, 4918, 65, 0, 9, 4881, 6, -1, 1, 64, 5524, 16, 13, 18, 9, 4892, 6, 0, 199, 65, 0, 9, 4918, 65, 0, 9, 4896, 65, 0, 9, 4905, 34, 65, 0, 9, 4918, 65, 0, 9, 4909, 65, 0, 9, 4896, 64, 1172, 24, 7, 40, 65, 0, 9, 4918, 19, 15, 4929, 45, 62, -1, 27, 65, 0, 9, 5028, 22, 0, 27, 32, 55, 39, 1, 0, 1, 6, -1, 1, 64, 5432, 24, 16, 18, 9, 4959, 6, 0, 200, 65, 0, 9, 5027, 65, 0, 9, 4969, 6, -1, 1, 64, 2008, 20, 22, 18, 9, 4980, 6, 0, 201, 65, 0, 9, 5027, 65, 0, 9, 4990, 6, -1, 1, 64, 5728, 28, 17, 18, 9, 5001, 6, 0, 202, 65, 0, 9, 5027, 65, 0, 9, 5005, 65, 0, 9, 5014, 34, 65, 0, 9, 5027, 65, 0, 9, 5018, 65, 0, 9, 5005, 64, 1172, 24, 7, 40, 65, 0, 9, 5027, 19, 15, 5038, 45, 62, -1, 28, 65, 0, 9, 5124, 22, 0, 27, 33, 55, 39, 2, 0, 1, 2, 15, 5055, 45, 65, 0, 9, 5119, 22, 0, 27, 34, 62, -1, 0, 39, 2, 1, 2, 3, 15, 5074, 45, 65, 0, 9, 5114, 22, 0, 27, 35, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 6, 33, 2, 29, 6, 34, 2, 22, 1, 6, 33, 1, 29, 22, 2, 6, 34, 3, 29, 65, 0, 9, 5113, 19, 65, 0, 9, 5118, 19, 65, 0, 9, 5123, 19, 15, 5134, 45, 62, -1, 29, 65, 0, 9, 5237, 22, 0, 27, 36, 55, 39, 1, 0, 1, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 6, -1, 1, 64, 6320, 12, 13, 54, 9, 5192, 6, -1, 1, 64, 6320, 12, 13, 54, 65, 0, 9, 5200, 6, -1, 1, 64, 10124, 12, -6, 54, 6, -1, 1, 64, 10092, 12, 4, 54, 9, 5222, 6, -1, 1, 64, 10092, 12, 4, 54, 65, 0, 9, 5230, 6, -1, 1, 64, 5704, 24, -17, 54, 22, 4, 65, 0, 9, 5236, 19, 15, 5247, 45, 62, -1, 30, 65, 0, 9, 5358, 22, 0, 27, 37, 55, 39, 1, 0, 1, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 6, -1, 1, 64, 9204, 12, 4, 54, 6, -1, 1, 64, 6320, 12, 13, 54, 9, 5313, 6, -1, 1, 64, 6320, 12, 13, 54, 65, 0, 9, 5321, 6, -1, 1, 64, 10124, 12, -6, 54, 6, -1, 1, 64, 10092, 12, 4, 54, 9, 5343, 6, -1, 1, 64, 10092, 12, 4, 54, 65, 0, 9, 5351, 6, -1, 1, 64, 5704, 24, -17, 54, 22, 5, 65, 0, 9, 5357, 19, 15, 5368, 45, 62, -1, 31, 65, 0, 9, 5631, 22, 0, 27, 38, 55, 39, 1, 0, 1, 15, 0, 62, -1, 2, 64, 4708, 32, -20, 6, 0, 224, 64, 5220, 28, -17, 6, 0, 223, 64, 11180, 16, 6, 6, 0, 222, 64, 6708, 12, 18, 6, 0, 221, 7, 4, 62, -1, 3, 64, 2092, 12, 7, 6, 0, 229, 64, 4916, 36, -20, 6, 0, 228, 64, 4296, 20, 1, 6, 0, 227, 64, 7860, 12, 12, 6, 0, 226, 64, 5268, 8, -10, 6, 0, 225, 7, 5, 62, -1, 4, 6, -1, 3, 22, 1, 64, 2168, 20, -19, 40, 64, 6520, 12, -11, 54, 29, 62, -1, 5, 6, -1, 5, 64, 3156, 16, 16, 54, 62, -1, 6, 15, 0, 62, -1, 7, 6, -1, 7, 6, -1, 6, 12, 9, 5547, 6, -1, 5, 6, -1, 7, 54, 62, -1, 8, 6, -1, 1, 6, -1, 8, 54, 9, 5538, 6, -1, 3, 6, -1, 8, 54, 6, -1, 2, 22, 2, 6, 0, 16, 29, 43, -1, 2, 55, 47, -1, 7, 0, 55, 65, 0, 9, 5490, 6, -1, 4, 6, -1, 1, 64, 2896, 4, 1, 54, 54, 9, 5586, 6, -1, 4, 6, -1, 1, 64, 2896, 4, 1, 54, 54, 6, -1, 2, 22, 2, 6, 0, 16, 29, 43, -1, 2, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 6, -1, 2, 6, -1, 1, 64, 4512, 16, 8, 54, 22, 4, 65, 0, 9, 5630, 19, 15, 5641, 45, 62, -1, 32, 65, 0, 9, 5983, 22, 0, 27, 39, 55, 39, 1, 0, 1, 22, 0, 62, -1, 2, 0, 5963, 6, -1, 1, 64, 2244, 32, -15, 54, 16, 9, 5685, 55, 6, -1, 1, 64, 2244, 32, -15, 54, 64, 3156, 16, 16, 54, 15, 1, 28, 9, 5703, 6, -1, 1, 64, 2244, 32, -15, 54, 43, -1, 3, 55, 65, 0, 9, 5745, 6, -1, 1, 64, 1648, 20, -1, 54, 16, 9, 5731, 55, 6, -1, 1, 64, 1648, 20, -1, 54, 64, 3156, 16, 16, 54, 15, 1, 28, 9, 5745, 6, -1, 1, 64, 1648, 20, -1, 54, 43, -1, 3, 55, 6, -1, 3, 9, 5950, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 5, 15, 0, 62, -1, 6, 6, -1, 6, 6, -1, 5, 12, 9, 5899, 6, -1, 3, 6, -1, 6, 54, 22, 1, 50, 64, 6088, 28, 20, 54, 29, 43, -1, 4, 55, 6, -1, 4, 9, 5890, 6, -1, 3, 6, -1, 6, 54, 64, 2352, 24, 12, 54, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 4, 64, 10784, 4, 16, 54, 22, 1, 64, 11032, 8, -8, 40, 64, 1280, 16, -12, 54, 29, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 4, 64, 4528, 4, 20, 54, 22, 1, 64, 11032, 8, -8, 40, 64, 1280, 16, -12, 54, 29, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 6, 0, 55, 65, 0, 9, 5766, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 2, 65, 0, 9, 5982, 5, 5959, 65, 0, 9, 5973, 62, -1, 7, 6, -1, 2, 65, 0, 9, 5982, 64, 1172, 24, 7, 40, 65, 0, 9, 5982, 19, 15, 5993, 45, 62, -1, 33, 65, 0, 9, 6036, 22, 0, 27, 40, 55, 39, 1, 0, 1, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 22, 2, 65, 0, 9, 6035, 19, 15, 6046, 45, 62, -1, 34, 65, 0, 9, 6370, 22, 0, 27, 41, 55, 39, 1, 0, 1, 6, -1, 1, 64, 7016, 12, 8, 54, 62, -1, 2, 6, -1, 1, 64, 480, 12, -10, 54, 64, 4192, 8, 17, 18, 9, 6088, 6, 0, 230, 65, 0, 9, 6091, 6, 0, 231, 62, -1, 3, 6, -1, 2, 64, 9052, 12, 10, 54, 16, 2, 9, 6111, 55, 64, 6088, 0, 2, 62, -1, 4, 6, -1, 1, 64, 6056, 32, -12, 54, 16, 2, 9, 6128, 55, 34, 62, -1, 5, 6, -1, 5, 16, 9, 6146, 55, 6, -1, 5, 64, 1620, 16, 8, 54, 9, 6167, 64, 3468, 28, -12, 22, 1, 6, -1, 5, 64, 1620, 16, 8, 54, 29, 65, 0, 9, 6171, 64, 6088, 0, 2, 62, -1, 6, 15, 0, 62, -1, 7, 6, -1, 3, 6, 0, 231, 18, 9, 6264, 6, -1, 2, 64, 8688, 24, 13, 54, 15, 0, 22, 2, 6, -1, 4, 64, 5016, 12, 15, 54, 29, 6, -1, 6, 13, 6, -1, 2, 64, 8400, 24, 12, 54, 22, 1, 6, -1, 4, 64, 5016, 12, 15, 54, 29, 13, 62, -1, 8, 6, -1, 6, 64, 3156, 16, 16, 54, 6, -1, 8, 64, 3156, 16, 16, 54, 60, 15, 100, 23, 43, -1, 7, 55, 65, 0, 9, 6318, 6, -1, 2, 64, 8400, 24, 12, 54, 6, -1, 2, 64, 8688, 24, 13, 54, 22, 2, 6, -1, 4, 64, 5016, 12, 15, 54, 29, 62, -1, 9, 6, -1, 9, 64, 3156, 16, 16, 54, 6, -1, 4, 64, 3156, 16, 16, 54, 60, 15, 100, 23, 43, -1, 7, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 2, 22, 1, 6, 0, 14, 29, 6, -1, 3, 6, 0, 231, 18, 9, 6356, 15, 1, 14, 65, 0, 9, 6357, 34, 6, -1, 7, 6, -1, 3, 22, 5, 65, 0, 9, 6369, 19, 15, 6380, 45, 62, -1, 35, 65, 0, 9, 6597, 22, 0, 27, 42, 55, 39, 1, 0, 1, 15, 0, 62, -1, 2, 6, -1, 1, 64, 7016, 12, 8, 54, 64, 256, 24, -3, 40, 59, 16, 2, 9, 6427, 55, 6, -1, 1, 64, 7016, 12, 8, 54, 64, 8756, 28, -1, 40, 59, 9, 6455, 6, -1, 1, 64, 7016, 12, 8, 54, 64, 9052, 12, 10, 54, 64, 3156, 16, 16, 54, 43, -1, 2, 55, 65, 0, 9, 6510, 6, -1, 1, 64, 7016, 12, 8, 54, 64, 3448, 20, 11, 40, 59, 16, 9, 6486, 55, 6, -1, 1, 64, 7016, 12, 8, 54, 64, 8316, 36, -9, 54, 9, 6510, 6, -1, 1, 64, 7016, 12, 8, 54, 64, 9968, 48, -21, 54, 64, 3156, 16, 16, 54, 43, -1, 2, 55, 6, -1, 1, 64, 9800, 8, 13, 54, 9, 6537, 6, -1, 1, 64, 9800, 8, 13, 54, 64, 3156, 16, 16, 54, 65, 0, 9, 6540, 15, 1, 14, 62, -1, 3, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 17, 29, 6, -1, 3, 6, -1, 2, 22, 5, 65, 0, 9, 6596, 19, 15, 6607, 45, 62, -1, 36, 65, 0, 9, 6859, 22, 0, 27, 43, 55, 39, 1, 0, 1, 6, -1, 1, 64, 480, 12, -10, 54, 64, 5728, 28, 17, 18, 16, 9, 6641, 55, 6, -1, 1, 64, 6916, 32, 4, 54, 9, 6776, 22, 0, 6, -1, 1, 64, 6916, 32, 4, 54, 29, 62, -1, 2, 22, 0, 15, 6666, 45, 65, 0, 9, 6751, 22, 0, 27, 44, 62, -1, 0, 39, 1, 1, 2, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 2, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 6, -1, 2, 64, 72, 20, 18, 54, 6, -1, 2, 64, 10964, 12, 0, 54, 6, -1, 2, 64, 7984, 60, -17, 54, 6, -1, 2, 64, 10124, 12, -6, 54, 6, -1, 2, 64, 5704, 24, -17, 54, 22, 7, 65, 0, 9, 6750, 19, 22, 1, 6, -1, 2, 64, 2892, 4, 8, 54, 29, 64, 8924, 16, -15, 54, 29, 65, 0, 9, 6858, 65, 0, 9, 6849, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 1, 64, 7016, 12, 8, 54, 22, 1, 6, 0, 14, 29, 6, -1, 1, 64, 72, 20, 18, 54, 6, -1, 1, 64, 10964, 12, 0, 54, 6, -1, 1, 64, 7984, 60, -17, 54, 6, -1, 1, 64, 10124, 12, -6, 54, 6, -1, 1, 64, 5704, 24, -17, 54, 22, 7, 65, 0, 9, 6858, 64, 1172, 24, 7, 40, 65, 0, 9, 6858, 19, 15, 6869, 45, 62, -1, 37, 65, 0, 9, 6984, 22, 0, 27, 45, 55, 39, 0, 0, 0, 6965, 64, 356, 24, -16, 40, 64, 8560, 24, 18, 54, 34, 52, 9, 6899, 65, 0, 65, 0, 9, 6983, 64, 2484, 20, 18, 62, -1, 1, 6, -1, 1, 6, -1, 1, 22, 2, 64, 356, 24, -16, 40, 64, 8560, 24, 18, 54, 64, 9904, 32, -16, 54, 29, 55, 6, -1, 1, 22, 1, 64, 356, 24, -16, 40, 64, 8560, 24, 18, 54, 64, 9216, 32, -12, 54, 29, 55, 65, 1, 65, 0, 9, 6983, 5, 6961, 65, 0, 9, 6974, 62, -1, 2, 65, 0, 65, 0, 9, 6983, 64, 1172, 24, 7, 40, 65, 0, 9, 6983, 19, 15, 6994, 45, 62, -1, 38, 65, 0, 9, 7175, 22, 0, 27, 46, 55, 39, 0, 0, 6, 0, 235, 62, -1, 1, 64, 356, 24, -16, 40, 15, 0, 51, 52, 9, 7026, 6, -1, 1, 65, 0, 9, 7174, 64, 356, 24, -16, 40, 64, 104, 20, -10, 54, 9, 7045, 6, 0, 236, 57, -1, 1, 55, 64, 356, 24, -16, 40, 64, 104, 20, -10, 54, 16, 9, 7074, 55, 64, 356, 24, -16, 40, 64, 104, 20, -10, 54, 64, 832, 8, 0, 54, 9, 7083, 6, 0, 237, 57, -1, 1, 55, 64, 356, 24, -16, 40, 64, 11224, 16, 15, 54, 9, 7102, 6, 0, 238, 57, -1, 1, 55, 64, 356, 24, -16, 40, 64, 8204, 24, -7, 54, 33, 64, 1172, 24, 7, 10, 9, 7127, 6, 0, 239, 57, -1, 1, 55, 0, 7164, 64, 356, 24, -16, 40, 64, 8560, 24, 18, 54, 16, 9, 7149, 55, 22, 0, 6, 0, 37, 29, 9, 7158, 6, 0, 240, 57, -1, 1, 55, 5, 7160, 65, 0, 9, 7167, 62, -1, 2, 6, -1, 1, 65, 0, 9, 7174, 19, 15, 7185, 45, 62, -1, 39, 65, 0, 9, 7206, 22, 0, 27, 47, 55, 39, 1, 0, 1, 6, -1, 1, 6, 0, 241, 18, 65, 0, 9, 7205, 19, 15, 7216, 45, 62, -1, 40, 65, 0, 9, 7450, 22, 0, 27, 48, 55, 39, 1, 0, 1, 22, 0, 6, 0, 38, 29, 22, 1, 6, 0, 39, 29, 2, 31, 64, 6396, 68, -16, 56, 55, 31, 64, 6396, 68, -16, 54, 9, 7258, 35, 65, 0, 9, 7449, 34, 31, 64, 6636, 8, 18, 56, 55, 22, 0, 31, 64, 5276, 8, 13, 56, 55, 6, -1, 1, 31, 64, 5776, 20, -4, 56, 55, 22, 0, 31, 64, 8372, 16, -12, 54, 29, 31, 64, 7568, 16, 8, 56, 55, 34, 31, 64, 3252, 16, -4, 56, 55, 22, 0, 31, 64, 4252, 28, 5, 56, 55, 65, 0, 31, 64, 7936, 28, 1, 56, 55, 31, 62, -1, 2, 64, 356, 24, -16, 40, 64, 9692, 44, -12, 54, 9, 7440, 15, 7350, 45, 65, 0, 9, 7422, 22, 0, 27, 49, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 64, 2896, 4, 1, 54, 6, 48, 2, 64, 5776, 20, -4, 54, 18, 16, 9, 7390, 55, 6, -1, 2, 64, 1340, 28, -14, 54, 9, 7412, 6, -1, 2, 64, 1340, 28, -14, 54, 22, 1, 6, 48, 2, 64, 4592, 36, 6, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 7421, 19, 64, 10788, 12, 0, 22, 2, 64, 356, 24, -16, 40, 64, 9692, 44, -12, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 7449, 19, 15, 7460, 45, 62, -1, 41, 65, 0, 9, 7498, 22, 0, 27, 50, 55, 39, 1, 0, 1, 22, 0, 31, 64, 5276, 8, 13, 56, 55, 6, -1, 1, 31, 64, 5776, 20, -4, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 7497, 19, 15, 7508, 45, 62, -1, 42, 65, 0, 9, 7567, 22, 0, 27, 51, 55, 39, 1, 0, 1, 0, 7548, 6, -1, 1, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 55, 65, 0, 65, 0, 9, 7566, 5, 7544, 65, 0, 9, 7557, 62, -1, 2, 65, 1, 65, 0, 9, 7566, 64, 1172, 24, 7, 40, 65, 0, 9, 7566, 19, 15, 7577, 45, 62, -1, 43, 65, 0, 9, 8076, 22, 0, 27, 52, 55, 39, 3, 0, 1, 2, 3, 6, -1, 2, 34, 52, 9, 7602, 6, 0, 233, 43, -1, 2, 55, 6, -1, 3, 22, 1, 64, 3816, 28, -20, 40, 64, 2596, 12, 17, 54, 29, 2, 9, 7628, 6, 0, 276, 43, -1, 3, 55, 22, 0, 62, -1, 8, 7, 0, 62, -1, 9, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 10, 15, 0, 43, -1, 4, 55, 6, -1, 4, 6, -1, 10, 12, 9, 7698, 6, -1, 4, 6, -1, 9, 6, -1, 3, 6, -1, 4, 54, 56, 55, 22, 0, 6, -1, 8, 6, -1, 4, 56, 55, 47, -1, 4, 0, 55, 65, 0, 9, 7655, 6, -1, 1, 64, 3156, 16, 16, 54, 62, -1, 11, 15, 0, 43, -1, 4, 55, 6, -1, 4, 6, -1, 11, 12, 9, 7815, 6, -1, 1, 6, -1, 4, 54, 43, -1, 7, 55, 6, -1, 7, 15, 0, 54, 43, -1, 5, 55, 6, -1, 9, 6, -1, 5, 54, 15, 0, 51, 10, 9, 7806, 6, -1, 9, 6, -1, 5, 54, 43, -1, 6, 55, 64, 1368, 8, 13, 6, -1, 4, 64, 7820, 8, -3, 6, -1, 7, 7, 2, 6, -1, 8, 6, -1, 6, 54, 6, -1, 8, 6, -1, 6, 54, 64, 3156, 16, 16, 54, 56, 55, 47, -1, 4, 0, 55, 65, 0, 9, 7715, 6, -1, 8, 64, 3156, 16, 16, 54, 62, -1, 12, 22, 0, 62, -1, 13, 15, 0, 43, -1, 4, 55, 6, -1, 4, 6, -1, 12, 12, 9, 7955, 6, -1, 8, 6, -1, 4, 54, 62, -1, 14, 6, -1, 14, 64, 3156, 16, 16, 54, 62, -1, 15, 15, 0, 62, -1, 16, 6, -1, 16, 6, -1, 15, 12, 9, 7928, 6, -1, 14, 6, -1, 16, 54, 6, -1, 13, 6, -1, 13, 64, 3156, 16, 16, 54, 56, 55, 6, -1, 13, 64, 3156, 16, 16, 54, 6, -1, 2, 28, 9, 7919, 65, 0, 9, 7928, 47, -1, 16, 0, 55, 65, 0, 9, 7872, 6, -1, 13, 64, 3156, 16, 16, 54, 6, -1, 2, 28, 9, 7946, 65, 0, 9, 7955, 47, -1, 4, 0, 55, 65, 0, 9, 7837, 15, 7962, 45, 65, 0, 9, 7996, 22, 0, 27, 53, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 2, 64, 1368, 8, 13, 54, 6, -1, 3, 64, 1368, 8, 13, 54, 37, 65, 0, 9, 7995, 19, 22, 1, 6, -1, 13, 64, 4564, 28, -15, 54, 29, 55, 6, -1, 13, 64, 3156, 16, 16, 54, 62, -1, 17, 22, 0, 62, -1, 18, 15, 0, 43, -1, 4, 55, 6, -1, 4, 6, -1, 17, 12, 9, 8068, 6, -1, 13, 6, -1, 4, 54, 64, 7820, 8, -3, 54, 6, -1, 18, 6, -1, 4, 56, 55, 47, -1, 4, 0, 55, 65, 0, 9, 8030, 6, -1, 18, 65, 0, 9, 8075, 19, 15, 8086, 45, 62, -1, 44, 65, 0, 9, 8128, 22, 0, 27, 54, 55, 39, 0, 0, 22, 0, 64, 11032, 8, -8, 40, 64, 1880, 12, -11, 54, 29, 15, 100, 23, 22, 1, 64, 11032, 8, -8, 40, 64, 11168, 12, -12, 54, 29, 65, 0, 9, 8127, 19, 15, 8138, 45, 62, -1, 45, 65, 0, 9, 8222, 22, 0, 27, 55, 55, 39, 0, 0, 15, 15, 15, 2, 22, 2, 15, 36, 22, 1, 22, 0, 64, 11032, 8, -8, 40, 64, 1880, 12, -11, 54, 29, 64, 780, 36, -16, 54, 29, 64, 4132, 48, -14, 54, 29, 15, 15, 15, 2, 22, 2, 15, 36, 22, 1, 22, 0, 64, 11032, 8, -8, 40, 64, 1880, 12, -11, 54, 29, 64, 780, 36, -16, 54, 29, 64, 4132, 48, -14, 54, 29, 13, 65, 0, 9, 8221, 19, 15, 8232, 45, 62, -1, 46, 65, 0, 9, 8291, 22, 0, 27, 56, 55, 39, 0, 0, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 2732, 16, 21, 54, 64, 92, 4, -11, 22, 1, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 8476, 12, 11, 54, 64, 8912, 8, 2, 54, 29, 15, 0, 54, 13, 65, 0, 9, 8290, 19, 15, 8301, 45, 62, -1, 47, 65, 0, 9, 8423, 22, 0, 27, 57, 55, 39, 1, 0, 1, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 4636, 12, -17, 54, 62, -1, 2, 6, -1, 2, 16, 9, 8338, 55, 6, -1, 1, 9, 8416, 65, 0, 62, -1, 3, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 1, 64, 3156, 16, 16, 54, 12, 9, 8409, 6, -1, 1, 6, -1, 4, 54, 62, -1, 5, 6, -1, 2, 22, 1, 6, -1, 5, 64, 2856, 8, -3, 54, 29, 9, 8400, 65, 1, 43, -1, 3, 55, 65, 0, 9, 8409, 47, -1, 4, 0, 55, 65, 0, 9, 8350, 6, -1, 3, 65, 0, 9, 8422, 65, 0, 65, 0, 9, 8422, 19, 15, 8433, 45, 62, -1, 48, 65, 0, 9, 8637, 22, 0, 27, 58, 55, 39, 1, 0, 1, 6, -1, 1, 2, 16, 2, 9, 8460, 55, 6, -1, 1, 33, 64, 8592, 8, -6, 10, 9, 8469, 6, -1, 1, 65, 0, 9, 8636, 6, -1, 1, 62, -1, 2, 64, 6364, 12, 4, 6, 0, 269, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 3888, 8, -6, 6, 0, 270, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 5456, 8, -11, 6, 0, 271, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 1800, 4, -4, 6, 0, 272, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 3896, 20, -21, 6, 0, 273, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 1636, 8, 0, 6, 0, 274, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 10292, 12, 13, 6, 0, 275, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 6, -1, 2, 65, 0, 9, 8636, 19, 15, 8647, 45, 62, -1, 49, 65, 0, 9, 8827, 22, 0, 27, 59, 55, 39, 1, 0, 1, 6, -1, 1, 2, 9, 8670, 64, 11376, 24, 11, 65, 0, 9, 8826, 15, 0, 62, -1, 2, 6, -1, 1, 64, 3156, 16, 16, 54, 62, -1, 3, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 3, 12, 9, 8755, 6, -1, 4, 22, 1, 6, -1, 1, 64, 3564, 24, 3, 54, 29, 62, -1, 5, 6, -1, 2, 15, 5, 49, 6, -1, 2, 37, 6, -1, 5, 13, 43, -1, 2, 55, 6, -1, 2, 6, -1, 2, 24, 43, -1, 2, 55, 47, -1, 4, 0, 55, 65, 0, 9, 8691, 15, 16, 22, 1, 6, -1, 2, 15, 0, 46, 64, 780, 36, -16, 54, 29, 62, -1, 6, 6, -1, 6, 64, 3156, 16, 16, 54, 15, 6, 12, 9, 8807, 64, 11012, 4, -8, 6, -1, 6, 13, 6, -1, 6, 13, 43, -1, 6, 55, 65, 0, 9, 8774, 15, 6, 15, 0, 22, 2, 6, -1, 6, 64, 4132, 48, -14, 54, 29, 65, 0, 9, 8826, 19, 15, 8837, 45, 62, -1, 50, 65, 0, 9, 8875, 22, 0, 27, 60, 55, 39, 1, 0, 1, 6, -1, 1, 33, 64, 8592, 8, -6, 18, 16, 9, 8870, 55, 6, -1, 1, 64, 3156, 16, 16, 54, 15, 0, 41, 65, 0, 9, 8874, 19, 15, 8885, 45, 62, -1, 51, 65, 0, 9, 8998, 22, 0, 27, 61, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 50, 29, 2, 9, 8914, 64, 6088, 0, 2, 65, 0, 9, 8997, 22, 0, 64, 7716, 4, 22, 6, 0, 247, 22, 2, 64, 7716, 4, 22, 6, 0, 246, 22, 2, 64, 6088, 0, 2, 6, 0, 245, 22, 2, 6, -1, 1, 22, 1, 64, 8044, 32, -18, 40, 29, 64, 3204, 16, 18, 54, 29, 64, 3204, 16, 18, 54, 29, 64, 3204, 16, 18, 54, 29, 64, 2980, 24, -8, 54, 29, 62, -1, 2, 6, -1, 2, 16, 2, 9, 8993, 55, 64, 6088, 0, 2, 65, 0, 9, 8997, 19, 15, 9008, 45, 62, -1, 52, 65, 0, 9, 9145, 22, 0, 27, 62, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 50, 29, 2, 9, 9035, 65, 0, 65, 0, 9, 9144, 6, -1, 1, 22, 1, 6, 0, 250, 64, 2856, 8, -3, 54, 29, 9, 9057, 65, 1, 65, 0, 9, 9144, 6, -1, 1, 22, 1, 6, 0, 251, 64, 2856, 8, -3, 54, 29, 16, 9, 9086, 55, 6, -1, 1, 64, 3156, 16, 16, 54, 15, 12, 41, 9, 9094, 65, 1, 65, 0, 9, 9144, 6, -1, 1, 22, 1, 6, 0, 252, 64, 2856, 8, -3, 54, 29, 9, 9116, 65, 1, 65, 0, 9, 9144, 6, -1, 1, 22, 1, 6, 0, 253, 64, 2856, 8, -3, 54, 29, 9, 9138, 65, 1, 65, 0, 9, 9144, 65, 0, 65, 0, 9, 9144, 19, 15, 9155, 45, 62, -1, 53, 65, 0, 9, 9211, 22, 0, 27, 63, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 50, 29, 2, 9, 9182, 65, 0, 65, 0, 9, 9210, 6, -1, 1, 22, 1, 6, 0, 254, 64, 2856, 8, -3, 54, 29, 9, 9204, 65, 1, 65, 0, 9, 9210, 65, 0, 65, 0, 9, 9210, 19, 15, 9221, 45, 62, -1, 54, 65, 0, 9, 9421, 22, 0, 27, 64, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 50, 29, 2, 9, 9248, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 52, 29, 9, 9265, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 53, 29, 9, 9282, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 255, 64, 2856, 8, -3, 54, 29, 9, 9304, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 256, 64, 2856, 8, -3, 54, 29, 9, 9326, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 257, 64, 2856, 8, -3, 54, 29, 9, 9348, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 258, 64, 2856, 8, -3, 54, 29, 9, 9370, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 259, 64, 2856, 8, -3, 54, 29, 9, 9392, 65, 0, 65, 0, 9, 9420, 6, -1, 1, 22, 1, 6, 0, 260, 64, 2856, 8, -3, 54, 29, 9, 9414, 65, 0, 65, 0, 9, 9420, 65, 1, 65, 0, 9, 9420, 19, 15, 9431, 45, 62, -1, 55, 65, 0, 9, 9460, 22, 0, 27, 65, 55, 39, 2, 0, 1, 2, 6, -1, 2, 22, 1, 6, -1, 1, 64, 10356, 56, -16, 54, 29, 65, 0, 9, 9459, 19, 15, 9470, 45, 62, -1, 56, 65, 0, 9, 9524, 22, 0, 27, 66, 55, 39, 1, 0, 1, 64, 5580, 8, 6, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 2, 6, -1, 2, 9, 9515, 22, 0, 6, -1, 2, 64, 2980, 24, -8, 54, 29, 65, 0, 9, 9519, 64, 6088, 0, 2, 65, 0, 9, 9523, 19, 15, 9534, 45, 62, -1, 57, 65, 0, 9, 9573, 22, 0, 27, 67, 55, 39, 1, 0, 1, 64, 4636, 12, -17, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 2, 6, -1, 2, 22, 1, 6, 0, 50, 29, 65, 0, 9, 9572, 19, 15, 9583, 45, 62, -1, 58, 65, 0, 9, 9666, 22, 0, 27, 68, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 50, 29, 2, 9, 9611, 6, -1, 1, 65, 0, 9, 9665, 6, -1, 1, 22, 1, 6, 0, 52, 29, 16, 2, 9, 9634, 55, 6, -1, 1, 22, 1, 6, 0, 53, 29, 9, 9643, 6, -1, 1, 65, 0, 9, 9665, 64, 988, 12, 0, 6, 0, 267, 22, 2, 6, -1, 1, 64, 3204, 16, 18, 54, 29, 65, 0, 9, 9665, 19, 15, 9676, 45, 62, -1, 59, 65, 0, 9, 10315, 22, 0, 27, 69, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 6, 0, 50, 29, 2, 9, 9702, 34, 65, 0, 9, 10314, 6, -1, 1, 22, 1, 6, 0, 261, 64, 2856, 8, -3, 54, 29, 2, 9, 9724, 34, 65, 0, 9, 10314, 6, -1, 1, 22, 1, 6, 0, 262, 64, 2856, 8, -3, 54, 29, 16, 9, 9756, 55, 6, -1, 1, 22, 1, 6, 0, 263, 64, 2856, 8, -3, 54, 29, 16, 9, 9774, 55, 6, -1, 1, 22, 1, 6, 0, 264, 64, 2856, 8, -3, 54, 29, 9, 9781, 34, 65, 0, 9, 10314, 22, 0, 6, -1, 1, 64, 2980, 24, -8, 54, 29, 62, -1, 2, 64, 3496, 20, -7, 15, 1, 64, 10256, 24, 21, 15, 1, 64, 328, 20, 21, 15, 1, 64, 3652, 60, -18, 15, 1, 64, 4112, 20, 1, 15, 1, 64, 8812, 24, 9, 15, 1, 64, 7056, 36, -20, 15, 1, 64, 492, 24, -9, 15, 1, 64, 8784, 28, 17, 15, 1, 64, 2660, 72, -15, 15, 1, 64, 10412, 16, 19, 15, 1, 64, 2768, 12, -1, 15, 1, 64, 2380, 12, 16, 15, 1, 64, 2228, 16, -4, 15, 1, 64, 8836, 16, 13, 15, 1, 64, 7372, 12, 20, 15, 1, 64, 11288, 24, -15, 15, 1, 64, 9780, 12, 14, 15, 1, 64, 9324, 8, 12, 15, 1, 64, 3244, 8, -6, 15, 1, 64, 976, 12, 16, 15, 1, 64, 9204, 12, 4, 15, 1, 64, 6464, 8, 20, 15, 1, 7, 23, 62, -1, 3, 6, -1, 3, 6, -1, 2, 54, 9, 9952, 34, 65, 0, 9, 10314, 34, 62, -1, 4, 64, 10020, 8, -12, 22, 1, 6, -1, 1, 64, 3588, 12, 4, 54, 29, 62, -1, 5, 6, -1, 5, 15, 0, 41, 9, 10055, 6, -1, 5, 15, 0, 22, 2, 6, -1, 1, 64, 4132, 48, -14, 54, 29, 62, -1, 6, 64, 5976, 4, -6, 22, 1, 6, -1, 6, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 41, 9, 10044, 64, 5976, 4, -6, 22, 1, 6, -1, 6, 64, 8912, 8, 2, 54, 29, 15, 0, 54, 65, 0, 9, 10047, 6, -1, 6, 43, -1, 4, 55, 65, 0, 9, 10247, 64, 5976, 4, -6, 22, 1, 6, -1, 1, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 41, 9, 10102, 64, 5976, 4, -6, 22, 1, 6, -1, 1, 64, 8912, 8, 2, 54, 29, 15, 0, 54, 43, -1, 4, 55, 65, 0, 9, 10247, 64, 4892, 8, 16, 22, 1, 6, -1, 1, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 41, 9, 10149, 64, 4892, 8, 16, 22, 1, 6, -1, 1, 64, 8912, 8, 2, 54, 29, 15, 0, 54, 43, -1, 4, 55, 65, 0, 9, 10247, 6, -1, 1, 22, 1, 6, 0, 264, 64, 2856, 8, -3, 54, 29, 16, 2, 9, 10187, 55, 64, 7716, 4, 22, 22, 1, 6, -1, 1, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 41, 16, 2, 9, 10211, 55, 64, 5988, 4, 7, 22, 1, 6, -1, 1, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 41, 9, 10224, 6, -1, 1, 43, -1, 4, 55, 65, 0, 9, 10247, 6, -1, 1, 22, 1, 6, 0, 265, 64, 2856, 8, -3, 54, 29, 9, 10247, 6, -1, 1, 43, -1, 4, 55, 6, -1, 4, 2, 9, 10258, 34, 65, 0, 9, 10314, 6, -1, 4, 22, 1, 6, 0, 58, 29, 43, -1, 4, 55, 6, -1, 4, 22, 1, 6, 0, 52, 29, 16, 2, 9, 10294, 55, 6, -1, 4, 22, 1, 6, 0, 53, 29, 9, 10301, 34, 65, 0, 9, 10314, 6, -1, 4, 22, 1, 6, 0, 51, 29, 65, 0, 9, 10314, 19, 15, 10325, 45, 62, -1, 60, 65, 0, 9, 10623, 22, 0, 27, 70, 55, 39, 1, 0, 1, 6, -1, 1, 64, 8536, 16, -1, 54, 16, 2, 9, 10355, 55, 6, -1, 1, 64, 9968, 48, -21, 54, 16, 2, 9, 10364, 55, 64, 6088, 0, 2, 62, -1, 2, 64, 6088, 0, 2, 6, 0, 249, 22, 2, 64, 1644, 4, -4, 6, 0, 248, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 64, 10164, 20, 10, 6, -1, 1, 22, 2, 6, 0, 55, 29, 9, 10445, 64, 10164, 20, 10, 6, -1, 1, 22, 2, 6, 0, 55, 29, 16, 2, 9, 10441, 55, 64, 6088, 0, 2, 43, -1, 2, 55, 6, -1, 2, 2, 9, 10477, 64, 11440, 24, -14, 6, -1, 1, 22, 2, 6, 0, 55, 29, 16, 2, 9, 10473, 55, 64, 6088, 0, 2, 43, -1, 2, 55, 6, -1, 2, 2, 9, 10536, 64, 4636, 12, -17, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 3, 6, -1, 3, 9, 10536, 64, 6088, 0, 2, 64, 10976, 4, -1, 22, 2, 6, -1, 3, 64, 3204, 16, 18, 54, 29, 16, 2, 9, 10532, 55, 64, 6088, 0, 2, 43, -1, 2, 55, 6, -1, 2, 2, 9, 10547, 34, 65, 0, 9, 10622, 6, -1, 2, 22, 1, 6, 0, 48, 29, 43, -1, 2, 55, 64, 1644, 4, -4, 22, 1, 6, -1, 2, 64, 8912, 8, 2, 54, 29, 62, -1, 4, 64, 7716, 4, 22, 22, 1, 6, 0, 279, 15, 0, 22, 2, 6, -1, 4, 64, 5016, 12, 15, 54, 29, 64, 9676, 8, 10, 54, 29, 62, -1, 5, 6, -1, 5, 22, 1, 6, 0, 51, 29, 65, 0, 9, 10622, 19, 15, 10633, 45, 62, -1, 61, 65, 0, 9, 10805, 22, 0, 27, 71, 55, 39, 1, 0, 1, 6, -1, 1, 64, 1904, 12, 18, 54, 16, 2, 9, 10659, 55, 64, 6088, 0, 2, 62, -1, 2, 64, 6088, 0, 2, 6, 0, 249, 22, 2, 64, 1644, 4, -4, 6, 0, 248, 22, 2, 6, -1, 2, 64, 3204, 16, 18, 54, 29, 64, 3204, 16, 18, 54, 29, 43, -1, 2, 55, 6, -1, 2, 2, 9, 10731, 64, 44, 28, 7, 6, -1, 1, 22, 2, 6, 0, 55, 29, 16, 2, 9, 10727, 55, 64, 6088, 0, 2, 43, -1, 2, 55, 6, -1, 2, 2, 9, 10742, 34, 65, 0, 9, 10804, 64, 1644, 4, -4, 22, 1, 6, -1, 2, 64, 8912, 8, 2, 54, 29, 62, -1, 3, 64, 7716, 4, 22, 22, 1, 6, 0, 279, 15, 0, 22, 2, 6, -1, 3, 64, 5016, 12, 15, 54, 29, 64, 9676, 8, 10, 54, 29, 62, -1, 4, 6, -1, 4, 22, 1, 6, 0, 51, 29, 65, 0, 9, 10804, 19, 15, 10815, 45, 62, -1, 62, 65, 0, 9, 11092, 22, 0, 27, 72, 55, 39, 2, 0, 1, 2, 6, -1, 1, 2, 16, 2, 9, 10843, 55, 6, -1, 1, 64, 3980, 48, -12, 54, 2, 9, 10850, 34, 65, 0, 9, 11091, 22, 0, 62, -1, 3, 6, -1, 2, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 10918, 64, 424, 4, 5, 6, -1, 2, 6, -1, 5, 54, 13, 64, 9424, 4, -8, 13, 22, 1, 6, -1, 3, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 5, 0, 55, 65, 0, 9, 10871, 0, 10956, 64, 8488, 4, -19, 22, 1, 6, -1, 3, 64, 9676, 8, 10, 54, 29, 22, 1, 6, -1, 1, 64, 3980, 48, -12, 54, 29, 43, -1, 6, 55, 5, 10952, 65, 0, 9, 10964, 62, -1, 7, 34, 65, 0, 9, 11091, 6, 0, 277, 6, -1, 6, 64, 3156, 16, 16, 54, 22, 2, 64, 11032, 8, -8, 40, 64, 3320, 4, 21, 54, 29, 62, -1, 8, 15, 0, 62, -1, 9, 6, -1, 9, 6, -1, 8, 12, 9, 11086, 6, -1, 6, 6, -1, 9, 54, 62, -1, 10, 15, 0, 62, -1, 11, 6, -1, 11, 6, -1, 4, 12, 9, 11077, 6, -1, 2, 6, -1, 11, 54, 22, 1, 6, -1, 10, 64, 10356, 56, -16, 54, 29, 62, -1, 12, 6, -1, 12, 22, 1, 6, 0, 54, 29, 9, 11068, 6, -1, 12, 65, 0, 9, 11091, 47, -1, 11, 0, 55, 65, 0, 9, 11020, 47, -1, 9, 0, 55, 65, 0, 9, 10996, 34, 65, 0, 9, 11091, 19, 15, 11102, 45, 62, -1, 63, 65, 0, 9, 11189, 22, 0, 27, 73, 55, 39, 2, 0, 1, 2, 6, -1, 1, 64, 9204, 12, 4, 18, 9, 11128, 65, 1, 65, 0, 9, 11188, 6, -1, 1, 64, 976, 12, 16, 18, 16, 9, 11174, 55, 6, -1, 2, 64, 9204, 12, 4, 18, 16, 2, 9, 11161, 55, 6, -1, 2, 64, 11312, 12, 12, 18, 16, 2, 9, 11174, 55, 6, -1, 2, 64, 5028, 8, 16, 18, 9, 11182, 65, 1, 65, 0, 9, 11188, 65, 0, 65, 0, 9, 11188, 19, 15, 11199, 45, 62, -1, 64, 65, 0, 9, 11412, 22, 0, 27, 74, 55, 39, 4, 0, 1, 2, 3, 4, 6, -1, 2, 64, 976, 12, 16, 18, 16, 9, 11236, 55, 6, -1, 3, 6, -1, 2, 22, 2, 6, 0, 63, 29, 2, 9, 11244, 65, 1, 65, 0, 9, 11411, 6, -1, 2, 64, 11340, 16, 4, 18, 16, 2, 9, 11265, 55, 6, -1, 2, 64, 7828, 16, -9, 18, 9, 11273, 65, 1, 65, 0, 9, 11411, 64, 3388, 12, 19, 64, 2780, 8, 10, 64, 1156, 16, 19, 64, 10304, 8, -4, 64, 6888, 16, 3, 64, 3764, 24, 15, 64, 2276, 16, 9, 64, 8388, 12, 16, 22, 8, 62, -1, 5, 6, -1, 4, 22, 1, 6, -1, 5, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 10, 9, 11336, 65, 1, 65, 0, 9, 11411, 64, 2436, 28, -9, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 6, 6, -1, 6, 64, 6088, 0, 2, 18, 16, 2, 9, 11373, 55, 6, -1, 6, 64, 220, 8, -1, 18, 16, 9, 11385, 55, 6, -1, 4, 64, 9204, 12, 4, 10, 16, 9, 11397, 55, 6, -1, 4, 64, 4880, 8, 4, 10, 9, 11405, 65, 1, 65, 0, 9, 11411, 65, 0, 65, 0, 9, 11411, 19, 15, 11422, 45, 62, -1, 65, 65, 0, 9, 11575, 22, 0, 27, 75, 55, 39, 4, 0, 1, 2, 3, 4, 6, -1, 3, 6, -1, 2, 22, 2, 6, 0, 63, 29, 9, 11456, 64, 9204, 12, 4, 65, 0, 9, 11574, 6, -1, 2, 64, 1920, 4, -21, 18, 16, 9, 11477, 55, 6, -1, 1, 22, 1, 6, 0, 57, 29, 9, 11487, 64, 4880, 8, 4, 65, 0, 9, 11574, 6, -1, 4, 64, 9204, 12, 4, 18, 9, 11505, 64, 9204, 12, 4, 65, 0, 9, 11574, 6, -1, 4, 64, 4880, 8, 4, 18, 9, 11523, 64, 4880, 8, 4, 65, 0, 9, 11574, 6, -1, 4, 6, -1, 3, 6, -1, 2, 6, -1, 1, 22, 4, 6, 0, 64, 29, 9, 11551, 64, 976, 12, 16, 65, 0, 9, 11574, 6, -1, 2, 64, 1920, 4, -21, 18, 9, 11569, 64, 4880, 8, 4, 65, 0, 9, 11574, 34, 65, 0, 9, 11574, 19, 15, 11585, 45, 62, -1, 66, 65, 0, 9, 11657, 22, 0, 27, 76, 55, 39, 1, 0, 1, 6, -1, 1, 64, 9204, 12, 4, 18, 9, 11612, 64, 6464, 8, 20, 65, 0, 9, 11656, 6, -1, 1, 64, 976, 12, 16, 18, 9, 11630, 64, 976, 12, 16, 65, 0, 9, 11656, 6, -1, 1, 64, 4880, 8, 4, 18, 9, 11648, 64, 4880, 8, 4, 65, 0, 9, 11656, 64, 6088, 0, 2, 65, 0, 9, 11656, 19, 15, 11667, 45, 62, -1, 67, 65, 0, 9, 11739, 22, 0, 27, 77, 55, 39, 2, 0, 1, 2, 6, -1, 2, 22, 1, 6, 0, 50, 29, 2, 9, 11694, 35, 65, 0, 9, 11738, 6, -1, 2, 22, 1, 6, -1, 1, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 18, 9, 11729, 6, -1, 2, 22, 1, 6, -1, 1, 64, 4628, 8, 2, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 11738, 19, 15, 11749, 45, 62, -1, 68, 65, 0, 9, 12228, 22, 0, 27, 78, 55, 39, 5, 0, 1, 2, 3, 4, 5, 6, -1, 2, 22, 1, 6, 0, 51, 29, 62, -1, 6, 6, -1, 6, 2, 9, 11785, 35, 65, 0, 9, 12227, 6, 0, 268, 22, 1, 6, -1, 6, 64, 8912, 8, 2, 54, 29, 62, -1, 7, 64, 7716, 4, 22, 22, 1, 6, 0, 279, 15, 0, 22, 2, 6, -1, 7, 64, 5016, 12, 15, 54, 29, 64, 9676, 8, 10, 54, 29, 62, -1, 8, 6, -1, 3, 22, 1, 6, 0, 66, 29, 62, -1, 9, 64, 6088, 0, 2, 62, -1, 10, 64, 6088, 0, 2, 62, -1, 11, 6, -1, 9, 2, 9, 11883, 6, -1, 8, 43, -1, 10, 55, 6, -1, 6, 43, -1, 11, 55, 65, 0, 9, 12157, 6, -1, 3, 64, 976, 12, 16, 18, 9, 12015, 6, -1, 4, 16, 2, 9, 11905, 55, 64, 6088, 0, 2, 22, 1, 6, 0, 51, 29, 62, -1, 12, 6, -1, 12, 16, 9, 11929, 55, 6, -1, 12, 64, 3468, 28, -12, 10, 16, 9, 11951, 55, 6, -1, 12, 22, 1, 6, -1, 6, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 18, 62, -1, 13, 6, -1, 9, 6, 0, 278, 13, 62, -1, 14, 6, -1, 13, 9, 11989, 6, -1, 9, 6, 0, 278, 13, 6, -1, 12, 13, 64, 7716, 4, 22, 13, 43, -1, 14, 55, 6, -1, 14, 6, -1, 8, 13, 43, -1, 10, 55, 6, -1, 9, 6, -1, 6, 13, 43, -1, 11, 55, 65, 0, 9, 12157, 6, -1, 8, 62, -1, 15, 6, -1, 6, 62, -1, 16, 6, -1, 9, 6, 0, 278, 13, 22, 1, 6, -1, 16, 64, 3588, 12, 4, 54, 29, 15, 0, 18, 9, 12127, 6, -1, 9, 64, 3156, 16, 16, 54, 15, 1, 13, 22, 1, 6, -1, 16, 64, 4132, 48, -14, 54, 29, 43, -1, 16, 55, 64, 7716, 4, 22, 22, 1, 6, -1, 16, 64, 8912, 8, 2, 54, 29, 43, -1, 7, 55, 64, 7716, 4, 22, 22, 1, 6, 0, 279, 15, 0, 22, 2, 6, -1, 7, 64, 5016, 12, 15, 54, 29, 64, 9676, 8, 10, 54, 29, 43, -1, 15, 55, 6, -1, 9, 6, 0, 278, 13, 6, -1, 15, 13, 43, -1, 10, 55, 6, -1, 9, 6, 0, 278, 13, 6, -1, 16, 13, 43, -1, 11, 55, 6, -1, 11, 62, -1, 17, 6, -1, 5, 22, 1, 6, 0, 50, 29, 9, 12185, 6, 0, 278, 6, -1, 5, 13, 21, -1, 17, 55, 6, -1, 17, 22, 1, 6, 0, 49, 29, 62, -1, 18, 6, -1, 10, 6, 0, 278, 13, 6, -1, 18, 13, 6, -1, 1, 22, 2, 6, 0, 67, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 12227, 19, 15, 12238, 45, 62, -1, 69, 65, 0, 9, 13153, 22, 0, 27, 79, 55, 39, 2, 0, 1, 2, 6, -1, 1, 2, 16, 2, 9, 12268, 55, 6, -1, 1, 64, 192, 12, 1, 54, 15, 1, 10, 9, 12275, 34, 65, 0, 9, 13152, 22, 0, 62, -1, 3, 22, 0, 6, -1, 1, 64, 6740, 24, -14, 54, 64, 2980, 24, -8, 54, 29, 62, -1, 4, 22, 0, 64, 480, 12, -10, 6, -1, 1, 22, 2, 6, 0, 55, 29, 16, 2, 9, 12323, 55, 64, 6088, 0, 2, 64, 2980, 24, -8, 54, 29, 62, -1, 5, 6, -1, 1, 22, 1, 6, 0, 56, 29, 62, -1, 6, 6, -1, 6, 6, -1, 5, 6, -1, 4, 6, -1, 1, 22, 4, 6, 0, 65, 29, 62, -1, 7, 6, -1, 7, 64, 4880, 8, 4, 18, 9, 12392, 64, 4636, 12, -17, 6, -1, 1, 22, 2, 6, 0, 55, 29, 65, 0, 9, 12393, 34, 62, -1, 8, 64, 9264, 44, -8, 64, 10980, 32, 12, 64, 10312, 20, -18, 64, 4228, 24, 22, 64, 6116, 12, -4, 64, 8352, 20, -9, 64, 3936, 20, 1, 64, 10140, 24, 15, 64, 1688, 44, -21, 22, 9, 62, -1, 9, 6, -1, 9, 64, 3156, 16, 16, 54, 62, -1, 10, 15, 0, 62, -1, 11, 6, -1, 11, 6, -1, 10, 12, 9, 12525, 6, -1, 9, 6, -1, 11, 54, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 12, 6, -1, 12, 22, 1, 6, 0, 54, 29, 9, 12516, 34, 6, -1, 5, 6, -1, 7, 6, -1, 12, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 65, 0, 9, 12525, 47, -1, 11, 0, 55, 65, 0, 9, 12453, 64, 9864, 8, -19, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 13, 6, -1, 13, 22, 1, 6, 0, 54, 29, 9, 12572, 34, 6, -1, 5, 6, -1, 7, 6, -1, 13, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 6, -1, 7, 16, 9, 12590, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 12638, 6, -1, 9, 6, -1, 1, 22, 2, 6, 0, 62, 29, 62, -1, 14, 6, -1, 14, 22, 1, 6, 0, 54, 29, 9, 12638, 34, 6, -1, 5, 6, -1, 7, 6, -1, 14, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 12770, 64, 3400, 20, 5, 64, 5248, 20, 3, 64, 9844, 20, 17, 64, 8100, 32, -18, 64, 44, 28, 7, 64, 1904, 12, 18, 22, 6, 62, -1, 15, 6, -1, 15, 64, 3156, 16, 16, 54, 62, -1, 16, 15, 0, 62, -1, 17, 6, -1, 17, 6, -1, 16, 12, 9, 12770, 6, -1, 15, 6, -1, 17, 54, 6, -1, 1, 22, 2, 6, 0, 55, 29, 62, -1, 18, 6, -1, 18, 22, 1, 6, 0, 54, 29, 9, 12761, 6, -1, 8, 6, -1, 5, 6, -1, 7, 6, -1, 18, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 65, 0, 9, 12770, 47, -1, 17, 0, 55, 65, 0, 9, 12696, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 12951, 6, -1, 1, 64, 7188, 20, 22, 54, 62, -1, 19, 6, -1, 19, 33, 64, 8592, 8, -6, 18, 16, 9, 12818, 55, 6, -1, 19, 64, 3156, 16, 16, 54, 15, 0, 41, 9, 12951, 64, 6088, 0, 2, 64, 1240, 8, 8, 22, 2, 64, 6168, 12, -5, 40, 53, 22, 1, 6, -1, 19, 64, 8912, 8, 2, 54, 29, 62, -1, 20, 6, 0, 277, 6, -1, 20, 64, 3156, 16, 16, 54, 22, 2, 64, 11032, 8, -8, 40, 64, 3320, 4, 21, 54, 29, 62, -1, 21, 15, 0, 62, -1, 22, 6, -1, 22, 6, -1, 21, 12, 9, 12951, 6, -1, 20, 6, -1, 22, 54, 22, 1, 6, 0, 59, 29, 62, -1, 23, 6, -1, 23, 9, 12942, 6, -1, 8, 6, -1, 20, 13, 6, -1, 5, 6, -1, 7, 6, -1, 23, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 65, 0, 9, 12951, 47, -1, 22, 0, 55, 65, 0, 9, 12882, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 13003, 6, -1, 1, 22, 1, 6, 0, 61, 29, 62, -1, 24, 6, -1, 24, 9, 13003, 6, -1, 8, 6, -1, 5, 6, -1, 7, 6, -1, 24, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 13055, 6, -1, 1, 22, 1, 6, 0, 60, 29, 62, -1, 25, 6, -1, 25, 9, 13055, 6, -1, 8, 6, -1, 5, 6, -1, 7, 6, -1, 25, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 13113, 6, -1, 7, 16, 2, 9, 13079, 55, 6, -1, 4, 6, 0, 278, 13, 64, 2548, 12, 6, 13, 62, -1, 26, 6, -1, 8, 6, -1, 5, 6, -1, 7, 6, -1, 26, 6, -1, 3, 22, 5, 6, 0, 68, 29, 55, 6, -1, 2, 9, 13125, 6, -1, 3, 65, 0, 9, 13152, 6, -1, 3, 15, 0, 54, 62, -1, 27, 6, -1, 27, 2, 9, 13145, 34, 65, 0, 9, 13152, 6, -1, 27, 65, 0, 9, 13152, 19, 15, 13163, 45, 62, -1, 70, 65, 0, 9, 13247, 22, 0, 27, 80, 55, 39, 1, 0, 1, 6, -1, 1, 2, 16, 2, 9, 13192, 55, 6, -1, 1, 64, 3156, 16, 16, 54, 15, 0, 18, 9, 13201, 6, -1, 1, 65, 0, 9, 13246, 6, -1, 1, 64, 3156, 16, 16, 54, 15, 4, 4, 9, 13222, 64, 4280, 8, -10, 65, 0, 9, 13246, 6, -1, 1, 64, 3156, 16, 16, 54, 22, 1, 64, 1376, 4, 4, 64, 8460, 16, 18, 54, 29, 65, 0, 9, 13246, 19, 15, 13257, 45, 62, -1, 71, 65, 0, 9, 13433, 22, 0, 27, 81, 55, 39, 1, 0, 1, 6, -1, 1, 15, 0, 54, 62, -1, 2, 6, -1, 2, 6, 0, 281, 18, 9, 13303, 6, -1, 1, 15, 1, 54, 16, 2, 9, 13299, 55, 64, 6088, 0, 2, 65, 0, 9, 13432, 6, -1, 2, 6, 0, 280, 18, 9, 13424, 6, -1, 1, 15, 3, 54, 62, -1, 3, 6, -1, 3, 9, 13345, 6, -1, 1, 15, 2, 54, 16, 2, 9, 13341, 55, 64, 6088, 0, 2, 65, 0, 9, 13432, 6, -1, 1, 15, 4, 54, 62, -1, 4, 64, 6088, 0, 2, 62, -1, 5, 6, -1, 4, 9, 13417, 6, -1, 4, 64, 3156, 16, 16, 54, 62, -1, 6, 15, 0, 62, -1, 7, 6, -1, 7, 6, -1, 6, 12, 9, 13417, 6, -1, 4, 6, -1, 7, 54, 22, 1, 6, 0, 71, 29, 21, -1, 5, 55, 47, -1, 7, 0, 55, 65, 0, 9, 13382, 6, -1, 5, 65, 0, 9, 13432, 64, 6088, 0, 2, 65, 0, 9, 13432, 19, 15, 13443, 45, 62, -1, 72, 65, 0, 9, 13936, 22, 0, 27, 82, 55, 39, 2, 0, 1, 2, 15, 13463, 45, 62, -1, 3, 65, 0, 9, 13882, 22, 0, 27, 83, 55, 39, 1, 0, 1, 6, -1, 1, 2, 16, 2, 9, 13491, 55, 6, -1, 1, 64, 192, 12, 1, 54, 34, 52, 9, 13509, 34, 65, 0, 64, 6088, 0, 2, 6, 0, 282, 22, 4, 65, 0, 9, 13881, 6, -1, 1, 64, 192, 12, 1, 54, 62, -1, 2, 65, 0, 62, -1, 3, 6, -1, 2, 15, 3, 18, 9, 13615, 6, -1, 1, 64, 3600, 20, 10, 54, 16, 2, 9, 13550, 55, 64, 6088, 0, 2, 62, -1, 4, 6, -1, 4, 6, -1, 1, 22, 2, 6, 82, 2, 29, 43, -1, 3, 55, 6, -1, 3, 9, 13587, 6, -1, 4, 22, 1, 6, 0, 70, 29, 65, 0, 9, 13590, 6, -1, 4, 62, -1, 5, 6, -1, 1, 6, -1, 3, 6, -1, 5, 6, 0, 281, 22, 4, 65, 0, 9, 13881, 65, 0, 9, 13863, 6, -1, 2, 15, 1, 18, 9, 13863, 6, -1, 1, 62, -1, 6, 22, 0, 62, -1, 7, 6, -1, 6, 64, 428, 32, -17, 54, 62, -1, 8, 64, 6088, 0, 2, 62, -1, 9, 6, -1, 8, 64, 3156, 16, 16, 54, 62, -1, 10, 15, 0, 62, -1, 11, 6, -1, 11, 6, -1, 10, 12, 9, 13730, 6, -1, 8, 6, -1, 11, 54, 22, 1, 6, 82, 3, 29, 62, -1, 12, 6, -1, 12, 22, 1, 6, -1, 7, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 12, 22, 1, 6, 0, 71, 29, 21, -1, 9, 55, 47, -1, 11, 0, 55, 65, 0, 9, 13668, 6, -1, 6, 64, 6740, 24, -14, 54, 9, 13760, 22, 0, 6, -1, 6, 64, 6740, 24, -14, 54, 64, 2980, 24, -8, 54, 29, 65, 0, 9, 13764, 64, 6088, 0, 2, 62, -1, 13, 6, -1, 13, 64, 976, 12, 16, 18, 16, 2, 9, 13788, 55, 6, -1, 13, 64, 11340, 16, 4, 18, 62, -1, 14, 6, -1, 14, 16, 2, 9, 13811, 55, 6, -1, 9, 6, -1, 6, 22, 2, 6, 82, 2, 29, 43, -1, 3, 55, 6, -1, 3, 9, 13833, 6, -1, 9, 22, 1, 6, 0, 70, 29, 65, 0, 9, 13836, 6, -1, 9, 62, -1, 15, 6, -1, 6, 6, -1, 7, 6, -1, 3, 6, -1, 15, 6, -1, 13, 6, 0, 280, 22, 6, 65, 0, 9, 13881, 6, -1, 1, 65, 0, 64, 6088, 0, 2, 6, 0, 282, 22, 4, 65, 0, 9, 13881, 19, 6, -1, 1, 2, 16, 2, 9, 13900, 55, 6, -1, 2, 33, 64, 10184, 12, 1, 10, 9, 13910, 64, 6088, 0, 2, 65, 0, 9, 13935, 6, -1, 1, 22, 1, 6, -1, 3, 29, 62, -1, 4, 6, -1, 4, 22, 1, 6, 0, 71, 29, 65, 0, 9, 13935, 19, 15, 13946, 45, 62, -1, 73, 65, 0, 9, 14117, 22, 0, 27, 84, 55, 39, 1, 0, 1, 6, -1, 1, 22, 1, 64, 3816, 28, -20, 40, 64, 2596, 12, 17, 54, 29, 2, 9, 13979, 34, 65, 0, 9, 14116, 22, 0, 6, -1, 1, 64, 5016, 12, 15, 54, 29, 62, -1, 2, 6, -1, 1, 64, 3156, 16, 16, 54, 62, -1, 3, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 3, 12, 9, 14109, 6, -1, 1, 6, -1, 4, 54, 62, -1, 5, 6, -1, 5, 33, 64, 8592, 8, -6, 18, 16, 9, 14053, 55, 6, -1, 5, 64, 3156, 16, 16, 54, 6, 0, 234, 41, 9, 14100, 6, -1, 5, 22, 1, 6, 0, 266, 64, 2856, 8, -3, 54, 29, 9, 14076, 34, 65, 0, 9, 14116, 6, 0, 234, 15, 0, 22, 2, 6, -1, 5, 64, 5016, 12, 15, 54, 29, 6, -1, 2, 6, -1, 4, 56, 55, 47, -1, 4, 0, 55, 65, 0, 9, 14009, 6, -1, 2, 65, 0, 9, 14116, 19, 15, 14127, 45, 62, -1, 74, 65, 0, 9, 14405, 22, 0, 27, 85, 55, 39, 1, 0, 1, 22, 0, 6, 0, 38, 29, 31, 64, 9348, 76, -21, 56, 55, 31, 64, 9348, 76, -21, 54, 22, 1, 6, 0, 39, 29, 2, 9, 14178, 6, 0, 291, 31, 64, 7916, 20, -19, 56, 55, 65, 0, 9, 14188, 6, 0, 290, 31, 64, 7916, 20, -19, 56, 55, 6, -1, 1, 22, 1, 6, 0, 75, 29, 31, 64, 3956, 24, -5, 56, 55, 31, 22, 1, 31, 64, 6248, 20, 19, 54, 64, 2900, 8, -13, 54, 29, 31, 64, 1256, 24, -4, 56, 55, 31, 64, 7916, 20, -19, 54, 6, 0, 290, 18, 9, 14259, 64, 2464, 20, -1, 22, 1, 6, 0, 40, 53, 31, 64, 7156, 32, 5, 56, 55, 65, 0, 9, 14288, 31, 64, 7916, 20, -19, 54, 6, 0, 291, 18, 9, 14288, 64, 2464, 20, -1, 22, 1, 6, 0, 41, 53, 31, 64, 7156, 32, 5, 56, 55, 22, 0, 6, 0, 44, 29, 31, 64, 3624, 20, -19, 56, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 31, 64, 1836, 44, -16, 56, 55, 0, 14392, 15, 14330, 45, 65, 0, 9, 14351, 22, 0, 27, 86, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 14350, 19, 22, 1, 31, 64, 1836, 44, -16, 54, 22, 0, 6, 0, 46, 29, 22, 2, 6, 0, 203, 22, 2, 31, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 14388, 65, 0, 9, 14395, 62, -1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 14404, 19, 15, 14415, 45, 62, -1, 75, 65, 0, 9, 14805, 22, 0, 27, 87, 55, 39, 1, 0, 1, 22, 0, 62, -1, 2, 6, -1, 1, 64, 11428, 12, -8, 54, 6, -1, 2, 6, 0, 283, 56, 55, 6, -1, 1, 64, 2568, 16, -5, 54, 6, -1, 2, 6, 0, 286, 56, 55, 6, -1, 1, 64, 10904, 24, 21, 54, 6, -1, 2, 6, 0, 288, 56, 55, 15, 0, 51, 6, -1, 2, 6, 0, 284, 56, 55, 15, 0, 51, 6, -1, 2, 6, 0, 285, 56, 55, 6, -1, 1, 64, 636, 32, 15, 54, 6, -1, 2, 6, 0, 287, 56, 55, 6, -1, 1, 64, 10904, 24, 21, 54, 6, -1, 2, 6, 0, 288, 56, 55, 6, -1, 1, 64, 9248, 16, -3, 54, 9, 14617, 15, 14548, 45, 65, 0, 9, 14593, 22, 0, 27, 88, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 33, 64, 8592, 8, -6, 18, 9, 14585, 6, -1, 2, 22, 1, 64, 6168, 12, -5, 40, 53, 65, 0, 9, 14592, 6, -1, 2, 65, 0, 9, 14592, 19, 22, 1, 6, -1, 1, 64, 9248, 16, -3, 54, 64, 2892, 4, 8, 54, 29, 6, -1, 2, 6, 0, 284, 56, 55, 6, -1, 1, 64, 7132, 16, -5, 54, 9, 14703, 15, 14634, 45, 65, 0, 9, 14679, 22, 0, 27, 89, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 33, 64, 8592, 8, -6, 18, 9, 14671, 6, -1, 2, 22, 1, 64, 6168, 12, -5, 40, 53, 65, 0, 9, 14678, 6, -1, 2, 65, 0, 9, 14678, 19, 22, 1, 6, -1, 1, 64, 7132, 16, -5, 54, 64, 2892, 4, 8, 54, 29, 6, -1, 2, 6, 0, 285, 56, 55, 6, -1, 1, 64, 2568, 16, -5, 54, 9, 14745, 64, 3004, 8, 19, 22, 1, 6, -1, 1, 64, 2568, 16, -5, 54, 64, 9676, 8, 10, 54, 29, 6, -1, 2, 6, 0, 287, 56, 55, 65, 0, 9, 14757, 64, 11256, 28, 20, 6, -1, 2, 6, 0, 287, 56, 55, 6, -1, 1, 64, 10904, 24, 21, 54, 9, 14787, 6, -1, 1, 64, 10904, 24, 21, 54, 6, -1, 2, 6, 0, 288, 56, 55, 65, 0, 9, 14797, 65, 0, 6, -1, 2, 6, 0, 288, 56, 55, 6, -1, 2, 65, 0, 9, 14804, 19, 15, 14815, 45, 62, -1, 76, 65, 0, 9, 15037, 22, 0, 27, 90, 55, 39, 3, 0, 1, 2, 3, 6, -1, 1, 2, 9, 14837, 34, 65, 0, 9, 15036, 6, -1, 3, 33, 64, 10292, 12, 13, 18, 9, 14855, 6, -1, 3, 65, 0, 9, 14857, 15, 2, 62, -1, 4, 6, -1, 1, 62, -1, 5, 15, 0, 62, -1, 6, 64, 760, 12, -1, 40, 64, 8492, 44, -14, 54, 62, -1, 7, 6, -1, 7, 64, 5856, 12, -7, 54, 33, 64, 10184, 12, 1, 18, 9, 14908, 64, 5856, 12, -7, 65, 0, 9, 14957, 6, -1, 7, 64, 8132, 28, 4, 54, 33, 64, 10184, 12, 1, 18, 9, 14932, 64, 8132, 28, 4, 65, 0, 9, 14957, 6, -1, 7, 64, 2392, 44, -8, 54, 33, 64, 10184, 12, 1, 18, 9, 14956, 64, 2392, 44, -8, 65, 0, 9, 14957, 34, 62, -1, 8, 6, -1, 5, 16, 9, 14974, 55, 6, -1, 6, 6, -1, 4, 4, 9, 15031, 6, -1, 8, 2, 9, 14987, 34, 65, 0, 9, 15036, 6, -1, 2, 22, 1, 6, -1, 5, 6, -1, 8, 54, 29, 9, 15009, 6, -1, 5, 65, 0, 9, 15036, 6, -1, 5, 64, 10876, 28, -9, 54, 43, -1, 5, 55, 15, 1, 21, -1, 6, 55, 65, 0, 9, 14960, 34, 65, 0, 9, 15036, 19, 15, 15047, 45, 62, -1, 77, 65, 0, 9, 15286, 22, 0, 27, 91, 55, 39, 0, 0, 7, 0, 31, 64, 11328, 12, -5, 56, 55, 64, 11404, 24, 4, 22, 0, 64, 8716, 16, 18, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 64, 4348, 52, -21, 15, 0, 64, 3136, 20, -8, 7, 0, 64, 1604, 8, 18, 7, 0, 64, 1808, 28, -11, 7, 0, 64, 6472, 24, 9, 65, 0, 64, 8940, 20, 12, 65, 0, 7, 8, 31, 64, 3032, 8, 16, 56, 55, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 295, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 296, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 297, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 298, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 299, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 300, 56, 55, 31, 22, 1, 31, 64, 4316, 32, 22, 54, 64, 2900, 8, -13, 54, 29, 31, 64, 4316, 32, 22, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 15285, 19, 15, 15296, 45, 62, -1, 78, 65, 0, 9, 15323, 22, 0, 27, 92, 55, 39, 0, 0, 22, 0, 31, 64, 11328, 12, -5, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 15322, 19, 15, 15333, 45, 62, -1, 79, 65, 0, 9, 15361, 22, 0, 27, 93, 55, 39, 0, 0, 15, 0, 51, 31, 64, 4808, 12, 15, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 15360, 19, 15, 15371, 45, 62, -1, 80, 65, 0, 9, 15508, 22, 0, 27, 94, 55, 39, 0, 0, 64, 356, 24, -16, 40, 64, 8076, 24, 8, 54, 62, -1, 1, 6, -1, 1, 2, 9, 15404, 15, 0, 65, 0, 9, 15507, 64, 6088, 0, 2, 62, -1, 2, 6, -1, 1, 22, 1, 64, 2168, 20, -19, 40, 64, 6520, 12, -11, 54, 29, 62, -1, 3, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 15494, 6, -1, 3, 6, -1, 5, 54, 62, -1, 6, 6, -1, 6, 64, 10028, 8, 14, 13, 6, -1, 1, 6, -1, 6, 54, 13, 21, -1, 2, 55, 47, -1, 5, 0, 55, 65, 0, 9, 15446, 6, -1, 2, 22, 1, 6, 0, 312, 29, 65, 0, 9, 15507, 19, 15, 15518, 45, 62, -1, 81, 65, 0, 9, 15562, 22, 0, 27, 95, 55, 39, 0, 0, 0, 15544, 22, 0, 6, 0, 80, 29, 65, 0, 9, 15561, 5, 15540, 65, 0, 9, 15552, 62, -1, 1, 34, 65, 0, 9, 15561, 64, 1172, 24, 7, 40, 65, 0, 9, 15561, 19, 15, 15572, 45, 62, -1, 82, 65, 0, 9, 15665, 22, 0, 27, 96, 55, 39, 0, 0, 0, 15647, 64, 9024, 16, 15, 22, 1, 64, 2204, 24, -11, 40, 64, 3220, 24, 0, 54, 29, 62, -1, 1, 6, -1, 1, 64, 3156, 16, 16, 54, 15, 0, 41, 9, 15634, 6, -1, 1, 15, 0, 54, 64, 9308, 16, 5, 54, 65, 0, 9, 15664, 65, 0, 9, 15641, 15, 1, 14, 65, 0, 9, 15664, 5, 15643, 65, 0, 9, 15655, 62, -1, 2, 34, 65, 0, 9, 15664, 64, 1172, 24, 7, 40, 65, 0, 9, 15664, 19, 15, 15675, 45, 62, -1, 83, 65, 0, 9, 15724, 22, 0, 27, 97, 55, 39, 0, 0, 0, 15706, 22, 0, 6, 0, 305, 64, 1620, 16, 8, 54, 29, 65, 0, 9, 15723, 5, 15702, 65, 0, 9, 15714, 62, -1, 1, 34, 65, 0, 9, 15723, 64, 1172, 24, 7, 40, 65, 0, 9, 15723, 19, 15, 15734, 45, 62, -1, 84, 65, 0, 9, 15783, 22, 0, 27, 98, 55, 39, 0, 0, 0, 15765, 22, 0, 6, 0, 167, 64, 1620, 16, 8, 54, 29, 65, 0, 9, 15782, 5, 15761, 65, 0, 9, 15773, 62, -1, 1, 34, 65, 0, 9, 15782, 64, 1172, 24, 7, 40, 65, 0, 9, 15782, 19, 15, 15793, 45, 62, -1, 85, 65, 0, 9, 15842, 22, 0, 27, 99, 55, 39, 0, 0, 0, 15824, 22, 0, 6, 0, 308, 64, 1620, 16, 8, 54, 29, 65, 0, 9, 15841, 5, 15820, 65, 0, 9, 15832, 62, -1, 1, 34, 65, 0, 9, 15841, 64, 1172, 24, 7, 40, 65, 0, 9, 15841, 19, 15, 15852, 45, 62, -1, 86, 65, 0, 9, 15917, 22, 0, 27, 100, 55, 39, 0, 0, 0, 15899, 15, 150, 15, 0, 22, 2, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 4636, 12, -17, 54, 64, 5016, 12, 15, 54, 29, 65, 0, 9, 15916, 5, 15895, 65, 0, 9, 15907, 62, -1, 1, 34, 65, 0, 9, 15916, 64, 1172, 24, 7, 40, 65, 0, 9, 15916, 19, 15, 15927, 45, 62, -1, 87, 65, 0, 9, 15992, 22, 0, 27, 101, 55, 39, 0, 0, 0, 15974, 15, 150, 15, 0, 22, 2, 64, 3300, 20, 7, 40, 64, 4512, 16, 8, 54, 64, 4636, 12, -17, 54, 64, 5016, 12, 15, 54, 29, 65, 0, 9, 15991, 5, 15970, 65, 0, 9, 15982, 62, -1, 1, 34, 65, 0, 9, 15991, 64, 1172, 24, 7, 40, 65, 0, 9, 15991, 19, 15, 16002, 45, 62, -1, 88, 65, 0, 9, 16051, 22, 0, 27, 102, 55, 39, 0, 0, 0, 16033, 22, 0, 6, 0, 311, 64, 1620, 16, 8, 54, 29, 65, 0, 9, 16050, 5, 16029, 65, 0, 9, 16041, 62, -1, 1, 34, 65, 0, 9, 16050, 64, 1172, 24, 7, 40, 65, 0, 9, 16050, 19, 15, 16061, 45, 62, -1, 89, 65, 0, 9, 16084, 22, 0, 27, 103, 55, 39, 0, 0, 64, 3324, 20, 14, 40, 64, 9176, 16, 0, 54, 65, 0, 9, 16083, 19, 15, 16094, 45, 62, -1, 90, 65, 0, 9, 16117, 22, 0, 27, 104, 55, 39, 0, 0, 64, 3324, 20, 14, 40, 64, 8228, 44, 20, 54, 65, 0, 9, 16116, 19, 15, 16127, 45, 62, -1, 91, 65, 0, 9, 16150, 22, 0, 27, 105, 55, 39, 0, 0, 64, 3324, 20, 14, 40, 64, 1568, 16, 11, 54, 65, 0, 9, 16149, 19, 15, 16160, 45, 62, -1, 92, 65, 0, 9, 16183, 22, 0, 27, 106, 55, 39, 0, 0, 64, 3324, 20, 14, 40, 64, 11100, 16, 14, 54, 65, 0, 9, 16182, 19, 15, 16193, 45, 62, -1, 93, 65, 0, 9, 16216, 22, 0, 27, 107, 55, 39, 0, 0, 64, 3324, 20, 14, 40, 64, 9040, 12, -3, 54, 65, 0, 9, 16215, 19, 15, 16226, 45, 62, -1, 94, 65, 0, 9, 16249, 22, 0, 27, 108, 55, 39, 0, 0, 64, 3284, 16, 8, 40, 64, 5284, 12, 10, 54, 65, 0, 9, 16248, 19, 15, 16259, 45, 62, -1, 95, 65, 0, 9, 16282, 22, 0, 27, 109, 55, 39, 0, 0, 64, 3284, 16, 8, 40, 64, 5600, 8, -6, 54, 65, 0, 9, 16281, 19, 15, 16292, 45, 62, -1, 96, 65, 0, 9, 16315, 22, 0, 27, 110, 55, 39, 0, 0, 64, 3284, 16, 8, 40, 64, 392, 32, -16, 54, 65, 0, 9, 16314, 19, 15, 16325, 45, 62, -1, 97, 65, 0, 9, 16348, 22, 0, 27, 111, 55, 39, 0, 0, 64, 3284, 16, 8, 40, 64, 4072, 24, -11, 54, 65, 0, 9, 16347, 19, 15, 16358, 45, 62, -1, 98, 65, 0, 9, 16381, 22, 0, 27, 112, 55, 39, 0, 0, 64, 3284, 16, 8, 40, 64, 1584, 20, 22, 54, 65, 0, 9, 16380, 19, 15, 16391, 45, 62, -1, 99, 65, 0, 9, 16414, 22, 0, 27, 113, 55, 39, 0, 0, 64, 3284, 16, 8, 40, 64, 2864, 28, -14, 54, 65, 0, 9, 16413, 19, 15, 16424, 45, 62, -1, 100, 65, 0, 9, 16442, 22, 0, 27, 114, 55, 39, 0, 0, 64, 11140, 28, 21, 40, 65, 0, 9, 16441, 19, 15, 16452, 45, 62, -1, 101, 65, 0, 9, 16521, 22, 0, 27, 115, 55, 39, 0, 0, 65, 0, 62, -1, 1, 0, 16510, 64, 6684, 24, 8, 22, 1, 64, 3300, 20, 7, 40, 64, 8732, 24, 6, 54, 29, 2, 2, 16, 9, 16500, 55, 64, 7720, 28, 18, 64, 356, 24, -16, 40, 1, 43, -1, 1, 55, 5, 16506, 65, 0, 9, 16513, 62, -1, 2, 6, -1, 1, 65, 0, 9, 16520, 19, 15, 16531, 45, 62, -1, 102, 65, 0, 9, 16554, 22, 0, 27, 116, 55, 39, 0, 0, 64, 3324, 20, 14, 40, 64, 10440, 76, -21, 54, 65, 0, 9, 16553, 19, 15, 16564, 45, 62, -1, 103, 65, 0, 9, 16698, 22, 0, 27, 117, 55, 39, 0, 0, 64, 5964, 12, 16, 40, 33, 64, 1172, 24, 7, 18, 16, 2, 9, 16599, 55, 64, 5964, 12, 16, 40, 64, 2828, 28, 13, 54, 2, 9, 16606, 34, 65, 0, 9, 16697, 22, 0, 64, 5964, 12, 16, 40, 64, 2828, 28, 13, 54, 29, 62, -1, 1, 6, -1, 1, 64, 6268, 24, 13, 54, 33, 64, 10184, 12, 1, 10, 9, 16643, 34, 65, 0, 9, 16697, 22, 0, 6, -1, 1, 64, 6268, 24, 13, 54, 29, 62, -1, 2, 6, -1, 2, 16, 9, 16678, 55, 6, -1, 2, 64, 7e3, 16, 11, 54, 33, 64, 8592, 8, -6, 18, 9, 16692, 6, -1, 2, 64, 7e3, 16, 11, 54, 65, 0, 9, 16693, 34, 65, 0, 9, 16697, 19, 15, 16708, 45, 62, -1, 104, 65, 0, 9, 16842, 22, 0, 27, 118, 55, 39, 0, 0, 64, 5964, 12, 16, 40, 33, 64, 1172, 24, 7, 18, 16, 2, 9, 16743, 55, 64, 5964, 12, 16, 40, 64, 2828, 28, 13, 54, 2, 9, 16750, 34, 65, 0, 9, 16841, 22, 0, 64, 5964, 12, 16, 40, 64, 2828, 28, 13, 54, 29, 62, -1, 1, 6, -1, 1, 64, 6268, 24, 13, 54, 33, 64, 10184, 12, 1, 10, 9, 16787, 34, 65, 0, 9, 16841, 22, 0, 6, -1, 1, 64, 6268, 24, 13, 54, 29, 62, -1, 2, 6, -1, 2, 16, 9, 16822, 55, 6, -1, 2, 64, 4848, 16, 3, 54, 33, 64, 8592, 8, -6, 18, 9, 16836, 6, -1, 2, 64, 4848, 16, 3, 54, 65, 0, 9, 16837, 34, 65, 0, 9, 16841, 19, 15, 16852, 45, 62, -1, 105, 65, 0, 9, 16891, 22, 0, 27, 119, 55, 39, 0, 0, 64, 5992, 16, -2, 22, 1, 64, 4288, 8, -1, 40, 53, 62, -1, 1, 22, 0, 6, -1, 1, 64, 6532, 60, -14, 54, 29, 65, 0, 9, 16890, 19, 15, 16901, 45, 62, -1, 106, 65, 0, 9, 17142, 22, 0, 27, 120, 55, 39, 0, 0, 0, 17124, 64, 5992, 16, -2, 22, 1, 64, 4288, 8, -1, 40, 53, 62, -1, 1, 64, 5988, 4, 7, 22, 1, 15, 11, 15, 1, 22, 2, 6, -1, 1, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 64, 5016, 12, 15, 54, 29, 64, 8912, 8, 2, 54, 29, 62, -1, 2, 6, -1, 2, 15, 0, 54, 62, -1, 3, 6, -1, 2, 15, 1, 54, 62, -1, 4, 6, -1, 2, 15, 2, 54, 62, -1, 5, 64, 6088, 0, 2, 6, -1, 4, 13, 64, 10976, 4, -1, 13, 6, -1, 5, 13, 64, 10976, 4, -1, 13, 6, -1, 3, 13, 62, -1, 6, 64, 6088, 0, 2, 6, -1, 3, 13, 64, 5988, 4, 7, 13, 6, -1, 4, 13, 64, 5988, 4, 7, 13, 6, -1, 5, 13, 62, -1, 7, 6, -1, 6, 22, 1, 64, 4288, 8, -1, 40, 53, 8, 62, -1, 8, 6, -1, 7, 22, 1, 64, 4288, 8, -1, 40, 53, 8, 62, -1, 9, 6, -1, 8, 6, -1, 9, 37, 15, 6e4, 60, 8, 62, -1, 10, 6, -1, 10, 22, 1, 64, 11032, 8, -8, 40, 64, 11168, 12, -12, 54, 29, 65, 0, 9, 17141, 5, 17120, 65, 0, 9, 17132, 62, -1, 11, 34, 65, 0, 9, 17141, 64, 1172, 24, 7, 40, 65, 0, 9, 17141, 19, 15, 17152, 45, 62, -1, 107, 65, 0, 9, 17248, 22, 0, 27, 121, 55, 39, 0, 0, 15, 2018, 15, 1976, 15, 1952, 15, 1921, 15, 1879, 22, 5, 62, -1, 1, 15, 0, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 3, 6, -1, 1, 64, 3156, 16, 16, 54, 12, 9, 17240, 64, 460, 12, 4, 6, -1, 1, 6, -1, 3, 54, 13, 22, 1, 64, 4288, 8, -1, 40, 53, 22, 1, 64, 1072, 28, -14, 40, 29, 21, -1, 2, 55, 47, -1, 3, 0, 55, 65, 0, 9, 17185, 6, -1, 2, 65, 0, 9, 17247, 19, 15, 17258, 45, 62, -1, 108, 65, 0, 9, 17337, 22, 0, 27, 122, 55, 39, 0, 0, 64, 5992, 16, -2, 22, 1, 64, 4288, 8, -1, 40, 53, 22, 1, 64, 8044, 32, -18, 40, 29, 22, 1, 64, 6088, 0, 2, 64, 5036, 24, -3, 22, 2, 64, 6168, 12, -5, 40, 53, 64, 5476, 8, 15, 54, 29, 62, -1, 1, 6, -1, 1, 9, 17328, 6, -1, 1, 15, 1, 54, 65, 0, 9, 17332, 64, 6088, 0, 2, 65, 0, 9, 17336, 19, 15, 17347, 45, 62, -1, 109, 65, 0, 9, 17374, 22, 0, 27, 123, 55, 39, 0, 0, 15, 4, 31, 64, 5060, 24, -7, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 17373, 19, 15, 17384, 45, 62, -1, 110, 65, 0, 9, 17594, 22, 0, 27, 124, 55, 39, 2, 0, 1, 2, 64, 2196, 8, -8, 22, 1, 64, 3300, 20, 7, 40, 64, 2028, 36, 4, 54, 29, 62, -1, 3, 64, 6904, 12, 2, 6, -1, 2, 13, 43, -1, 7, 55, 64, 11400, 4, -5, 6, -1, 1, 13, 43, -1, 8, 55, 15, 0, 43, -1, 4, 55, 6, -1, 4, 6, -1, 3, 64, 3156, 16, 16, 54, 12, 9, 17588, 6, -1, 3, 6, -1, 4, 54, 43, -1, 5, 55, 6, -1, 5, 64, 10356, 56, -16, 54, 9, 17498, 64, 3192, 12, -9, 22, 1, 6, -1, 5, 64, 10356, 56, -16, 54, 29, 65, 0, 9, 17499, 34, 43, -1, 6, 55, 6, -1, 6, 2, 9, 17530, 6, -1, 5, 64, 3192, 12, -9, 54, 16, 2, 9, 17526, 55, 64, 6088, 0, 2, 43, -1, 6, 55, 6, -1, 7, 22, 1, 6, -1, 6, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 10, 16, 9, 17570, 55, 6, -1, 8, 22, 1, 6, -1, 6, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 10, 9, 17579, 6, -1, 5, 65, 0, 9, 17593, 47, -1, 4, 0, 55, 65, 0, 9, 17444, 34, 65, 0, 9, 17593, 19, 15, 17604, 45, 62, -1, 111, 65, 0, 9, 18097, 22, 0, 27, 125, 55, 39, 1, 0, 1, 0, 18053, 64, 1156, 16, 19, 62, -1, 2, 34, 62, -1, 3, 6, -1, 1, 64, 9800, 8, 13, 54, 62, -1, 4, 6, -1, 4, 15, 0, 51, 10, 16, 9, 17660, 55, 6, -1, 4, 64, 880, 8, -22, 54, 15, 0, 51, 10, 9, 18047, 6, -1, 4, 64, 880, 8, -22, 54, 64, 3712, 4, 14, 18, 9, 17816, 6, -1, 1, 64, 3788, 12, 6, 54, 64, 356, 24, -16, 40, 18, 9, 17779, 6, -1, 4, 64, 472, 4, 1, 54, 15, 2, 18, 9, 17714, 64, 5868, 40, -20, 43, -1, 2, 55, 6, -1, 2, 6, -1, 4, 64, 4900, 4, 13, 54, 22, 2, 6, 0, 110, 29, 43, -1, 3, 55, 6, -1, 3, 34, 42, 9, 17775, 6, -1, 3, 64, 3192, 12, -9, 54, 6, -1, 3, 64, 124, 24, -6, 54, 22, 2, 22, 1, 6, 0, 321, 15, 0, 54, 64, 4628, 8, 2, 54, 29, 55, 65, 0, 9, 17812, 6, -1, 1, 64, 280, 12, -9, 54, 6, -1, 1, 64, 3788, 12, 6, 54, 22, 2, 22, 1, 6, 0, 321, 15, 0, 54, 64, 4628, 8, 2, 54, 29, 55, 65, 0, 9, 18047, 6, -1, 4, 64, 880, 8, -22, 54, 64, 1612, 8, 9, 18, 9, 17954, 6, -1, 1, 64, 3788, 12, 6, 54, 64, 356, 24, -16, 40, 18, 9, 17925, 6, -1, 4, 64, 472, 4, 1, 54, 15, 2, 18, 9, 17868, 64, 5868, 40, -20, 43, -1, 2, 55, 6, -1, 2, 6, -1, 4, 64, 4900, 4, 13, 54, 22, 2, 6, 0, 110, 29, 43, -1, 3, 55, 6, -1, 3, 34, 42, 9, 17921, 6, -1, 3, 64, 3192, 12, -9, 54, 6, -1, 3, 64, 124, 24, -6, 54, 22, 2, 6, 0, 321, 15, 1, 56, 55, 65, 0, 9, 17950, 6, -1, 1, 64, 280, 12, -9, 54, 6, -1, 1, 64, 3788, 12, 6, 54, 22, 2, 6, 0, 321, 15, 1, 56, 55, 65, 0, 9, 18047, 6, -1, 4, 64, 880, 8, -22, 54, 64, 8920, 4, -7, 18, 9, 18047, 6, -1, 4, 64, 11324, 4, 0, 54, 34, 52, 9, 17986, 35, 65, 0, 9, 18096, 6, 0, 321, 15, 2, 54, 6, -1, 4, 64, 11324, 4, 0, 54, 54, 34, 42, 9, 18047, 6, -1, 4, 64, 3712, 4, 14, 54, 6, -1, 4, 64, 10136, 4, 9, 54, 22, 2, 22, 1, 6, 0, 321, 15, 2, 54, 6, -1, 4, 64, 11324, 4, 0, 54, 54, 64, 4628, 8, 2, 54, 29, 55, 5, 18049, 65, 0, 9, 18087, 62, -1, 5, 64, 11068, 32, -20, 6, -1, 5, 64, 11068, 32, -20, 54, 7, 1, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 3728, 36, 21, 22, 4, 11, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18096, 19, 15, 18107, 45, 62, -1, 112, 65, 0, 9, 18445, 22, 0, 27, 126, 55, 39, 3, 0, 1, 2, 3, 0, 18401, 6, -1, 1, 64, 9800, 8, 13, 54, 62, -1, 4, 6, -1, 4, 15, 0, 51, 10, 16, 9, 18154, 55, 6, -1, 4, 64, 880, 8, -22, 54, 15, 0, 51, 10, 9, 18395, 6, -1, 4, 64, 880, 8, -22, 54, 64, 11372, 4, -6, 18, 9, 18395, 6, -1, 4, 64, 4900, 4, 13, 54, 34, 42, 16, 9, 18197, 55, 6, -1, 4, 64, 4900, 4, 13, 54, 6, -1, 3, 10, 9, 18204, 35, 65, 0, 9, 18444, 15, 18211, 45, 65, 0, 9, 18261, 22, 0, 27, 127, 55, 39, 1, 0, 1, 64, 11068, 32, -20, 6, -1, 1, 64, 11068, 32, -20, 54, 7, 1, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 8600, 16, 5, 22, 4, 11, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18260, 19, 22, 1, 15, 18270, 45, 65, 0, 9, 18374, 22, 0, 27, 128, 55, 39, 0, 0, 64, 1376, 4, 4, 64, 11324, 4, 0, 6, 126, 4, 64, 11324, 4, 0, 54, 64, 3712, 4, 14, 6, 0, 313, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 22, 1, 6, 0, 114, 29, 64, 10136, 4, 9, 6, 126, 2, 64, 880, 8, -22, 64, 8920, 4, -7, 64, 3788, 12, 6, 64, 8076, 24, 8, 7, 5, 22, 2, 64, 356, 24, -16, 40, 64, 3112, 24, -13, 54, 64, 4648, 24, 10, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18373, 19, 22, 1, 22, 0, 6, 0, 113, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 18397, 65, 0, 9, 18435, 62, -1, 5, 64, 11068, 32, -20, 6, -1, 5, 64, 11068, 32, -20, 54, 7, 1, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 3516, 48, 18, 22, 4, 11, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18444, 19, 15, 18455, 45, 62, -1, 113, 65, 0, 9, 18819, 22, 0, 27, 129, 55, 39, 0, 0, 15, 18473, 45, 62, -1, 1, 65, 0, 9, 18722, 22, 0, 27, 130, 55, 39, 2, 0, 1, 2, 15, 18490, 45, 65, 0, 9, 18555, 22, 0, 27, 131, 55, 39, 2, 0, 1, 2, 15, 25, 15, 18509, 45, 65, 0, 9, 18536, 22, 0, 27, 132, 55, 39, 0, 0, 64, 5656, 8, 0, 22, 1, 64, 8584, 8, -4, 40, 53, 22, 1, 6, 131, 2, 29, 19, 22, 2, 64, 2064, 24, 21, 40, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18554, 19, 22, 1, 64, 5084, 12, 4, 40, 53, 62, -1, 3, 15, 18573, 45, 65, 0, 9, 18625, 22, 0, 27, 133, 62, -1, 0, 39, 1, 1, 2, 64, 11068, 32, -20, 6, -1, 2, 64, 11068, 32, -20, 54, 7, 1, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 9008, 16, -8, 22, 4, 11, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18624, 19, 22, 1, 15, 18634, 45, 65, 0, 9, 18666, 22, 0, 27, 134, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 6, 0, 313, 6, 130, 2, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18665, 19, 22, 1, 6, -1, 3, 22, 0, 6, -1, 1, 29, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 22, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 2188, 8, 16, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 18721, 19, 22, 0, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 3, 6, 0, 314, 64, 3156, 16, 16, 54, 12, 9, 18798, 6, 0, 314, 6, -1, 3, 54, 33, 64, 10184, 12, 1, 18, 9, 18789, 6, -1, 3, 6, 0, 314, 6, -1, 3, 54, 22, 2, 6, -1, 1, 29, 22, 1, 6, -1, 2, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 3, 0, 55, 65, 0, 9, 18732, 6, -1, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 10776, 8, 3, 54, 29, 65, 0, 9, 18818, 19, 15, 18829, 45, 62, -1, 114, 65, 0, 9, 18846, 22, 0, 27, 135, 55, 39, 1, 0, 1, 6, -1, 1, 65, 0, 9, 18845, 19, 15, 18856, 45, 62, -1, 115, 65, 0, 9, 18998, 22, 0, 27, 136, 55, 39, 2, 0, 1, 2, 15, 18873, 45, 65, 0, 9, 18939, 22, 0, 27, 137, 55, 39, 2, 0, 1, 2, 6, 136, 2, 15, 18893, 45, 65, 0, 9, 18920, 22, 0, 27, 138, 55, 39, 0, 0, 64, 10036, 20, -16, 22, 1, 64, 8584, 8, -4, 40, 53, 22, 1, 6, 137, 2, 29, 19, 22, 2, 64, 2064, 24, 21, 40, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 18938, 19, 22, 1, 64, 5084, 12, 4, 40, 53, 62, -1, 3, 22, 0, 6, -1, 1, 29, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 62, -1, 4, 6, -1, 3, 6, -1, 4, 22, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 2188, 8, 16, 54, 29, 65, 0, 9, 18997, 19, 15, 19008, 45, 62, -1, 116, 65, 0, 9, 19345, 22, 0, 27, 139, 55, 39, 4, 0, 1, 2, 3, 4, 64, 5952, 12, -16, 43, 0, 322, 55, 6, -1, 1, 33, 64, 10292, 12, 13, 10, 16, 2, 9, 19048, 55, 6, -1, 1, 15, 2, 41, 9, 19056, 15, 0, 43, -1, 1, 55, 6, -1, 4, 9, 19071, 6, -1, 1, 15, 1, 13, 65, 0, 9, 19073, 15, 1, 62, -1, 5, 15, 19083, 45, 65, 0, 9, 19332, 22, 0, 27, 140, 62, -1, 0, 39, 2, 1, 2, 3, 15, 19105, 45, 62, -1, 4, 65, 0, 9, 19319, 22, 0, 27, 141, 55, 39, 1, 0, 1, 64, 7980, 4, 13, 6, -1, 1, 13, 43, 0, 322, 55, 0, 19296, 6, 0, 321, 15, 2, 54, 6, 139, 3, 54, 62, -1, 2, 6, -1, 2, 64, 3156, 16, 16, 54, 6, 139, 5, 10, 62, -1, 3, 6, -1, 2, 15, 0, 51, 18, 16, 2, 9, 19171, 55, 6, -1, 3, 62, -1, 4, 6, -1, 4, 16, 9, 19187, 55, 6, -1, 1, 15, 30, 12, 9, 19259, 6, -1, 1, 15, 10, 12, 9, 19203, 15, 1, 65, 0, 9, 19205, 15, 3, 62, -1, 5, 6, -1, 5, 15, 19218, 45, 65, 0, 9, 19246, 22, 0, 27, 142, 62, -1, 0, 39, 0, 1, 6, 141, 1, 6, 141, 5, 13, 22, 1, 6, 140, 4, 29, 65, 0, 9, 19245, 19, 22, 2, 64, 2064, 24, 21, 40, 29, 55, 65, 0, 9, 19290, 64, 6976, 4, 4, 43, 0, 322, 55, 6, -1, 2, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 22, 1, 6, 140, 2, 29, 55, 5, 19292, 65, 0, 9, 19309, 62, -1, 6, 6, -1, 6, 22, 1, 6, 140, 3, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 19318, 19, 15, 0, 22, 1, 6, -1, 4, 29, 65, 0, 9, 19331, 19, 22, 1, 64, 5084, 12, 4, 40, 53, 65, 0, 9, 19344, 19, 15, 19355, 45, 62, -1, 118, 65, 0, 9, 19499, 22, 0, 27, 143, 55, 39, 2, 0, 1, 2, 15, 0, 62, -1, 3, 15, 0, 62, -1, 4, 6, -1, 4, 6, 0, 321, 15, 0, 54, 64, 3156, 16, 16, 54, 12, 9, 19491, 6, 0, 321, 15, 0, 54, 6, -1, 4, 54, 15, 0, 54, 34, 42, 9, 19482, 6, 0, 321, 15, 0, 54, 6, -1, 4, 54, 15, 1, 54, 64, 11324, 4, 0, 6, -1, 2, 64, 4900, 4, 13, 6, -1, 1, 64, 880, 8, -22, 64, 11372, 4, -6, 64, 3788, 12, 6, 64, 8076, 24, 8, 7, 4, 22, 2, 6, 0, 321, 15, 0, 54, 6, -1, 4, 54, 15, 0, 54, 64, 4648, 24, 10, 54, 29, 55, 15, 1, 21, -1, 3, 55, 47, -1, 4, 0, 55, 65, 0, 9, 19375, 6, -1, 3, 65, 0, 9, 19498, 19, 15, 19509, 45, 62, -1, 119, 65, 0, 9, 19896, 22, 0, 27, 144, 55, 39, 4, 0, 1, 2, 3, 4, 6, -1, 2, 34, 52, 9, 19533, 35, 65, 0, 9, 19895, 0, 19805, 15, 0, 62, -1, 5, 6, -1, 3, 16, 9, 19551, 55, 6, -1, 4, 2, 9, 19569, 6, -1, 2, 6, -1, 1, 22, 2, 6, 0, 118, 29, 43, -1, 5, 55, 64, 4780, 4, 20, 43, 0, 322, 55, 22, 0, 6, 0, 113, 29, 62, -1, 6, 15, 19593, 45, 65, 0, 9, 19638, 22, 0, 27, 145, 55, 39, 1, 0, 1, 64, 5588, 12, -12, 6, -1, 1, 7, 1, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 10728, 24, 5, 22, 4, 11, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 19637, 19, 22, 1, 15, 19647, 45, 65, 0, 9, 19778, 22, 0, 27, 146, 62, -1, 0, 39, 0, 1, 64, 11464, 4, -15, 43, 0, 322, 55, 6, 0, 313, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 22, 1, 6, 0, 114, 29, 15, 0, 22, 2, 22, 1, 6, 0, 321, 15, 2, 54, 6, 144, 2, 54, 64, 4628, 8, 2, 54, 29, 55, 6, 144, 4, 9, 19755, 6, 0, 321, 15, 2, 54, 6, 144, 2, 54, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 19777, 6, 144, 3, 6, 144, 2, 6, 144, 1, 6, 144, 5, 22, 4, 6, 0, 116, 29, 65, 0, 9, 19777, 19, 22, 1, 6, -1, 6, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 19895, 5, 19801, 65, 0, 9, 19886, 62, -1, 7, 64, 11068, 32, -20, 6, -1, 7, 64, 11068, 32, -20, 54, 7, 1, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 0, 28, 1, 22, 4, 11, 29, 55, 15, 19846, 45, 65, 0, 9, 19874, 22, 0, 27, 147, 62, -1, 0, 39, 1, 1, 2, 22, 0, 6, -1, 2, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 19873, 19, 22, 1, 64, 5084, 12, 4, 40, 53, 65, 0, 9, 19895, 64, 1172, 24, 7, 40, 65, 0, 9, 19895, 19, 15, 19906, 45, 62, -1, 120, 65, 0, 9, 19954, 22, 0, 27, 148, 55, 39, 0, 0, 15, 15, 15, 2, 22, 2, 15, 36, 22, 1, 22, 0, 64, 11032, 8, -8, 40, 64, 1880, 12, -11, 54, 29, 64, 780, 36, -16, 54, 29, 64, 4132, 48, -14, 54, 29, 65, 0, 9, 19953, 19, 15, 19964, 45, 62, -1, 121, 65, 0, 9, 20048, 22, 0, 27, 149, 55, 39, 0, 0, 64, 5084, 12, 4, 40, 33, 64, 1172, 24, 7, 10, 16, 9, 20003, 55, 64, 5084, 12, 4, 40, 64, 2188, 8, 16, 54, 33, 64, 10184, 12, 1, 18, 16, 9, 20023, 55, 64, 5084, 12, 4, 40, 64, 10776, 8, 3, 54, 33, 64, 10184, 12, 1, 18, 16, 9, 20043, 55, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 33, 64, 10184, 12, 1, 18, 65, 0, 9, 20047, 19, 15, 20058, 45, 62, -1, 122, 65, 0, 9, 20357, 22, 0, 27, 150, 55, 39, 4, 0, 1, 2, 3, 4, 22, 0, 6, 0, 121, 29, 2, 9, 20084, 34, 65, 0, 9, 20356, 6, -1, 4, 15, 0, 51, 10, 16, 9, 20104, 55, 6, -1, 4, 22, 1, 6, 0, 123, 29, 9, 20111, 34, 65, 0, 9, 20356, 6, -1, 3, 33, 64, 2908, 20, 18, 10, 9, 20128, 65, 0, 43, -1, 3, 55, 6, -1, 2, 33, 64, 2908, 20, 18, 10, 9, 20145, 65, 1, 43, -1, 2, 55, 22, 0, 6, 0, 120, 29, 62, -1, 5, 22, 0, 6, 0, 321, 15, 2, 54, 6, -1, 5, 56, 55, 15, 20174, 45, 65, 0, 9, 20254, 22, 0, 27, 151, 62, -1, 0, 39, 1, 1, 2, 64, 4780, 4, 20, 43, 0, 322, 55, 64, 5908, 4, 12, 6, 0, 322, 64, 8436, 8, -18, 6, 150, 2, 64, 5588, 12, -12, 6, -1, 2, 7, 3, 64, 7600, 4, 17, 64, 5588, 12, -12, 64, 11116, 24, -5, 22, 4, 11, 29, 55, 6, 0, 321, 15, 2, 54, 6, 150, 5, 38, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 20253, 19, 22, 1, 15, 20263, 45, 65, 0, 9, 20293, 22, 0, 27, 152, 62, -1, 0, 39, 1, 1, 2, 6, 0, 321, 15, 2, 54, 6, 150, 5, 38, 55, 6, -1, 2, 65, 0, 9, 20292, 19, 22, 1, 15, 90, 15, 20304, 45, 65, 0, 9, 20334, 22, 0, 27, 153, 62, -1, 0, 39, 0, 1, 6, 150, 2, 6, 150, 5, 6, 150, 1, 22, 3, 6, 0, 119, 29, 65, 0, 9, 20333, 19, 22, 2, 6, 0, 115, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 20356, 19, 15, 20367, 45, 62, -1, 123, 65, 0, 9, 20474, 22, 0, 27, 154, 55, 39, 1, 0, 1, 6, -1, 1, 34, 52, 9, 20402, 64, 8552, 8, 10, 64, 7784, 36, 15, 22, 2, 11, 29, 55, 65, 0, 65, 0, 9, 20473, 6, 0, 323, 64, 3156, 16, 16, 54, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 3, 6, -1, 2, 12, 9, 20467, 15, 8, 15, 0, 22, 2, 6, -1, 1, 64, 5016, 12, 15, 54, 29, 6, 0, 323, 6, -1, 3, 54, 18, 9, 20458, 65, 1, 65, 0, 9, 20473, 47, -1, 3, 0, 55, 65, 0, 9, 20418, 65, 0, 65, 0, 9, 20473, 19, 15, 20484, 45, 62, -1, 124, 65, 0, 9, 20566, 22, 0, 27, 155, 55, 39, 1, 0, 1, 6, -1, 1, 15, 0, 18, 9, 20526, 6, 0, 111, 64, 11068, 32, -20, 22, 2, 64, 356, 24, -16, 40, 64, 6784, 72, -13, 54, 29, 55, 65, 0, 9, 20556, 6, 0, 325, 15, 0, 51, 10, 9, 20556, 6, 0, 325, 64, 11068, 32, -20, 22, 2, 64, 356, 24, -16, 40, 64, 6784, 72, -13, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 20565, 19, 15, 20576, 45, 62, -1, 125, 65, 0, 9, 20856, 22, 0, 27, 156, 55, 39, 2, 0, 1, 2, 6, -1, 1, 22, 1, 6, 0, 324, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 10, 9, 20611, 35, 65, 0, 9, 20855, 6, -1, 1, 22, 1, 6, 0, 324, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 1, 15, 0, 18, 9, 20659, 6, 0, 111, 64, 11068, 32, -20, 22, 2, 64, 356, 24, -16, 40, 64, 9692, 44, -12, 54, 29, 55, 65, 0, 9, 20846, 15, 20666, 45, 65, 0, 9, 20703, 22, 0, 27, 157, 62, -1, 0, 39, 1, 1, 2, 6, 156, 2, 6, 156, 1, 6, -1, 2, 22, 3, 6, 0, 112, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 20702, 19, 43, 0, 325, 55, 6, 0, 325, 64, 11068, 32, -20, 22, 2, 64, 356, 24, -16, 40, 64, 9692, 44, -12, 54, 29, 55, 64, 1376, 4, 4, 64, 4900, 4, 13, 6, -1, 2, 64, 472, 4, 1, 6, -1, 1, 64, 880, 8, -22, 64, 3712, 4, 14, 64, 3788, 12, 6, 64, 8076, 24, 8, 7, 4, 22, 2, 64, 356, 24, -16, 40, 64, 3112, 24, -13, 54, 64, 4648, 24, 10, 54, 29, 55, 6, -1, 1, 15, 2, 18, 9, 20846, 64, 1376, 4, 4, 64, 4900, 4, 13, 6, -1, 2, 64, 472, 4, 1, 6, -1, 1, 64, 880, 8, -22, 64, 1612, 8, 9, 64, 3788, 12, 6, 64, 8076, 24, 8, 7, 4, 22, 2, 64, 356, 24, -16, 40, 64, 3112, 24, -13, 54, 64, 4648, 24, 10, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 20855, 19, 15, 100, 62, -1, 127, 15, 101, 62, -1, 128, 15, 102, 62, -1, 129, 15, 110, 62, -1, 130, 15, 111, 62, -1, 131, 15, 112, 62, -1, 132, 15, 113, 62, -1, 133, 15, 120, 62, -1, 134, 15, 121, 62, -1, 135, 15, 130, 62, -1, 136, 15, 131, 62, -1, 137, 15, 140, 62, -1, 138, 15, 150, 62, -1, 139, 15, 151, 62, -1, 140, 15, 152, 62, -1, 141, 15, 160, 62, -1, 142, 15, 161, 62, -1, 143, 15, 162, 62, -1, 144, 15, 164, 62, -1, 145, 15, 165, 62, -1, 146, 15, 170, 62, -1, 147, 15, 171, 62, -1, 148, 15, 172, 62, -1, 149, 15, 173, 62, -1, 150, 15, 174, 62, -1, 151, 15, 180, 62, -1, 152, 15, 181, 62, -1, 153, 6, -1, 11, 6, -1, 0, 22, 2, 6, -1, 6, 29, 62, -1, 154, 6, -1, 8, 6, -1, 1, 22, 2, 6, -1, 6, 29, 62, -1, 155, 6, -1, 10, 6, -1, 2, 22, 2, 6, -1, 6, 29, 62, -1, 156, 6, -1, 9, 6, -1, 3, 22, 2, 6, -1, 7, 29, 62, -1, 157, 6, -1, 12, 6, -1, 4, 22, 2, 6, -1, 6, 29, 62, -1, 158, 15, 16, 62, -1, 159, 15, 15, 15, 1e3, 23, 62, -1, 160, 15, 12, 62, -1, 161, 15, 256, 62, -1, 162, 15, 1, 62, -1, 163, 15, 2, 62, -1, 164, 15, 3, 62, -1, 165, 15, 4, 62, -1, 166, 15, 21116, 45, 65, 0, 9, 21652, 22, 0, 27, 158, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 16, 2, 9, 21137, 55, 7, 0, 43, -1, 2, 55, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 56, 55, 6, -1, 2, 6, 0, 163, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 163, 56, 55, 6, -1, 2, 6, 0, 164, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 164, 56, 55, 6, -1, 2, 6, 0, 165, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 165, 56, 55, 6, -1, 2, 6, 0, 166, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 166, 56, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 56, 55, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 31, 64, 11328, 12, -5, 54, 6, 0, 139, 56, 55, 31, 64, 3032, 8, 16, 54, 64, 6472, 24, 9, 54, 65, 0, 18, 9, 21628, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 22, 1, 63, 53, 62, -1, 3, 6, 0, 158, 64, 10332, 16, 1, 6, 0, 166, 22, 3, 6, 0, 154, 64, 4740, 40, -18, 6, 0, 165, 22, 3, 6, 0, 154, 64, 5484, 40, -12, 6, 0, 165, 22, 3, 6, 0, 154, 64, 9764, 16, -1, 6, 0, 165, 22, 3, 6, 0, 156, 64, 6644, 40, -18, 6, 0, 164, 22, 3, 6, 0, 156, 64, 6720, 20, -14, 6, 0, 164, 22, 3, 6, 0, 157, 64, 5728, 28, 17, 6, 0, 163, 22, 3, 6, 0, 155, 64, 1940, 48, -17, 6, 0, 163, 22, 3, 6, 0, 155, 64, 11356, 16, 16, 6, 0, 163, 22, 3, 6, 0, 155, 64, 9744, 20, 21, 6, 0, 163, 22, 3, 22, 10, 62, -1, 4, 6, -1, 4, 64, 3156, 16, 16, 54, 62, -1, 5, 15, 0, 62, -1, 6, 6, -1, 6, 6, -1, 5, 12, 9, 21614, 6, -1, 4, 6, -1, 6, 54, 62, -1, 7, 6, -1, 7, 15, 1, 54, 62, -1, 8, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, -1, 7, 15, 0, 54, 54, 65, 1, 18, 9, 21605, 31, 64, 4316, 32, 22, 54, 6, -1, 8, 22, 2, 6, -1, 7, 15, 2, 54, 29, 62, -1, 9, 65, 1, 6, -1, 9, 6, -1, 8, 22, 3, 6, -1, 3, 64, 9692, 44, -12, 54, 29, 55, 65, 1, 6, -1, 9, 6, -1, 8, 6, -1, 3, 22, 4, 22, 1, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 54, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 6, 0, 55, 65, 0, 9, 21480, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 6472, 24, 9, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 8940, 20, 12, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 21651, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 204, 16, 21, 56, 55, 15, 21673, 45, 65, 0, 9, 21849, 22, 0, 27, 159, 62, -1, 0, 39, 0, 1, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 54, 9, 21825, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 54, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 3, 6, -1, 2, 64, 3156, 16, 16, 54, 12, 9, 21811, 6, -1, 2, 6, -1, 3, 54, 15, 0, 54, 62, -1, 4, 6, -1, 2, 6, -1, 3, 54, 15, 1, 54, 62, -1, 5, 6, -1, 2, 6, -1, 3, 54, 15, 2, 54, 62, -1, 6, 6, -1, 2, 6, -1, 3, 54, 15, 3, 54, 62, -1, 7, 6, -1, 7, 6, -1, 6, 6, -1, 5, 22, 3, 6, -1, 4, 64, 6784, 72, -13, 54, 29, 55, 47, -1, 3, 0, 55, 65, 0, 9, 21715, 22, 0, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 56, 55, 65, 0, 31, 64, 3032, 8, 16, 54, 64, 8940, 20, 12, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 21848, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 292, 8, 12, 56, 55, 15, 21870, 45, 65, 0, 9, 21896, 22, 0, 27, 160, 62, -1, 0, 39, 0, 1, 31, 64, 3032, 8, 16, 54, 64, 8716, 16, 18, 54, 65, 0, 9, 21895, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 6624, 12, -17, 56, 55, 15, 21917, 45, 65, 0, 9, 22151, 22, 0, 27, 161, 62, -1, 0, 39, 0, 1, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 22, 1, 64, 2168, 20, -19, 40, 64, 6520, 12, -11, 54, 29, 62, -1, 2, 6, -1, 2, 64, 3156, 16, 16, 54, 62, -1, 3, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 3, 12, 9, 22140, 6, -1, 2, 6, -1, 4, 54, 62, -1, 5, 22, 0, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 5, 54, 64, 1620, 16, 8, 54, 29, 31, 64, 11328, 12, -5, 54, 6, -1, 5, 56, 55, 6, -1, 5, 6, 0, 132, 52, 9, 22066, 22, 0, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 5, 54, 64, 732, 28, 16, 54, 29, 31, 64, 11328, 12, -5, 54, 6, 0, 133, 56, 55, 6, -1, 5, 6, 0, 136, 52, 9, 22109, 22, 0, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 5, 54, 64, 732, 28, 16, 54, 29, 31, 64, 11328, 12, -5, 54, 6, 0, 137, 56, 55, 6, -1, 5, 6, 0, 136, 52, 9, 22131, 22, 0, 31, 64, 11328, 12, -5, 54, 6, 0, 136, 56, 55, 47, -1, 4, 0, 55, 65, 0, 9, 21970, 31, 64, 11328, 12, -5, 54, 65, 0, 9, 22150, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 1620, 16, 8, 56, 55, 15, 22172, 45, 65, 0, 9, 22234, 22, 0, 27, 162, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 2, 22, 1, 64, 3172, 20, -16, 40, 29, 9, 22210, 6, -1, 2, 22, 1, 6, 0, 5, 29, 43, -1, 2, 55, 6, -1, 3, 31, 64, 11328, 12, -5, 54, 6, -1, 2, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 22233, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 380, 12, 14, 56, 55, 15, 22255, 45, 65, 0, 9, 22298, 22, 0, 27, 163, 62, -1, 0, 39, 0, 1, 7, 0, 31, 64, 11328, 12, -5, 56, 55, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 22297, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 11468, 12, 16, 56, 55, 15, 22319, 45, 65, 0, 9, 22357, 22, 0, 27, 164, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 3, 6, -1, 2, 22, 2, 31, 64, 4316, 32, 22, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 22356, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 4028, 44, -13, 56, 55, 15, 22378, 45, 65, 0, 9, 22698, 22, 0, 27, 165, 62, -1, 0, 39, 2, 1, 2, 3, 31, 64, 3032, 8, 16, 54, 64, 8940, 20, 12, 54, 65, 0, 18, 9, 22411, 35, 65, 0, 9, 22697, 0, 22668, 6, -1, 2, 22, 1, 64, 3172, 20, -16, 40, 29, 9, 22439, 6, -1, 2, 22, 1, 6, 0, 5, 29, 43, -1, 2, 55, 15, 10, 6, -1, 2, 22, 2, 64, 3916, 20, 18, 40, 29, 43, -1, 2, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 1, 37, 62, -1, 4, 6, -1, 3, 6, -1, 4, 54, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 37, 62, -1, 5, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 2, 54, 2, 9, 22605, 6, -1, 2, 6, 0, 132, 18, 16, 2, 9, 22529, 55, 6, -1, 2, 6, 0, 136, 18, 9, 22537, 65, 1, 65, 0, 9, 22539, 65, 0, 62, -1, 6, 6, -1, 6, 9, 22554, 6, 0, 162, 65, 0, 9, 22557, 6, 0, 161, 62, -1, 7, 6, -1, 7, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 6, 0, 160, 6, 0, 159, 22, 4, 58, 64, 7844, 16, -2, 54, 53, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 2, 56, 55, 6, -1, 3, 6, -1, 4, 54, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 37, 6, -1, 3, 6, -1, 4, 56, 55, 6, -1, 3, 6, -1, 5, 22, 2, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 2, 54, 64, 4628, 8, 2, 54, 29, 55, 5, 22664, 65, 0, 9, 22688, 62, -1, 8, 6, -1, 8, 64, 2148, 20, 17, 22, 2, 58, 64, 6980, 20, 17, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 22697, 19, 6, -1, 13, 64, 8492, 44, -14, 54, 64, 4316, 32, 22, 56, 55, 22, 0, 6, -1, 13, 53, 62, -1, 167, 15, 1, 62, -1, 168, 15, 2, 62, -1, 169, 64, 10104, 12, -5, 40, 33, 64, 1172, 24, 7, 10, 9, 22756, 22, 0, 64, 10104, 12, -5, 40, 53, 65, 0, 9, 22757, 34, 62, -1, 170, 15, 0, 62, -1, 171, 15, 1, 62, -1, 172, 15, 2, 62, -1, 173, 15, 3, 62, -1, 174, 15, 4, 62, -1, 175, 15, 5, 62, -1, 176, 15, 6, 62, -1, 177, 15, 7, 62, -1, 178, 15, 8, 62, -1, 179, 15, 9, 62, -1, 180, 15, 10, 62, -1, 181, 22, 0, 15, 22824, 45, 65, 0, 9, 22924, 22, 0, 27, 166, 62, -1, 0, 39, 0, 1, 7, 0, 62, -1, 2, 64, 4888, 4, 13, 15, 22850, 45, 65, 0, 9, 22883, 22, 0, 27, 167, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 3, 6, 166, 2, 6, -1, 2, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 22882, 19, 64, 2332, 8, -7, 15, 22894, 45, 65, 0, 9, 22917, 22, 0, 27, 168, 62, -1, 0, 39, 1, 1, 2, 6, 166, 2, 6, -1, 2, 54, 65, 0, 9, 22916, 19, 7, 2, 65, 0, 9, 22923, 19, 29, 62, -1, 182, 15, 0, 62, -1, 183, 15, 1, 62, -1, 184, 15, 2, 62, -1, 185, 15, 3, 62, -1, 186, 15, 10, 62, -1, 187, 15, 11, 62, -1, 188, 15, 12, 62, -1, 189, 15, 13, 62, -1, 190, 15, 20, 62, -1, 191, 15, 21, 62, -1, 192, 15, 30, 62, -1, 193, 15, 40, 62, -1, 194, 15, 41, 62, -1, 195, 15, 50, 62, -1, 196, 15, 51, 62, -1, 197, 15, 52, 62, -1, 198, 15, 53, 62, -1, 199, 15, 60, 62, -1, 200, 15, 61, 62, -1, 201, 15, 62, 62, -1, 202, 15, 70, 62, -1, 203, 15, 71, 62, -1, 204, 15, 72, 62, -1, 205, 15, 73, 62, -1, 206, 15, 74, 62, -1, 207, 15, 75, 62, -1, 208, 15, 76, 62, -1, 209, 15, 77, 62, -1, 210, 15, 78, 62, -1, 211, 15, 89, 62, -1, 212, 6, -1, 29, 6, -1, 22, 22, 2, 6, -1, 28, 29, 62, -1, 213, 6, -1, 30, 6, -1, 22, 22, 2, 6, -1, 28, 29, 62, -1, 214, 6, -1, 32, 6, -1, 21, 22, 2, 6, -1, 28, 29, 62, -1, 215, 6, -1, 31, 6, -1, 23, 22, 2, 6, -1, 28, 29, 62, -1, 216, 6, -1, 33, 6, -1, 26, 22, 2, 6, -1, 28, 29, 62, -1, 217, 6, -1, 34, 6, -1, 25, 22, 2, 6, -1, 28, 29, 62, -1, 218, 6, -1, 35, 6, -1, 24, 22, 2, 6, -1, 28, 29, 62, -1, 219, 6, -1, 36, 6, -1, 27, 22, 2, 6, -1, 28, 29, 62, -1, 220, 15, 1, 15, 0, 49, 62, -1, 221, 15, 1, 15, 1, 49, 62, -1, 222, 15, 1, 15, 2, 49, 62, -1, 223, 15, 1, 15, 3, 49, 62, -1, 224, 15, 1, 15, 4, 49, 62, -1, 225, 15, 1, 15, 5, 49, 62, -1, 226, 15, 1, 15, 6, 49, 62, -1, 227, 15, 1, 15, 7, 49, 62, -1, 228, 15, 1, 15, 8, 49, 62, -1, 229, 15, 0, 62, -1, 230, 15, 1, 62, -1, 231, 15, 300, 62, -1, 232, 15, 100, 62, -1, 233, 15, 128, 62, -1, 234, 15, 0, 62, -1, 235, 15, 1, 15, 0, 49, 62, -1, 236, 15, 1, 15, 1, 49, 62, -1, 237, 15, 1, 15, 2, 49, 62, -1, 238, 15, 1, 15, 3, 49, 62, -1, 239, 15, 1, 15, 4, 49, 62, -1, 240, 6, -1, 236, 6, -1, 237, 44, 6, -1, 238, 44, 6, -1, 239, 44, 6, -1, 240, 44, 62, -1, 241, 64, 356, 24, -16, 40, 64, 5328, 84, -20, 54, 33, 64, 10184, 12, 1, 18, 9, 23394, 64, 356, 24, -16, 40, 64, 5328, 84, -20, 54, 65, 0, 9, 23430, 15, 23401, 45, 65, 0, 9, 23430, 22, 0, 27, 169, 62, -1, 0, 39, 1, 1, 2, 15, 50, 6, -1, 2, 22, 2, 64, 2064, 24, 21, 40, 29, 65, 0, 9, 23429, 19, 62, -1, 242, 64, 356, 24, -16, 40, 64, 4820, 28, 2, 54, 33, 64, 10184, 12, 1, 18, 9, 23465, 64, 356, 24, -16, 40, 64, 4820, 28, 2, 54, 65, 0, 9, 23505, 15, 23472, 45, 65, 0, 9, 23505, 22, 0, 27, 170, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 64, 2608, 36, -12, 40, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 23504, 19, 62, -1, 243, 15, 212, 15, 81, 15, 127, 15, 16, 15, 59, 15, 17, 15, 231, 15, 255, 15, 172, 15, 102, 15, 136, 15, 155, 15, 103, 15, 126, 15, 36, 15, 6, 15, 52, 15, 69, 15, 137, 15, 139, 15, 158, 15, 214, 15, 78, 15, 237, 15, 128, 15, 162, 15, 26, 15, 135, 15, 42, 15, 253, 15, 125, 15, 205, 22, 32, 62, -1, 244, 15, 23584, 45, 65, 0, 9, 23672, 22, 0, 27, 171, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 15, 23605, 45, 65, 0, 9, 23644, 22, 0, 27, 172, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 6, 171, 2, 64, 6636, 8, 18, 56, 55, 22, 0, 6, 171, 2, 64, 2104, 12, -16, 54, 29, 65, 0, 9, 23643, 19, 22, 1, 31, 64, 1732, 28, -7, 54, 22, 1, 31, 64, 4996, 20, 12, 54, 29, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 23671, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 8372, 16, -12, 56, 55, 15, 23693, 45, 65, 0, 9, 23763, 22, 0, 27, 173, 62, -1, 0, 39, 0, 1, 64, 4096, 16, 5, 64, 4200, 24, -11, 22, 2, 65, 0, 64, 1904, 12, 18, 64, 1924, 16, -17, 7, 1, 6, 0, 244, 22, 1, 64, 11224, 16, 15, 40, 53, 64, 476, 4, 14, 22, 5, 64, 104, 20, -10, 40, 64, 832, 8, 0, 54, 64, 4400, 56, -18, 54, 29, 65, 0, 9, 23762, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 4996, 20, 12, 56, 55, 15, 23784, 45, 65, 0, 9, 24220, 22, 0, 27, 174, 62, -1, 0, 39, 1, 1, 2, 31, 62, -1, 3, 31, 64, 7936, 28, 1, 54, 9, 23812, 35, 65, 0, 9, 24219, 65, 1, 31, 64, 7936, 28, 1, 56, 55, 31, 64, 3252, 16, -4, 54, 34, 10, 9, 23852, 31, 64, 3252, 16, -4, 54, 22, 1, 6, 0, 243, 29, 55, 34, 31, 64, 3252, 16, -4, 56, 55, 15, 23859, 45, 65, 0, 9, 24189, 22, 0, 27, 175, 62, -1, 0, 39, 0, 1, 22, 0, 6, 174, 3, 64, 5276, 8, 13, 54, 64, 5016, 12, 15, 54, 29, 62, -1, 2, 15, 23895, 45, 65, 0, 9, 23929, 22, 0, 27, 176, 62, -1, 0, 39, 0, 1, 65, 0, 6, 174, 3, 64, 7936, 28, 1, 56, 55, 6, 174, 3, 64, 5276, 8, 13, 54, 65, 0, 9, 23928, 19, 22, 1, 15, 23938, 45, 65, 0, 9, 24156, 22, 0, 27, 177, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 64, 3816, 28, -20, 40, 64, 2596, 12, 17, 54, 29, 2, 9, 23974, 22, 0, 43, -1, 2, 55, 6, 175, 2, 6, -1, 2, 22, 2, 6, 174, 3, 64, 5684, 20, 21, 54, 29, 62, -1, 3, 6, -1, 3, 6, 174, 3, 64, 5276, 8, 13, 56, 55, 6, 175, 2, 64, 3156, 16, 16, 54, 15, 0, 41, 9, 24132, 15, 24026, 45, 65, 0, 9, 24060, 22, 0, 27, 178, 62, -1, 0, 39, 0, 1, 65, 0, 6, 174, 3, 64, 7936, 28, 1, 56, 55, 6, 174, 3, 64, 5276, 8, 13, 54, 65, 0, 9, 24059, 19, 22, 1, 15, 24069, 45, 65, 0, 9, 24103, 22, 0, 27, 179, 62, -1, 0, 39, 0, 1, 65, 0, 6, 174, 3, 64, 7936, 28, 1, 56, 55, 6, 174, 3, 64, 5276, 8, 13, 54, 65, 0, 9, 24102, 19, 22, 1, 22, 0, 6, 174, 3, 64, 10196, 56, -18, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 24155, 65, 0, 6, 174, 3, 64, 7936, 28, 1, 56, 55, 6, 174, 3, 64, 5276, 8, 13, 54, 65, 0, 9, 24155, 19, 22, 1, 6, 174, 2, 22, 1, 6, 174, 3, 64, 3076, 12, 0, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 24188, 19, 22, 1, 31, 64, 7568, 16, 8, 54, 64, 1792, 8, 2, 54, 29, 31, 64, 7568, 16, 8, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 24219, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 4592, 36, 6, 56, 55, 15, 24241, 45, 65, 0, 9, 24487, 22, 0, 27, 180, 62, -1, 0, 39, 2, 1, 2, 3, 22, 0, 62, -1, 4, 7, 0, 62, -1, 5, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 6, 15, 0, 62, -1, 7, 6, -1, 7, 6, -1, 6, 12, 9, 24371, 6, -1, 3, 6, -1, 7, 54, 62, -1, 8, 6, -1, 8, 16, 9, 24313, 55, 6, -1, 8, 64, 9864, 8, -19, 54, 16, 9, 24330, 55, 6, -1, 5, 6, -1, 8, 64, 9864, 8, -19, 54, 54, 2, 9, 24362, 6, -1, 8, 22, 1, 6, -1, 4, 64, 4628, 8, 2, 54, 29, 55, 65, 1, 6, -1, 5, 6, -1, 8, 64, 9864, 8, -19, 54, 56, 55, 47, -1, 7, 0, 55, 65, 0, 9, 24279, 6, -1, 2, 64, 3156, 16, 16, 54, 62, -1, 9, 15, 0, 62, -1, 10, 6, -1, 10, 6, -1, 9, 12, 9, 24479, 6, -1, 2, 6, -1, 10, 54, 62, -1, 11, 6, -1, 11, 16, 9, 24421, 55, 6, -1, 11, 64, 9864, 8, -19, 54, 16, 9, 24438, 55, 6, -1, 5, 6, -1, 11, 64, 9864, 8, -19, 54, 54, 2, 9, 24470, 6, -1, 11, 22, 1, 6, -1, 4, 64, 4628, 8, 2, 54, 29, 55, 65, 1, 6, -1, 5, 6, -1, 11, 64, 9864, 8, -19, 54, 56, 55, 47, -1, 10, 0, 55, 65, 0, 9, 24387, 6, -1, 4, 65, 0, 9, 24486, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 5684, 20, 21, 56, 55, 15, 24508, 45, 65, 0, 9, 24802, 22, 0, 27, 181, 62, -1, 0, 39, 1, 1, 2, 0, 24769, 31, 62, -1, 3, 22, 0, 64, 8204, 24, -7, 40, 53, 62, -1, 4, 15, 12, 22, 1, 64, 11224, 16, 15, 40, 53, 22, 1, 64, 104, 20, -10, 40, 64, 8180, 24, -5, 54, 29, 62, -1, 5, 6, -1, 2, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 22, 1, 6, -1, 4, 64, 5848, 8, -10, 54, 29, 62, -1, 6, 15, 24599, 45, 65, 0, 9, 24705, 22, 0, 27, 182, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 64, 11224, 16, 15, 40, 53, 62, -1, 3, 6, 181, 5, 34, 22, 2, 64, 8044, 32, -18, 40, 64, 7872, 44, -17, 54, 64, 7644, 36, -22, 54, 29, 22, 1, 64, 356, 24, -16, 40, 64, 4784, 8, -11, 54, 29, 64, 4224, 4, -4, 13, 6, -1, 3, 34, 22, 2, 64, 8044, 32, -18, 40, 64, 7872, 44, -17, 54, 64, 7644, 36, -22, 54, 29, 22, 1, 64, 356, 24, -16, 40, 64, 4784, 8, -11, 54, 29, 13, 65, 0, 9, 24704, 19, 22, 1, 6, -1, 6, 6, -1, 3, 64, 6636, 8, 18, 54, 64, 11488, 4, 3, 6, -1, 5, 64, 1904, 12, 18, 64, 1924, 16, -17, 7, 2, 22, 3, 64, 104, 20, -10, 40, 64, 832, 8, 0, 54, 64, 4200, 24, -11, 54, 29, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 24801, 5, 24765, 65, 0, 9, 24792, 62, -1, 7, 6, -1, 7, 22, 1, 64, 5084, 12, 4, 40, 64, 3268, 16, 5, 54, 29, 65, 0, 9, 24801, 64, 1172, 24, 7, 40, 65, 0, 9, 24801, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 888, 16, -4, 56, 55, 15, 24823, 45, 65, 0, 9, 25252, 22, 0, 27, 183, 62, -1, 0, 39, 1, 1, 2, 31, 62, -1, 3, 6, -1, 2, 2, 9, 24863, 22, 0, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 25251, 0, 25220, 64, 4224, 4, -4, 22, 1, 6, -1, 2, 64, 8912, 8, 2, 54, 29, 62, -1, 4, 15, 24890, 45, 65, 0, 9, 24919, 22, 0, 27, 184, 62, -1, 0, 39, 1, 1, 2, 15, 0, 22, 1, 6, -1, 2, 64, 3564, 24, 3, 54, 29, 65, 0, 9, 24918, 19, 22, 1, 64, 6088, 0, 2, 22, 1, 6, -1, 4, 15, 0, 54, 22, 1, 64, 356, 24, -16, 40, 64, 5676, 8, 19, 54, 29, 64, 8912, 8, 2, 54, 29, 64, 2892, 4, 8, 54, 29, 22, 1, 64, 11224, 16, 15, 40, 53, 62, -1, 5, 15, 24976, 45, 65, 0, 9, 25005, 22, 0, 27, 185, 62, -1, 0, 39, 1, 1, 2, 15, 0, 22, 1, 6, -1, 2, 64, 3564, 24, 3, 54, 29, 65, 0, 9, 25004, 19, 22, 1, 64, 6088, 0, 2, 22, 1, 6, -1, 4, 15, 1, 54, 22, 1, 64, 356, 24, -16, 40, 64, 5676, 8, 19, 54, 29, 64, 8912, 8, 2, 54, 29, 64, 2892, 4, 8, 54, 29, 22, 1, 64, 11224, 16, 15, 40, 53, 62, -1, 6, 15, 25062, 45, 65, 0, 9, 25079, 22, 0, 27, 186, 62, -1, 0, 39, 0, 1, 22, 0, 65, 0, 9, 25078, 19, 22, 1, 15, 25088, 45, 65, 0, 9, 25150, 22, 0, 27, 187, 62, -1, 0, 39, 1, 1, 2, 22, 0, 64, 8660, 16, -1, 40, 53, 62, -1, 3, 6, -1, 2, 22, 1, 64, 11224, 16, 15, 40, 53, 22, 1, 6, -1, 3, 64, 3844, 8, -15, 54, 29, 22, 1, 64, 28, 16, 19, 40, 64, 5320, 8, -5, 54, 29, 65, 0, 9, 25149, 19, 22, 1, 6, -1, 6, 6, -1, 3, 64, 6636, 8, 18, 54, 64, 11488, 4, 3, 6, -1, 5, 64, 1904, 12, 18, 64, 1924, 16, -17, 7, 2, 22, 3, 64, 104, 20, -10, 40, 64, 832, 8, 0, 54, 64, 4096, 16, 5, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 25251, 5, 25216, 65, 0, 9, 25242, 62, -1, 7, 22, 0, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 25251, 64, 1172, 24, 7, 40, 65, 0, 9, 25251, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 3076, 12, 0, 56, 55, 15, 25273, 45, 65, 0, 9, 25389, 22, 0, 27, 188, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 31, 64, 5776, 20, -4, 54, 22, 1, 64, 356, 24, -16, 40, 64, 8560, 24, 18, 54, 64, 816, 16, 15, 54, 29, 62, -1, 3, 15, 25321, 45, 65, 0, 9, 25364, 22, 0, 27, 189, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 16, 2, 9, 25342, 55, 22, 0, 6, 188, 2, 64, 5276, 8, 13, 56, 55, 6, 188, 2, 64, 5276, 8, 13, 54, 65, 0, 9, 25363, 19, 22, 1, 6, -1, 3, 22, 1, 31, 64, 3076, 12, 0, 54, 29, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 25388, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 2104, 12, -16, 56, 55, 15, 25410, 45, 65, 0, 9, 25998, 22, 0, 27, 190, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 31, 64, 4252, 28, 5, 54, 2, 9, 25442, 22, 0, 31, 64, 4252, 28, 5, 56, 55, 15, 25449, 45, 65, 0, 9, 25985, 22, 0, 27, 191, 62, -1, 0, 39, 2, 1, 2, 3, 64, 3268, 16, 5, 6, -1, 3, 64, 4792, 16, 8, 6, -1, 2, 7, 2, 22, 1, 6, 190, 2, 64, 4252, 28, 5, 54, 64, 4628, 8, 2, 54, 29, 55, 6, 190, 2, 64, 3252, 16, -4, 54, 34, 10, 9, 25531, 6, 190, 2, 64, 3252, 16, -4, 54, 22, 1, 6, 0, 243, 29, 55, 34, 6, 190, 2, 64, 3252, 16, -4, 56, 55, 15, 25538, 45, 65, 0, 9, 25960, 22, 0, 27, 192, 62, -1, 0, 39, 0, 1, 0, 25885, 34, 6, 190, 2, 64, 3252, 16, -4, 56, 55, 6, 190, 2, 64, 5276, 8, 13, 54, 64, 3156, 16, 16, 54, 6, 0, 232, 41, 9, 25608, 6, 0, 232, 14, 22, 1, 6, 190, 2, 64, 5276, 8, 13, 54, 64, 5016, 12, 15, 54, 29, 6, 190, 2, 64, 5276, 8, 13, 56, 55, 15, 25615, 45, 65, 0, 9, 25712, 22, 0, 27, 193, 62, -1, 0, 39, 1, 1, 2, 6, 190, 2, 64, 4252, 28, 5, 54, 16, 2, 9, 25641, 55, 22, 0, 62, -1, 3, 22, 0, 6, 190, 2, 64, 4252, 28, 5, 56, 55, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 3, 64, 3156, 16, 16, 54, 12, 9, 25702, 6, -1, 2, 22, 1, 6, -1, 3, 6, -1, 4, 54, 64, 3268, 16, 5, 54, 29, 55, 47, -1, 4, 0, 55, 65, 0, 9, 25660, 64, 1172, 24, 7, 40, 65, 0, 9, 25711, 19, 22, 1, 15, 25721, 45, 65, 0, 9, 25845, 22, 0, 27, 194, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 6, 190, 2, 64, 5776, 20, -4, 54, 22, 2, 64, 356, 24, -16, 40, 64, 8560, 24, 18, 54, 64, 9904, 32, -16, 54, 29, 55, 6, 190, 2, 64, 4252, 28, 5, 54, 16, 2, 9, 25777, 55, 22, 0, 62, -1, 3, 22, 0, 6, 190, 2, 64, 4252, 28, 5, 56, 55, 15, 0, 62, -1, 4, 6, -1, 4, 6, -1, 3, 64, 3156, 16, 16, 54, 12, 9, 25835, 22, 0, 6, -1, 3, 6, -1, 4, 54, 64, 4792, 16, 8, 54, 29, 55, 47, -1, 4, 0, 55, 65, 0, 9, 25796, 64, 1172, 24, 7, 40, 65, 0, 9, 25844, 19, 22, 1, 6, 190, 2, 64, 5276, 8, 13, 54, 22, 1, 6, 190, 2, 64, 888, 16, -4, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 25881, 65, 0, 9, 25950, 62, -1, 2, 6, -1, 2, 64, 8584, 8, -4, 40, 59, 16, 9, 25921, 55, 64, 1380, 16, -13, 22, 1, 6, -1, 2, 64, 11068, 32, -20, 54, 64, 2748, 20, 8, 54, 29, 9, 25938, 6, -1, 2, 22, 1, 6, 191, 3, 29, 55, 35, 65, 0, 9, 25959, 6, -1, 2, 64, 10928, 8, 19, 22, 2, 30, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 25959, 19, 22, 1, 6, 0, 242, 29, 6, 190, 2, 64, 3252, 16, -4, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 25984, 19, 22, 1, 64, 5084, 12, 4, 40, 53, 65, 0, 9, 25997, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 10196, 56, -18, 56, 55, 15, 26019, 45, 65, 0, 9, 26112, 22, 0, 27, 195, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 15, 26040, 45, 65, 0, 9, 26093, 22, 0, 27, 196, 62, -1, 0, 39, 0, 1, 6, 195, 2, 64, 7936, 28, 1, 54, 9, 26077, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 26092, 22, 0, 6, 195, 2, 64, 10196, 56, -18, 54, 29, 65, 0, 9, 26092, 19, 22, 1, 31, 64, 7568, 16, 8, 54, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 26111, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 4908, 8, -2, 56, 55, 15, 26133, 45, 65, 0, 9, 26406, 22, 0, 27, 197, 62, -1, 0, 39, 1, 1, 2, 31, 64, 6396, 68, -16, 54, 9, 26169, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 26405, 6, -1, 2, 34, 52, 16, 2, 9, 26189, 55, 6, -1, 2, 64, 9864, 8, -19, 54, 34, 52, 9, 26208, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 26405, 31, 62, -1, 3, 15, 26219, 45, 65, 0, 9, 26387, 22, 0, 27, 198, 62, -1, 0, 39, 0, 1, 0, 26354, 65, 0, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 3, 6, 197, 3, 64, 5276, 8, 13, 54, 64, 3156, 16, 16, 54, 12, 9, 26307, 6, 197, 3, 64, 5276, 8, 13, 54, 6, -1, 3, 54, 64, 9864, 8, -19, 54, 6, 197, 2, 64, 9864, 8, -19, 54, 18, 9, 26298, 65, 1, 43, -1, 2, 55, 65, 0, 9, 26307, 47, -1, 3, 0, 55, 65, 0, 9, 26241, 6, -1, 2, 2, 9, 26348, 6, 197, 2, 22, 1, 6, 197, 3, 64, 5276, 8, 13, 54, 64, 4628, 8, 2, 54, 29, 55, 22, 0, 6, 197, 3, 64, 4908, 8, -2, 54, 29, 65, 0, 9, 26386, 5, 26350, 65, 0, 9, 26377, 62, -1, 4, 6, -1, 4, 22, 1, 64, 5084, 12, 4, 40, 64, 3268, 16, 5, 54, 29, 65, 0, 9, 26386, 64, 1172, 24, 7, 40, 65, 0, 9, 26386, 19, 22, 1, 31, 64, 7568, 16, 8, 54, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 26405, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 6332, 4, -22, 56, 55, 15, 26427, 45, 65, 0, 9, 26515, 22, 0, 27, 199, 62, -1, 0, 39, 0, 1, 31, 64, 6396, 68, -16, 54, 9, 26462, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 26514, 31, 62, -1, 2, 15, 26473, 45, 65, 0, 9, 26496, 22, 0, 27, 200, 62, -1, 0, 39, 0, 1, 6, 199, 2, 64, 5276, 8, 13, 54, 65, 0, 9, 26495, 19, 22, 1, 31, 64, 7568, 16, 8, 54, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 26514, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 5664, 12, -14, 56, 55, 15, 26536, 45, 65, 0, 9, 26640, 22, 0, 27, 201, 62, -1, 0, 39, 0, 1, 31, 64, 6396, 68, -16, 54, 9, 26571, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 26639, 31, 62, -1, 2, 15, 26582, 45, 65, 0, 9, 26608, 22, 0, 27, 202, 62, -1, 0, 39, 0, 1, 22, 0, 6, 201, 2, 64, 2104, 12, -16, 54, 29, 65, 0, 9, 26607, 19, 22, 1, 31, 64, 7568, 16, 8, 54, 64, 1792, 8, 2, 54, 29, 31, 64, 7568, 16, 8, 56, 55, 31, 64, 7568, 16, 8, 54, 65, 0, 9, 26639, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 1248, 8, -8, 56, 55, 15, 26661, 45, 65, 0, 9, 26763, 22, 0, 27, 203, 62, -1, 0, 39, 0, 1, 31, 64, 6396, 68, -16, 54, 9, 26696, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 26762, 31, 62, -1, 2, 15, 26707, 45, 65, 0, 9, 26744, 22, 0, 27, 204, 62, -1, 0, 39, 0, 1, 22, 0, 6, 203, 2, 64, 5276, 8, 13, 56, 55, 22, 0, 6, 203, 2, 64, 4908, 8, -2, 54, 29, 65, 0, 9, 26743, 19, 22, 1, 31, 64, 7568, 16, 8, 54, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 26762, 19, 6, -1, 40, 64, 8492, 44, -14, 54, 64, 3024, 8, 5, 56, 55, 15, 26784, 45, 65, 0, 9, 27018, 22, 0, 27, 205, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 34, 52, 16, 2, 9, 26815, 55, 6, -1, 2, 64, 9864, 8, -19, 54, 34, 52, 9, 26834, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 27017, 6, -1, 2, 22, 1, 6, 0, 42, 29, 9, 26862, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 27017, 65, 0, 62, -1, 3, 15, 0, 62, -1, 4, 6, -1, 4, 31, 64, 5276, 8, 13, 54, 64, 3156, 16, 16, 54, 12, 9, 26934, 31, 64, 5276, 8, 13, 54, 6, -1, 4, 54, 64, 9864, 8, -19, 54, 6, -1, 2, 64, 9864, 8, -19, 54, 18, 9, 26925, 65, 1, 43, -1, 3, 55, 65, 0, 9, 26934, 47, -1, 4, 0, 55, 65, 0, 9, 26872, 6, -1, 3, 2, 9, 27e3, 6, -1, 2, 22, 1, 31, 64, 5276, 8, 13, 54, 64, 4628, 8, 2, 54, 29, 55, 31, 64, 5276, 8, 13, 54, 64, 3156, 16, 16, 54, 6, 0, 232, 41, 9, 27e3, 6, 0, 232, 14, 22, 1, 31, 64, 5276, 8, 13, 54, 64, 5016, 12, 15, 54, 29, 31, 64, 5276, 8, 13, 56, 55, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 27017, 19, 6, -1, 41, 64, 8492, 44, -14, 54, 64, 6332, 4, -22, 56, 55, 15, 27039, 45, 65, 0, 9, 27073, 22, 0, 27, 206, 62, -1, 0, 39, 0, 1, 31, 64, 5276, 8, 13, 54, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 27072, 19, 6, -1, 41, 64, 8492, 44, -14, 54, 64, 5664, 12, -14, 56, 55, 15, 27094, 45, 65, 0, 9, 27128, 22, 0, 27, 207, 62, -1, 0, 39, 0, 1, 31, 64, 5276, 8, 13, 54, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 27127, 19, 6, -1, 41, 64, 8492, 44, -14, 54, 64, 1248, 8, -8, 56, 55, 15, 27149, 45, 65, 0, 9, 27186, 22, 0, 27, 208, 62, -1, 0, 39, 0, 1, 22, 0, 31, 64, 5276, 8, 13, 56, 55, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 27185, 19, 6, -1, 41, 64, 8492, 44, -14, 54, 64, 3024, 8, 5, 56, 55, 64, 2088, 4, -16, 64, 6292, 28, 5, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 245, 64, 2088, 4, -16, 64, 228, 28, -4, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 246, 64, 2088, 4, -16, 64, 11480, 8, 16, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 247, 64, 2088, 4, -16, 64, 1240, 8, 8, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 248, 64, 2088, 4, -16, 64, 1116, 40, -15, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 249, 64, 4900, 4, 13, 64, 148, 28, 4, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 250, 64, 4900, 4, 13, 64, 2116, 32, -12, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 251, 64, 4900, 4, 13, 64, 668, 64, -3, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 252, 64, 4900, 4, 13, 64, 564, 72, -15, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 253, 64, 6088, 0, 2, 64, 9092, 64, 14, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 254, 64, 6088, 0, 2, 64, 7964, 16, 15, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 255, 64, 6088, 0, 2, 64, 11040, 28, -8, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 256, 64, 6088, 0, 2, 64, 5816, 24, -20, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 257, 64, 6088, 0, 2, 64, 904, 44, -16, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 258, 64, 6088, 0, 2, 64, 10280, 12, -1, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 259, 64, 6088, 0, 2, 64, 7364, 8, -4, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 260, 64, 6088, 0, 2, 64, 8444, 16, 14, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 261, 64, 6088, 0, 2, 64, 8960, 48, -6, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 262, 64, 6088, 0, 2, 64, 3420, 16, -21, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 263, 64, 6088, 0, 2, 64, 8676, 12, -13, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 264, 64, 6088, 0, 2, 64, 2504, 44, -18, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 265, 64, 4900, 4, 13, 64, 7404, 164, 20, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 266, 64, 2088, 4, -16, 64, 516, 48, 10, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 267, 64, 6088, 0, 2, 64, 176, 16, 0, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 268, 64, 2088, 4, -16, 64, 9428, 120, -3, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 269, 64, 2088, 4, -16, 64, 1396, 172, 6, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 270, 64, 2088, 4, -16, 64, 9548, 128, -11, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 271, 64, 2088, 4, -16, 64, 10800, 76, 0, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 272, 64, 2088, 4, -16, 64, 1e3, 56, -10, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 273, 64, 2088, 4, -16, 64, 5096, 84, -21, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 274, 64, 2088, 4, -16, 64, 7092, 40, -14, 22, 2, 64, 6168, 12, -5, 40, 53, 62, -1, 275, 6, -1, 204, 6, -1, 209, 6, -1, 211, 6, -1, 210, 6, -1, 208, 6, -1, 207, 6, -1, 205, 6, -1, 206, 6, -1, 212, 6, -1, 203, 22, 10, 62, -1, 276, 15, 3, 62, -1, 277, 64, 1804, 4, 3, 62, -1, 278, 15, 4, 62, -1, 279, 15, 0, 62, -1, 280, 15, 1, 62, -1, 281, 15, 2, 62, -1, 282, 15, 0, 62, -1, 283, 15, 1, 62, -1, 284, 15, 2, 62, -1, 285, 15, 3, 62, -1, 286, 15, 4, 62, -1, 287, 15, 5, 62, -1, 288, 15, 6, 62, -1, 289, 15, 1, 62, -1, 290, 15, 2, 62, -1, 291, 15, 27908, 45, 65, 0, 9, 28010, 22, 0, 27, 209, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 6, 0, 75, 29, 31, 64, 3956, 24, -5, 56, 55, 31, 64, 3956, 24, -5, 54, 6, 0, 283, 54, 2, 9, 27976, 31, 64, 1256, 24, -4, 54, 64, 9792, 8, -12, 22, 2, 64, 3300, 20, 7, 40, 64, 6784, 72, -13, 54, 29, 55, 65, 0, 9, 28e3, 31, 64, 1256, 24, -4, 54, 64, 9792, 8, -12, 22, 2, 64, 3300, 20, 7, 40, 64, 9692, 44, -12, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 28009, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 3344, 44, 19, 56, 55, 15, 28031, 45, 65, 0, 9, 28100, 22, 0, 27, 210, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 6, 0, 301, 54, 9, 28061, 22, 0, 31, 64, 840, 40, 2, 54, 29, 55, 6, -1, 2, 6, 0, 302, 54, 9, 28090, 22, 0, 31, 64, 4460, 40, -1, 54, 29, 55, 22, 0, 31, 64, 4672, 36, 6, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 28099, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 204, 16, 21, 56, 55, 15, 28121, 45, 65, 0, 9, 28327, 22, 0, 27, 211, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 15, 28142, 45, 65, 0, 9, 28299, 22, 0, 27, 212, 62, -1, 0, 39, 0, 1, 0, 28286, 64, 3300, 20, 7, 40, 64, 9736, 8, 21, 54, 9, 28225, 15, 28173, 45, 65, 0, 9, 28194, 22, 0, 27, 213, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28193, 19, 22, 1, 15, 0, 22, 1, 6, 0, 211, 22, 2, 6, 211, 2, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 65, 0, 9, 28280, 15, 28232, 45, 65, 0, 9, 28253, 22, 0, 27, 214, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28252, 19, 22, 1, 15, 1, 22, 1, 6, 0, 211, 22, 2, 6, 211, 2, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 28282, 65, 0, 9, 28289, 62, -1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28298, 19, 64, 5180, 40, 9, 22, 2, 64, 3300, 20, 7, 40, 64, 9692, 44, -12, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 28326, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 840, 40, 2, 56, 55, 15, 28348, 45, 65, 0, 9, 29038, 22, 0, 27, 215, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 15, 28369, 45, 65, 0, 9, 28460, 22, 0, 27, 216, 62, -1, 0, 39, 1, 1, 2, 0, 28447, 15, 28389, 45, 65, 0, 9, 28410, 22, 0, 27, 217, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28409, 19, 22, 1, 22, 0, 6, 0, 46, 29, 22, 1, 6, 0, 206, 22, 2, 6, 215, 2, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 28443, 65, 0, 9, 28450, 62, -1, 3, 64, 1172, 24, 7, 40, 65, 0, 9, 28459, 19, 64, 8896, 16, 10, 22, 2, 64, 356, 24, -16, 40, 64, 9692, 44, -12, 54, 29, 55, 15, 28485, 45, 65, 0, 9, 28576, 22, 0, 27, 218, 62, -1, 0, 39, 1, 1, 2, 0, 28563, 15, 28505, 45, 65, 0, 9, 28526, 22, 0, 27, 219, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28525, 19, 22, 1, 22, 0, 6, 0, 46, 29, 22, 1, 6, 0, 205, 22, 2, 6, 215, 2, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 28559, 65, 0, 9, 28566, 62, -1, 3, 64, 1172, 24, 7, 40, 65, 0, 9, 28575, 19, 64, 7748, 16, 15, 22, 2, 64, 356, 24, -16, 40, 64, 9692, 44, -12, 54, 29, 55, 64, 11196, 12, -2, 40, 64, 6128, 40, -14, 54, 62, -1, 3, 64, 11196, 12, -2, 40, 64, 5296, 24, 19, 54, 62, -1, 4, 15, 28627, 45, 65, 0, 9, 28813, 22, 0, 27, 220, 62, -1, 0, 39, 3, 1, 2, 3, 4, 0, 28674, 6, -1, 4, 6, -1, 3, 6, -1, 2, 64, 11196, 12, -2, 40, 22, 4, 6, 215, 3, 64, 5980, 8, 20, 54, 29, 55, 5, 28670, 65, 0, 9, 28684, 62, -1, 6, 6, -1, 6, 43, -1, 5, 55, 0, 28791, 15, 28693, 45, 65, 0, 9, 28714, 22, 0, 27, 221, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28713, 19, 22, 1, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 2732, 16, 21, 54, 64, 92, 4, -11, 22, 1, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 8476, 12, 11, 54, 64, 8912, 8, 2, 54, 29, 15, 0, 54, 13, 22, 1, 6, 0, 207, 22, 2, 6, 215, 2, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 28787, 65, 0, 9, 28794, 62, -1, 7, 6, -1, 5, 9, 28803, 6, -1, 5, 66, 64, 1172, 24, 7, 40, 65, 0, 9, 28812, 19, 64, 11196, 12, -2, 40, 64, 6128, 40, -14, 56, 55, 15, 28831, 45, 65, 0, 9, 29017, 22, 0, 27, 222, 62, -1, 0, 39, 3, 1, 2, 3, 4, 0, 28878, 6, -1, 4, 6, -1, 3, 6, -1, 2, 64, 11196, 12, -2, 40, 22, 4, 6, 215, 4, 64, 5980, 8, 20, 54, 29, 55, 5, 28874, 65, 0, 9, 28888, 62, -1, 6, 6, -1, 6, 43, -1, 5, 55, 0, 28995, 15, 28897, 45, 65, 0, 9, 28918, 22, 0, 27, 223, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 28917, 19, 22, 1, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 2732, 16, 21, 54, 64, 92, 4, -11, 22, 1, 64, 356, 24, -16, 40, 64, 4512, 16, 8, 54, 64, 8476, 12, 11, 54, 64, 8912, 8, 2, 54, 29, 15, 0, 54, 13, 22, 1, 6, 0, 208, 22, 2, 6, 215, 2, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 28991, 65, 0, 9, 28998, 62, -1, 7, 6, -1, 5, 9, 29007, 6, -1, 5, 66, 64, 1172, 24, 7, 40, 65, 0, 9, 29016, 19, 64, 11196, 12, -2, 40, 64, 5296, 24, 19, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 29037, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 4460, 40, -1, 56, 55, 15, 29059, 45, 65, 0, 9, 29577, 22, 0, 27, 224, 62, -1, 0, 39, 1, 1, 2, 31, 62, -1, 3, 0, 29564, 6, -1, 3, 64, 3956, 24, -5, 54, 62, -1, 4, 6, -1, 4, 6, 0, 283, 54, 2, 9, 29102, 35, 65, 0, 9, 29576, 6, -1, 4, 6, 0, 284, 54, 34, 42, 16, 9, 29129, 55, 6, -1, 4, 6, 0, 284, 54, 22, 1, 6, 0, 47, 29, 2, 9, 29136, 35, 65, 0, 9, 29576, 6, -1, 4, 6, 0, 285, 54, 34, 42, 16, 9, 29162, 55, 6, -1, 4, 6, 0, 285, 54, 22, 1, 6, 0, 47, 29, 9, 29169, 35, 65, 0, 9, 29576, 15, 2, 6, -1, 4, 6, 0, 287, 54, 6, -1, 2, 64, 7016, 12, 8, 54, 22, 3, 6, 0, 76, 29, 62, -1, 5, 6, -1, 5, 34, 52, 9, 29207, 35, 65, 0, 9, 29576, 6, -1, 5, 22, 1, 6, 0, 69, 29, 62, -1, 6, 15, 20, 15, 0, 22, 2, 64, 480, 12, -10, 22, 1, 6, -1, 5, 64, 10356, 56, -16, 54, 29, 16, 2, 9, 29249, 55, 64, 6088, 0, 2, 64, 5016, 12, 15, 54, 29, 62, -1, 7, 15, 20, 15, 0, 22, 2, 64, 10164, 20, 10, 22, 1, 6, -1, 5, 64, 10356, 56, -16, 54, 29, 16, 2, 9, 29288, 55, 64, 6088, 0, 2, 64, 5016, 12, 15, 54, 29, 62, -1, 8, 15, 20, 15, 0, 22, 2, 64, 1760, 32, -22, 22, 1, 6, -1, 5, 64, 10356, 56, -16, 54, 29, 16, 2, 9, 29327, 55, 64, 6088, 0, 2, 64, 5016, 12, 15, 54, 29, 62, -1, 9, 15, 20, 15, 0, 22, 2, 6, 0, 292, 22, 1, 6, -1, 5, 64, 10356, 56, -16, 54, 29, 16, 2, 9, 29365, 55, 64, 6088, 0, 2, 64, 5016, 12, 15, 54, 29, 62, -1, 10, 15, 50, 15, 0, 22, 2, 15, 29387, 45, 65, 0, 9, 29469, 22, 0, 27, 225, 62, -1, 0, 39, 2, 1, 2, 3, 6, 224, 3, 64, 3956, 24, -5, 54, 6, 0, 288, 54, 9, 29423, 65, 1, 65, 0, 9, 29468, 65, 0, 9, 29462, 6, 224, 3, 64, 3956, 24, -5, 54, 6, 0, 289, 54, 9, 29462, 6, -1, 3, 6, -1, 2, 22, 2, 6, 224, 3, 64, 3956, 24, -5, 54, 6, 0, 289, 54, 29, 65, 0, 9, 29468, 65, 0, 65, 0, 9, 29468, 19, 6, -1, 5, 22, 2, 6, 0, 72, 29, 64, 5016, 12, 15, 54, 29, 62, -1, 11, 15, 29494, 45, 65, 0, 9, 29515, 22, 0, 27, 226, 62, -1, 0, 39, 1, 1, 2, 64, 1172, 24, 7, 40, 65, 0, 9, 29514, 19, 22, 1, 6, -1, 11, 6, -1, 10, 6, -1, 8, 6, -1, 9, 6, -1, 7, 6, -1, 6, 22, 6, 6, 0, 212, 22, 2, 6, -1, 3, 64, 4316, 32, 22, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 29560, 65, 0, 9, 29567, 62, -1, 12, 64, 1172, 24, 7, 40, 65, 0, 9, 29576, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 6248, 20, 19, 56, 55, 64, 948, 20, 18, 62, -1, 292, 15, 29605, 45, 65, 0, 9, 29667, 22, 0, 27, 227, 62, -1, 0, 39, 0, 1, 31, 64, 3956, 24, -5, 54, 6, 0, 283, 54, 2, 9, 29633, 35, 65, 0, 9, 29666, 31, 64, 1256, 24, -4, 54, 64, 9792, 8, -12, 22, 2, 64, 3300, 20, 7, 40, 64, 9692, 44, -12, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 29666, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 4672, 36, 6, 56, 55, 15, 29688, 45, 65, 0, 9, 29874, 22, 0, 27, 228, 62, -1, 0, 39, 2, 1, 2, 3, 31, 64, 7156, 32, 5, 54, 34, 52, 9, 29731, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 29873, 65, 0, 9, 29763, 31, 64, 7156, 32, 5, 54, 64, 6332, 4, -22, 54, 34, 52, 9, 29763, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 29873, 6, -1, 3, 22, 1, 6, 0, 73, 29, 62, -1, 4, 6, -1, 4, 34, 18, 9, 29799, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 29873, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 31, 64, 1836, 44, -16, 54, 37, 62, -1, 5, 64, 9052, 12, 10, 6, -1, 5, 31, 64, 3624, 20, -19, 54, 6, -1, 4, 6, -1, 2, 22, 4, 64, 9864, 8, -19, 22, 0, 6, 0, 45, 29, 7, 2, 22, 1, 31, 64, 7156, 32, 5, 54, 64, 6332, 4, -22, 54, 29, 65, 0, 9, 29873, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 4316, 32, 22, 56, 55, 15, 29895, 45, 65, 0, 9, 30457, 22, 0, 27, 229, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 31, 64, 7156, 32, 5, 54, 34, 18, 9, 29946, 22, 0, 22, 0, 22, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30456, 65, 0, 9, 29984, 31, 64, 7156, 32, 5, 54, 64, 5664, 12, -14, 54, 34, 18, 9, 29984, 22, 0, 22, 0, 22, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30456, 0, 30421, 15, 29993, 45, 65, 0, 9, 30389, 22, 0, 27, 230, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 34, 52, 9, 30034, 22, 0, 22, 0, 22, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30388, 15, 30041, 45, 65, 0, 9, 30065, 22, 0, 27, 231, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 64, 9052, 12, 10, 54, 65, 0, 9, 30064, 19, 22, 1, 6, -1, 2, 64, 2892, 4, 8, 54, 29, 62, -1, 3, 6, 0, 233, 6, -1, 3, 22, 2, 6, 0, 43, 29, 62, -1, 4, 22, 0, 62, -1, 5, 7, 0, 62, -1, 6, 6, -1, 4, 64, 3156, 16, 16, 54, 62, -1, 7, 15, 0, 62, -1, 8, 6, -1, 8, 6, -1, 7, 12, 9, 30364, 6, -1, 4, 6, -1, 8, 54, 62, -1, 9, 6, -1, 9, 15, 1, 54, 22, 1, 64, 3816, 28, -20, 40, 64, 2596, 12, 17, 54, 29, 2, 9, 30165, 65, 0, 9, 30355, 6, -1, 9, 15, 1, 54, 62, -1, 10, 6, -1, 10, 64, 3156, 16, 16, 54, 62, -1, 11, 15, 0, 62, -1, 12, 6, -1, 12, 6, -1, 11, 12, 9, 30355, 6, -1, 10, 6, -1, 12, 54, 62, -1, 13, 6, -1, 13, 33, 64, 8592, 8, -6, 52, 16, 9, 30240, 55, 6, -1, 13, 22, 1, 6, -1, 5, 64, 3588, 12, 4, 54, 29, 15, 1, 14, 18, 9, 30293, 6, -1, 13, 22, 1, 6, -1, 5, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 13, 22, 1, 32, 29, 62, -1, 14, 6, -1, 14, 6, -1, 6, 6, -1, 13, 56, 55, 6, -1, 14, 6, -1, 10, 6, -1, 12, 56, 55, 65, 0, 9, 30346, 6, -1, 6, 6, -1, 13, 54, 43, -1, 14, 55, 6, -1, 14, 15, 0, 51, 18, 9, 30335, 6, -1, 13, 22, 1, 32, 29, 43, -1, 14, 55, 6, -1, 14, 6, -1, 6, 6, -1, 13, 56, 55, 6, -1, 14, 6, -1, 10, 6, -1, 12, 56, 55, 47, -1, 12, 0, 55, 65, 0, 9, 30190, 47, -1, 8, 0, 55, 65, 0, 9, 30120, 22, 0, 6, 229, 2, 64, 11468, 12, 16, 54, 29, 55, 6, -1, 5, 6, -1, 4, 22, 2, 65, 0, 9, 30388, 19, 22, 1, 22, 0, 31, 64, 7156, 32, 5, 54, 64, 5664, 12, -14, 54, 29, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 30456, 5, 30417, 65, 0, 9, 30447, 62, -1, 3, 22, 0, 22, 0, 22, 2, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30456, 64, 1172, 24, 7, 40, 65, 0, 9, 30456, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 1620, 16, 8, 56, 55, 15, 30478, 45, 65, 0, 9, 30603, 22, 0, 27, 232, 62, -1, 0, 39, 0, 1, 31, 64, 7156, 32, 5, 54, 34, 18, 9, 30515, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30602, 31, 64, 7156, 32, 5, 54, 64, 3024, 8, 5, 54, 34, 18, 9, 30547, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30602, 0, 30573, 22, 0, 31, 64, 7156, 32, 5, 54, 64, 3024, 8, 5, 54, 29, 65, 0, 9, 30602, 5, 30569, 65, 0, 9, 30593, 62, -1, 2, 22, 0, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 30602, 64, 1172, 24, 7, 40, 65, 0, 9, 30602, 19, 6, -1, 74, 64, 8492, 44, -14, 54, 64, 11468, 12, 16, 56, 55, 15, 16, 62, -1, 293, 15, 150, 15, 1e3, 23, 62, -1, 294, 15, 1, 62, -1, 295, 15, 2, 62, -1, 296, 15, 3, 62, -1, 297, 15, 4, 62, -1, 298, 15, 5, 62, -1, 299, 15, 6, 62, -1, 300, 15, 7, 62, -1, 301, 15, 8, 62, -1, 302, 15, 64, 62, -1, 303, 15, 16, 62, -1, 304, 15, 30687, 45, 65, 0, 9, 31100, 22, 0, 27, 233, 62, -1, 0, 39, 0, 1, 31, 62, -1, 2, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 2, 16, 2, 9, 30733, 55, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 64, 192, 12, 1, 54, 2, 9, 30740, 35, 65, 0, 9, 31099, 15, 30747, 45, 65, 0, 9, 30935, 22, 0, 27, 234, 62, -1, 0, 39, 1, 1, 2, 15, 30765, 45, 65, 0, 9, 30913, 22, 0, 27, 235, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 64, 480, 12, -10, 54, 64, 6604, 20, 15, 18, 9, 30903, 6, -1, 2, 64, 7764, 20, -12, 54, 62, -1, 3, 6, -1, 3, 64, 3156, 16, 16, 54, 6, 0, 304, 41, 9, 30823, 6, 0, 304, 65, 0, 9, 30831, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 30903, 6, -1, 3, 6, -1, 5, 54, 62, -1, 6, 6, -1, 6, 64, 192, 12, 1, 54, 64, 3852, 8, -15, 40, 64, 9876, 28, -16, 54, 18, 9, 30894, 6, -1, 6, 22, 1, 6, 233, 2, 64, 8616, 44, 8, 54, 29, 55, 47, -1, 5, 0, 55, 65, 0, 9, 30839, 64, 1172, 24, 7, 40, 65, 0, 9, 30912, 19, 22, 1, 6, -1, 2, 64, 3860, 28, -20, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 30934, 19, 62, -1, 3, 64, 11492, 12, -4, 40, 33, 64, 5540, 8, -1, 18, 16, 9, 30969, 55, 64, 11492, 12, -4, 40, 64, 3436, 12, 10, 54, 33, 64, 10184, 12, 1, 18, 9, 31005, 6, -1, 3, 22, 1, 64, 6496, 24, -3, 40, 22, 2, 64, 11492, 12, -4, 40, 64, 3436, 12, 10, 54, 29, 31, 64, 5608, 48, -21, 56, 55, 65, 0, 9, 31023, 6, -1, 3, 22, 1, 64, 6496, 24, -3, 40, 53, 31, 64, 5608, 48, -21, 56, 55, 0, 31070, 64, 4180, 12, 14, 65, 1, 64, 6604, 20, 15, 65, 1, 7, 2, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 22, 2, 31, 64, 5608, 48, -21, 54, 64, 5412, 20, 5, 54, 29, 55, 5, 31066, 65, 0, 9, 31090, 62, -1, 4, 6, -1, 4, 64, 7208, 156, -18, 22, 2, 26, 64, 6980, 20, 17, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 31099, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 6856, 32, 6, 56, 55, 15, 31121, 45, 65, 0, 9, 31273, 22, 0, 27, 236, 62, -1, 0, 39, 0, 1, 7, 0, 62, -1, 2, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 22, 1, 64, 2168, 20, -19, 40, 64, 6520, 12, -11, 54, 29, 62, -1, 3, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 31265, 6, -1, 3, 6, -1, 5, 54, 62, -1, 6, 6, -1, 6, 31, 64, 3032, 8, 16, 54, 64, 3136, 20, -8, 54, 1, 9, 31256, 31, 64, 3032, 8, 16, 54, 64, 3136, 20, -8, 54, 6, -1, 6, 54, 62, -1, 7, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 6, -1, 6, 54, 6, -1, 2, 6, -1, 7, 56, 55, 47, -1, 5, 0, 55, 65, 0, 9, 31179, 6, -1, 2, 65, 0, 9, 31272, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 2292, 40, 14, 56, 55, 15, 31294, 45, 65, 0, 9, 31524, 22, 0, 27, 237, 62, -1, 0, 39, 1, 1, 2, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 2, 9, 31333, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 56, 55, 31, 64, 3032, 8, 16, 54, 64, 3136, 20, -8, 54, 2, 9, 31375, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 3136, 20, -8, 56, 55, 15, 0, 31, 64, 3032, 8, 16, 54, 64, 4348, 52, -21, 56, 55, 31, 64, 3032, 8, 16, 54, 64, 4348, 52, -21, 54, 6, 0, 303, 28, 9, 31397, 35, 65, 0, 9, 31523, 6, -1, 2, 64, 3980, 48, -12, 54, 33, 64, 10184, 12, 1, 18, 9, 31436, 64, 8852, 44, 13, 22, 1, 6, -1, 2, 64, 3980, 48, -12, 54, 29, 43, -1, 3, 55, 65, 0, 9, 31442, 22, 0, 43, -1, 3, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 31514, 31, 64, 3032, 8, 16, 54, 64, 4348, 52, -21, 54, 6, 0, 303, 28, 9, 31488, 65, 0, 9, 31514, 6, -1, 3, 6, -1, 5, 54, 22, 1, 31, 64, 4964, 24, 12, 54, 29, 55, 47, -1, 5, 0, 55, 65, 0, 9, 31458, 64, 1172, 24, 7, 40, 65, 0, 9, 31523, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 8616, 44, 8, 56, 55, 15, 31545, 45, 65, 0, 9, 31690, 22, 0, 27, 238, 62, -1, 0, 39, 1, 1, 2, 31, 64, 3032, 8, 16, 54, 64, 4348, 52, -21, 54, 6, 0, 303, 28, 9, 31578, 35, 65, 0, 9, 31689, 6, -1, 2, 22, 1, 6, 0, 14, 29, 62, -1, 3, 6, -1, 3, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 1, 2, 9, 31680, 6, -1, 2, 22, 1, 6, 0, 17, 29, 62, -1, 4, 6, -1, 4, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 6, -1, 3, 56, 55, 31, 64, 3032, 8, 16, 54, 64, 4348, 52, -21, 54, 31, 64, 3032, 8, 16, 54, 64, 3136, 20, -8, 54, 6, -1, 3, 56, 55, 15, 1, 31, 64, 3032, 8, 16, 54, 64, 4348, 52, -21, 48, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 31689, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 4964, 24, 12, 56, 55, 15, 31711, 45, 65, 0, 9, 32590, 22, 0, 27, 239, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 2, 16, 2, 9, 31733, 55, 7, 0, 43, -1, 2, 55, 6, -1, 3, 34, 52, 9, 31770, 64, 2568, 16, -5, 64, 1920, 4, -21, 64, 9204, 12, 4, 22, 2, 64, 11428, 12, -8, 65, 1, 7, 2, 43, -1, 3, 55, 6, -1, 2, 6, 0, 302, 54, 65, 1, 18, 16, 9, 31794, 55, 31, 64, 9024, 16, 15, 54, 15, 0, 51, 18, 9, 31812, 6, -1, 3, 22, 1, 6, 0, 74, 53, 31, 64, 9024, 16, 15, 56, 55, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 56, 55, 6, -1, 2, 6, 0, 295, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 295, 56, 55, 6, -1, 2, 6, 0, 296, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 296, 56, 55, 6, -1, 2, 6, 0, 297, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 297, 56, 55, 6, -1, 2, 6, 0, 298, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 298, 56, 55, 6, -1, 2, 6, 0, 299, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 299, 56, 55, 6, -1, 2, 6, 0, 300, 54, 65, 0, 10, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 300, 56, 55, 6, -1, 2, 6, 0, 301, 54, 22, 1, 64, 7384, 20, 18, 40, 29, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 301, 56, 55, 6, -1, 2, 6, 0, 302, 54, 22, 1, 64, 7384, 20, 18, 40, 29, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, 0, 302, 56, 55, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 56, 55, 22, 0, 31, 64, 6856, 32, 6, 54, 29, 55, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 22, 1, 31, 64, 8616, 44, 8, 54, 29, 55, 31, 64, 3032, 8, 16, 54, 64, 6472, 24, 9, 54, 65, 0, 18, 9, 32529, 64, 3300, 20, 7, 40, 64, 10956, 8, 22, 54, 22, 1, 63, 53, 62, -1, 4, 6, 0, 218, 64, 6204, 8, 12, 6, 0, 300, 22, 3, 6, 0, 218, 64, 4192, 8, 17, 6, 0, 300, 22, 3, 6, 0, 219, 64, 976, 12, 16, 6, 0, 299, 22, 3, 6, 0, 217, 64, 5524, 16, 13, 6, 0, 298, 22, 3, 6, 0, 217, 64, 9156, 20, -7, 6, 0, 298, 22, 3, 6, 0, 217, 64, 96, 8, -4, 6, 0, 298, 22, 3, 6, 0, 217, 64, 9324, 8, 12, 6, 0, 298, 22, 3, 6, 0, 215, 64, 4740, 40, -18, 6, 0, 297, 22, 3, 6, 0, 215, 64, 5484, 40, -12, 6, 0, 297, 22, 3, 6, 0, 215, 64, 9764, 16, -1, 6, 0, 297, 22, 3, 6, 0, 216, 64, 6644, 40, -18, 6, 0, 296, 22, 3, 6, 0, 216, 64, 6720, 20, -14, 6, 0, 296, 22, 3, 6, 0, 214, 64, 5756, 20, -16, 6, 0, 295, 22, 3, 6, 0, 214, 64, 11356, 16, 16, 6, 0, 295, 22, 3, 6, 0, 213, 64, 1940, 48, -17, 6, 0, 295, 22, 3, 6, 0, 214, 64, 9744, 20, 21, 6, 0, 295, 22, 3, 6, 0, 220, 64, 2008, 20, 22, 6, 0, 295, 22, 3, 6, 0, 220, 64, 5728, 28, 17, 6, 0, 295, 22, 3, 6, 0, 220, 64, 5432, 24, 16, 6, 0, 295, 22, 3, 22, 19, 62, -1, 5, 6, -1, 5, 64, 3156, 16, 16, 54, 62, -1, 6, 15, 0, 62, -1, 7, 6, -1, 7, 6, -1, 6, 12, 9, 32515, 6, -1, 5, 6, -1, 7, 54, 62, -1, 8, 6, -1, 8, 15, 1, 54, 62, -1, 9, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 6, -1, 8, 15, 0, 54, 54, 65, 1, 18, 9, 32506, 31, 64, 4316, 32, 22, 54, 6, -1, 9, 22, 2, 6, -1, 8, 15, 2, 54, 29, 62, -1, 10, 65, 1, 6, -1, 10, 6, -1, 9, 22, 3, 6, -1, 4, 64, 9692, 44, -12, 54, 29, 55, 65, 1, 6, -1, 10, 6, -1, 9, 6, -1, 4, 22, 4, 22, 1, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 54, 64, 4628, 8, 2, 54, 29, 55, 47, -1, 7, 0, 55, 65, 0, 9, 32381, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 6472, 24, 9, 56, 55, 65, 1, 31, 64, 3032, 8, 16, 54, 64, 8940, 20, 12, 56, 55, 31, 64, 9024, 16, 15, 54, 9, 32580, 0, 32577, 6, -1, 2, 22, 1, 31, 64, 9024, 16, 15, 54, 64, 204, 16, 21, 54, 29, 55, 5, 32573, 65, 0, 9, 32580, 62, -1, 11, 64, 1172, 24, 7, 40, 65, 0, 9, 32589, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 204, 16, 21, 56, 55, 15, 32611, 45, 65, 0, 9, 32810, 22, 0, 27, 240, 62, -1, 0, 39, 0, 1, 31, 64, 5608, 48, -21, 54, 9, 32644, 22, 0, 31, 64, 5608, 48, -21, 54, 64, 1056, 16, -7, 54, 29, 55, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 54, 9, 32786, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 54, 62, -1, 2, 15, 0, 62, -1, 3, 6, -1, 3, 6, -1, 2, 64, 3156, 16, 16, 54, 12, 9, 32772, 6, -1, 2, 6, -1, 3, 54, 15, 0, 54, 62, -1, 4, 6, -1, 2, 6, -1, 3, 54, 15, 1, 54, 62, -1, 5, 6, -1, 2, 6, -1, 3, 54, 15, 2, 54, 62, -1, 6, 6, -1, 2, 6, -1, 3, 54, 15, 3, 54, 62, -1, 7, 6, -1, 7, 6, -1, 6, 6, -1, 5, 22, 3, 6, -1, 4, 64, 6784, 72, -13, 54, 29, 55, 47, -1, 3, 0, 55, 65, 0, 9, 32676, 22, 0, 31, 64, 3032, 8, 16, 54, 64, 11404, 24, 4, 56, 55, 65, 0, 31, 64, 3032, 8, 16, 54, 64, 8940, 20, 12, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 32809, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 292, 8, 12, 56, 55, 15, 32831, 45, 65, 0, 9, 33147, 22, 0, 27, 241, 62, -1, 0, 39, 0, 1, 7, 0, 62, -1, 2, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 22, 1, 64, 2168, 20, -19, 40, 64, 6520, 12, -11, 54, 29, 62, -1, 3, 6, -1, 3, 64, 3156, 16, 16, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, -1, 4, 12, 9, 32948, 6, -1, 3, 6, -1, 5, 54, 62, -1, 6, 22, 0, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 6, 54, 64, 1620, 16, 8, 54, 29, 6, -1, 2, 6, -1, 6, 56, 55, 47, -1, 5, 0, 55, 65, 0, 9, 32889, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 22, 0, 31, 64, 2292, 40, 14, 54, 29, 6, -1, 2, 22, 0, 31, 64, 8272, 44, 18, 54, 29, 22, 4, 62, -1, 7, 31, 64, 9024, 16, 15, 54, 9, 33126, 0, 33123, 15, 33002, 45, 65, 0, 9, 33021, 22, 0, 27, 242, 62, -1, 0, 39, 1, 1, 2, 6, 241, 7, 65, 0, 9, 33020, 19, 22, 1, 15, 33030, 45, 65, 0, 9, 33085, 22, 0, 27, 243, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 15, 0, 54, 22, 1, 6, 241, 7, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 2, 15, 1, 54, 22, 1, 6, 241, 7, 64, 4628, 8, 2, 54, 29, 55, 6, 241, 7, 65, 0, 9, 33084, 19, 22, 1, 22, 0, 31, 64, 9024, 16, 15, 54, 64, 1620, 16, 8, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 65, 0, 9, 33146, 5, 33119, 65, 0, 9, 33126, 62, -1, 8, 6, -1, 7, 22, 1, 64, 5084, 12, 4, 40, 64, 4792, 16, 8, 54, 29, 65, 0, 9, 33146, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 1620, 16, 8, 56, 55, 15, 33168, 45, 65, 0, 9, 33204, 22, 0, 27, 244, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 3, 31, 64, 11328, 12, -5, 54, 6, -1, 2, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 33203, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 380, 12, 14, 56, 55, 15, 33225, 45, 65, 0, 9, 33268, 22, 0, 27, 245, 62, -1, 0, 39, 0, 1, 7, 0, 31, 64, 11328, 12, -5, 56, 55, 7, 0, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 33267, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 11468, 12, 16, 56, 55, 15, 33289, 45, 65, 0, 9, 33736, 22, 0, 27, 246, 62, -1, 0, 39, 2, 1, 2, 3, 31, 64, 3032, 8, 16, 54, 64, 8940, 20, 12, 54, 65, 0, 18, 9, 33322, 35, 65, 0, 9, 33735, 0, 33706, 15, 10, 6, -1, 2, 22, 2, 64, 3916, 20, 18, 40, 29, 43, -1, 2, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 1, 37, 62, -1, 4, 6, -1, 3, 6, -1, 4, 54, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 37, 62, -1, 5, 6, -1, 3, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 2, 37, 54, 62, -1, 6, 6, -1, 2, 6, 0, 193, 28, 16, 9, 33413, 55, 6, -1, 2, 6, 0, 194, 12, 9, 33473, 6, -1, 3, 15, 2, 54, 62, -1, 7, 6, -1, 7, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 6, -1, 6, 56, 55, 6, -1, 3, 15, 4, 54, 6, -1, 3, 15, 3, 54, 6, -1, 3, 15, 1, 54, 6, -1, 3, 15, 0, 54, 22, 4, 43, -1, 3, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 1, 37, 43, -1, 4, 55, 6, -1, 3, 6, -1, 4, 54, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 37, 6, -1, 3, 6, -1, 4, 56, 55, 6, -1, 3, 64, 3156, 16, 16, 54, 15, 2, 37, 62, -1, 8, 31, 64, 3032, 8, 16, 54, 64, 3136, 20, -8, 54, 6, -1, 6, 54, 62, -1, 9, 6, -1, 9, 6, -1, 3, 6, -1, 8, 56, 55, 31, 64, 3032, 8, 16, 54, 64, 1604, 8, 18, 54, 6, -1, 6, 54, 62, -1, 10, 6, -1, 10, 2, 9, 33587, 35, 65, 0, 9, 33735, 6, -1, 10, 15, 0, 54, 62, -1, 11, 6, -1, 11, 6, 0, 178, 18, 9, 33610, 35, 65, 0, 9, 33735, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 2, 54, 2, 9, 33670, 31, 64, 3032, 8, 16, 54, 64, 2644, 16, -1, 54, 6, 0, 294, 6, 0, 293, 22, 3, 26, 64, 7844, 16, -2, 54, 53, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 2, 56, 55, 6, -1, 3, 6, -1, 5, 22, 2, 31, 64, 3032, 8, 16, 54, 64, 1808, 28, -11, 54, 6, -1, 2, 54, 64, 4628, 8, 2, 54, 29, 55, 5, 33702, 65, 0, 9, 33726, 62, -1, 12, 6, -1, 12, 64, 4864, 16, -9, 22, 2, 26, 64, 6980, 20, 17, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 33735, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 4316, 32, 22, 56, 55, 15, 33757, 45, 65, 0, 9, 33795, 22, 0, 27, 247, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 3, 6, -1, 2, 22, 2, 31, 64, 4316, 32, 22, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 33794, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 10712, 16, 17, 56, 55, 15, 33816, 45, 65, 0, 9, 33997, 22, 0, 27, 248, 62, -1, 0, 39, 0, 1, 15, 0, 62, -1, 2, 31, 64, 3032, 8, 16, 54, 64, 204, 16, 21, 54, 62, -1, 3, 6, -1, 3, 6, 0, 295, 54, 9, 33863, 15, 1, 15, 0, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 296, 54, 9, 33881, 15, 1, 15, 1, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 297, 54, 9, 33899, 15, 1, 15, 2, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 298, 54, 9, 33917, 15, 1, 15, 3, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 299, 54, 9, 33935, 15, 1, 15, 4, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 300, 54, 9, 33953, 15, 1, 15, 5, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 301, 54, 9, 33971, 15, 1, 15, 6, 49, 57, -1, 2, 55, 6, -1, 3, 6, 0, 302, 54, 9, 33989, 15, 1, 15, 7, 49, 57, -1, 2, 55, 6, -1, 2, 65, 0, 9, 33996, 19, 6, -1, 77, 64, 8492, 44, -14, 54, 64, 8272, 44, 18, 56, 55, 22, 0, 6, -1, 77, 53, 62, -1, 305, 15, 256, 62, -1, 306, 15, 34032, 45, 65, 0, 9, 34061, 22, 0, 27, 249, 62, -1, 0, 39, 0, 1, 22, 0, 31, 64, 11328, 12, -5, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 34060, 19, 6, -1, 78, 64, 8492, 44, -14, 54, 64, 6948, 28, -14, 56, 55, 15, 34082, 45, 65, 0, 9, 34260, 22, 0, 27, 250, 62, -1, 0, 39, 2, 1, 2, 3, 6, -1, 3, 33, 64, 5540, 8, -1, 10, 16, 2, 9, 34113, 55, 6, -1, 3, 34, 18, 9, 34120, 35, 65, 0, 9, 34259, 0, 34230, 6, -1, 2, 6, -1, 3, 64, 7820, 8, -3, 56, 55, 6, -1, 3, 64, 1892, 12, -3, 54, 2, 9, 34167, 22, 0, 64, 4288, 8, -1, 40, 64, 4988, 8, -6, 54, 29, 6, -1, 3, 64, 1892, 12, -3, 56, 55, 6, -1, 3, 22, 1, 31, 64, 11328, 12, -5, 54, 64, 4628, 8, 2, 54, 29, 55, 31, 64, 11328, 12, -5, 54, 64, 3156, 16, 16, 54, 6, 0, 306, 41, 9, 34217, 22, 0, 31, 64, 11328, 12, -5, 54, 64, 6348, 16, -12, 54, 29, 55, 6, -1, 3, 65, 0, 9, 34259, 5, 34226, 65, 0, 9, 34250, 62, -1, 4, 6, -1, 4, 64, 6592, 12, 0, 22, 2, 36, 64, 6980, 20, 17, 54, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 34259, 19, 6, -1, 78, 64, 8492, 44, -14, 54, 64, 968, 8, 12, 56, 55, 15, 34281, 45, 65, 0, 9, 34349, 22, 0, 27, 251, 62, -1, 0, 39, 0, 1, 15, 34298, 45, 65, 0, 9, 34330, 22, 0, 27, 252, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 65, 0, 9, 34329, 19, 22, 1, 31, 64, 11328, 12, -5, 54, 64, 2892, 4, 8, 54, 29, 65, 0, 9, 34348, 19, 6, -1, 78, 64, 8492, 44, -14, 54, 64, 1620, 16, 8, 56, 55, 6, -1, 78, 62, -1, 307, 22, 0, 6, -1, 307, 53, 62, -1, 308, 6, -1, 308, 22, 1, 6, -1, 308, 64, 968, 8, 12, 54, 64, 2900, 8, -13, 54, 29, 62, -1, 309, 15, 34407, 45, 65, 0, 9, 34437, 22, 0, 27, 253, 62, -1, 0, 39, 0, 1, 15, 0, 51, 31, 64, 4808, 12, 15, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 34436, 19, 6, -1, 79, 64, 8492, 44, -14, 54, 64, 6948, 28, -14, 56, 55, 15, 34458, 45, 65, 0, 9, 34489, 22, 0, 27, 254, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 31, 64, 4808, 12, 15, 56, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 34488, 19, 6, -1, 79, 64, 8492, 44, -14, 54, 64, 2788, 40, -15, 56, 55, 15, 34510, 45, 65, 0, 9, 34531, 22, 0, 27, 255, 62, -1, 0, 39, 0, 1, 31, 64, 4808, 12, 15, 54, 65, 0, 9, 34530, 19, 6, -1, 79, 64, 8492, 44, -14, 54, 64, 1620, 16, 8, 56, 55, 6, -1, 79, 62, -1, 310, 22, 0, 6, -1, 310, 53, 62, -1, 311, 15, 34567, 45, 65, 0, 9, 34839, 22, 0, 27, 256, 55, 39, 2, 0, 1, 2, 6, -1, 2, 15, 0, 51, 18, 9, 34592, 15, 0, 43, -1, 2, 55, 15, 3735928559, 6, -1, 2, 61, 62, -1, 3, 15, 1103547991, 6, -1, 2, 61, 62, -1, 4, 64, 11032, 8, -8, 40, 64, 9684, 8, 0, 54, 62, -1, 5, 6, -1, 1, 22, 1, 6, -1, 1, 64, 3564, 24, 3, 54, 64, 2900, 8, -13, 54, 29, 62, -1, 6, 6, -1, 1, 64, 3156, 16, 16, 54, 62, -1, 7, 15, 0, 62, -1, 8, 6, -1, 8, 6, -1, 7, 12, 9, 34730, 6, -1, 8, 22, 1, 6, -1, 6, 29, 43, -1, 9, 55, 15, 2654435761, 6, -1, 3, 6, -1, 9, 61, 22, 2, 6, -1, 5, 29, 43, -1, 3, 55, 15, 1597334677, 6, -1, 4, 6, -1, 9, 61, 22, 2, 6, -1, 5, 29, 43, -1, 4, 55, 47, -1, 8, 0, 55, 65, 0, 9, 34661, 15, 2246822507, 6, -1, 3, 6, -1, 3, 15, 16, 46, 61, 22, 2, 6, -1, 5, 29, 43, -1, 3, 55, 15, 3266489909, 6, -1, 4, 6, -1, 4, 15, 13, 46, 61, 22, 2, 6, -1, 5, 29, 20, -1, 3, 55, 15, 2246822507, 6, -1, 4, 6, -1, 4, 15, 16, 46, 61, 22, 2, 6, -1, 5, 29, 43, -1, 4, 55, 15, 3266489909, 6, -1, 3, 6, -1, 3, 15, 13, 46, 61, 22, 2, 6, -1, 5, 29, 20, -1, 4, 55, 15, 4294967296, 15, 2097151, 6, -1, 4, 24, 23, 6, -1, 3, 15, 0, 46, 13, 65, 0, 9, 34838, 19, 62, -1, 312, 64, 10516, 196, 2, 15, 1, 14, 22, 0, 6, -1, 87, 29, 22, 0, 6, -1, 86, 29, 15, 1, 14, 15, 1, 14, 15, 1, 14, 22, 0, 6, -1, 82, 29, 15, 1, 14, 22, 9, 62, -1, 313, 15, 34891, 45, 65, 0, 9, 34906, 22, 0, 27, 257, 55, 39, 0, 0, 22, 0, 6, 0, 88, 29, 19, 34, 34, 15, 34915, 45, 65, 0, 9, 34930, 22, 0, 27, 258, 55, 39, 0, 0, 22, 0, 6, 0, 85, 29, 19, 15, 34937, 45, 65, 0, 9, 34952, 22, 0, 27, 259, 55, 39, 0, 0, 22, 0, 6, 0, 84, 29, 19, 15, 34959, 45, 65, 0, 9, 34974, 22, 0, 27, 260, 55, 39, 0, 0, 22, 0, 6, 0, 83, 29, 19, 34, 15, 34982, 45, 65, 0, 9, 34997, 22, 0, 27, 261, 55, 39, 0, 0, 22, 0, 6, 0, 81, 29, 19, 22, 8, 62, -1, 314, 6, -1, 91, 6, -1, 93, 6, -1, 92, 6, -1, 90, 6, -1, 89, 22, 5, 62, -1, 315, 6, -1, 100, 6, -1, 102, 6, -1, 101, 6, -1, 99, 6, -1, 98, 6, -1, 97, 6, -1, 96, 6, -1, 95, 6, -1, 94, 22, 9, 62, -1, 316, 6, -1, 104, 6, -1, 108, 6, -1, 107, 6, -1, 105, 6, -1, 106, 6, -1, 103, 22, 6, 62, -1, 317, 6, -1, 317, 22, 1, 6, -1, 316, 22, 1, 6, -1, 315, 64, 11504, 8, 13, 54, 29, 64, 11504, 8, 13, 54, 29, 62, -1, 318, 15, 35112, 45, 65, 0, 9, 35250, 22, 0, 27, 262, 62, -1, 0, 39, 1, 1, 2, 22, 0, 62, -1, 3, 6, -1, 2, 64, 1988, 20, -18, 54, 62, -1, 4, 15, 0, 62, -1, 5, 6, -1, 5, 6, 0, 318, 64, 3156, 16, 16, 54, 12, 9, 35227, 0, 35206, 22, 0, 6, 0, 318, 6, -1, 5, 54, 29, 62, -1, 6, 6, -1, 6, 33, 64, 1172, 24, 7, 18, 9, 35189, 34, 65, 0, 9, 35192, 6, -1, 6, 6, -1, 3, 6, -1, 5, 56, 55, 5, 35202, 65, 0, 9, 35218, 62, -1, 7, 34, 6, -1, 3, 6, -1, 5, 56, 55, 47, -1, 5, 0, 55, 65, 0, 9, 35144, 6, -1, 4, 22, 1, 6, -1, 3, 64, 4628, 8, 2, 54, 29, 55, 6, -1, 3, 65, 0, 9, 35249, 19, 6, -1, 109, 64, 8492, 44, -14, 54, 64, 5912, 28, 13, 56, 55, 15, 35271, 45, 65, 0, 9, 35331, 22, 0, 27, 263, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 31, 64, 5912, 28, 13, 54, 29, 62, -1, 3, 64, 7604, 24, 18, 6, -1, 3, 22, 1, 64, 28, 16, 19, 40, 64, 2928, 52, -18, 54, 29, 22, 2, 17, 64, 7028, 28, 5, 54, 29, 65, 0, 9, 35330, 19, 6, -1, 109, 64, 8492, 44, -14, 54, 64, 2584, 12, -6, 56, 55, 15, 35352, 45, 65, 0, 9, 35435, 22, 0, 27, 264, 62, -1, 0, 39, 1, 1, 2, 31, 62, -1, 3, 15, 35374, 45, 65, 0, 9, 35410, 22, 0, 27, 265, 62, -1, 0, 39, 1, 1, 2, 6, 264, 3, 64, 5060, 24, -7, 54, 6, -1, 2, 22, 2, 17, 64, 10936, 20, 8, 54, 29, 65, 0, 9, 35409, 19, 22, 1, 6, -1, 2, 22, 1, 31, 64, 2584, 12, -6, 54, 29, 64, 1792, 8, 2, 54, 29, 65, 0, 9, 35434, 19, 6, -1, 109, 64, 8492, 44, -14, 54, 64, 8160, 20, 3, 56, 55, 15, 35456, 45, 65, 0, 9, 35717, 22, 0, 27, 266, 62, -1, 0, 39, 1, 1, 2, 31, 62, -1, 3, 15, 35478, 45, 65, 0, 9, 35704, 22, 0, 27, 267, 62, -1, 0, 39, 2, 1, 2, 3, 0, 35681, 6, 266, 2, 64, 2560, 8, 5, 54, 2, 9, 35516, 34, 22, 1, 6, -1, 2, 29, 55, 35, 65, 0, 9, 35703, 6, 266, 2, 64, 10428, 12, -21, 54, 33, 64, 10292, 12, 13, 18, 9, 35552, 6, 266, 2, 64, 10428, 12, -21, 54, 22, 1, 6, -1, 2, 29, 55, 35, 65, 0, 9, 35703, 15, 35559, 45, 65, 0, 9, 35606, 22, 0, 27, 268, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 64, 2560, 8, 5, 22, 2, 17, 64, 6980, 20, 17, 54, 29, 55, 15, 0, 22, 1, 6, 267, 2, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 35605, 19, 22, 1, 15, 35615, 45, 65, 0, 9, 35646, 22, 0, 27, 269, 62, -1, 0, 39, 1, 1, 2, 6, -1, 2, 22, 1, 6, 267, 2, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 35645, 19, 22, 1, 6, 266, 2, 22, 1, 6, 266, 3, 64, 8160, 20, 3, 54, 29, 64, 1792, 8, 2, 54, 29, 64, 11016, 16, -16, 54, 29, 55, 5, 35677, 65, 0, 9, 35694, 62, -1, 4, 6, -1, 4, 22, 1, 6, -1, 3, 29, 55, 64, 1172, 24, 7, 40, 65, 0, 9, 35703, 19, 22, 1, 64, 5084, 12, 4, 40, 53, 65, 0, 9, 35716, 19, 6, -1, 109, 64, 8492, 44, -14, 54, 64, 11240, 16, -4, 56, 55, 6, -1, 109, 62, -1, 319, 22, 0, 6, -1, 319, 53, 62, -1, 320, 7, 0, 15, 0, 51, 22, 0, 22, 3, 62, -1, 321, 34, 62, -1, 322, 64, 9064, 28, 20, 64, 1104, 12, -20, 64, 5548, 16, -3, 64, 1296, 16, -11, 64, 3088, 24, -5, 64, 5796, 20, 11, 64, 300, 28, -10, 64, 3064, 12, -20, 22, 8, 62, -1, 323, 22, 0, 62, -1, 324, 6, -1, 311, 64, 1920, 4, -21, 3, 6, -1, 308, 64, 4904, 4, -9, 3, 6, -1, 305, 64, 2376, 4, 9, 3, 6, -1, 122, 64, 1312, 28, 7, 3, 6, -1, 320, 64, 2560, 8, 5, 3, 6, -1, 123, 64, 4456, 4, 4, 3, 6, -1, 167, 64, 10252, 4, -11, 3, 6, -1, 122, 64, 3620, 4, -3, 3, 6, -1, 124, 64, 8712, 4, 4, 3, 6, -1, 125, 64, 6212, 36, -19, 3],
                _VXR9QNym: atob("YzJ0MWJDVXlRM0owWVd4b2N5VXlRMlJ4Y1c1eE55VTBNQ1V6UXlVelFnPT1YMmhyWmlVMVEyaG5iV3RvWldkYVppVTFSUT09SlRWRkpUWXdVMkZoWXlVMk1GTT1TZz09Wm5CNWRnPT1iU1UzUXlWRE1pVTRNM3ArZVE9PWFYVjBlbXQwZWlVMVJHOTBhblVsTjBRPVdsY2xNa01wTlNVMVJDbGlXWGMwS0hrbE1qQT1KVFZDSlROQlh5VTFSQT09Ylc1alpGTjRiMlE9SlRWRVVFNWFKVFZFVHc9PWRYTjJaZz09WDJKbE1YNUZNU1UxUlRReEpUTkVZU1V5Umc9PVMxZFFUMHh4YzNoM1NHOW9jR2h4ZHc9PWVDVTNRbkp3Y25jPVoyaGpaQT09SlROREpUTkZiMjRsTTBFbE0wRWxOREFsTTBVPVZDVTFSU1V4T0V4T1gxUmhVQT09SlRWRlRnPT1KVU15SlRnM2VYNTBKVGRHSlVNeUpUZzNaVmRtTmxObVV3PT1jU1ZETWlVNE5uRjVKVGREWjNsMEpVTXlKVGcwZUE9PVZnPT1kSGw2SlRkRWRWOGxReklsT0RCMWRpVkRNaVU0TkE9PU15VXlRaTBsTWtJPVpXZz1aRk5wZmlWRE1pVTRNM3B2ZDNBMmVTVTNRbklsTjBNbE4wUnlkMjQ9SlRGRlVWY2xNak53SlRJMkpUSXpKVEpHVXlVeFJpVXhSVkUzSlRJelVGTWxNVVk9TjI1dUpVTXlKVGhDSlROREpUTkRPR29sTTBZbE0wTkljQ1V6UXlWRE1pVTRPV3dsUXpJbE9FRkVKVE5DSlVNeUpUaERNdz09VmlVMVJGWWxOVVZXWDJWRVZpVTFSRlpVWlNVMk1HTT1KVFZGTXpBbE0wTmtNR2tsTmpCK0pUTkNKVU15SlRnd01DVTFSVE13SlRORFpEQnBKVFl3ZmpjbFF6SWxPREE9VjFWa0pUTkVWVkVsTlVVbE5EQlZZbGxmVkE9PVJtMW1ibVp2ZFE9PWEyRnlKVFZFSlVNeUpUZzBKVGRHWXlWRE1pVTROQ1ZETWlVNE1ubCtkdz09V0ZabEpUTkJaVllsTlVVPWMzVmlkR3hsSlRWRVlYQmpYM0pqVkdkeFp5VTJNR2RxWjNKM1NtZHhjbU5zWTNCeEpVTXlKVGhCWTJseVozWWxOMFIwZUE9PWJuaDFjWFFsTjBOMUpVTXlKVGd6SlVNeUpUZ3pKVU15SlRnMWVTVXpSQT09VWs5aVR5VXhRbE5rWWxwUFVGTmFhR1pWVjE4PVdTVTFSU1UyTUdWa0pUSTBNVjhsTWpReVpteG1iaVZETWlVNE5TVXpSaVZETWlVNE56STNabTRsUXpJbE9EVWxNMFVsUXpJbE9EY3pTV1pzYTNCNmFuWjFkV3hxSlRkQ0pUVkRKVU15SlRnekpUZENjSE1sUXpJbE9EQT1XbGxxUkhaSmVFZElTRVU9YldzbFF6SWxPRElsTTBFbFF6SWxPRUpySlVNeUpUZ3lKVE5CTXc9PVVGVlNVRmhQSlRWRFpRPT1ibWNsTlVRbE5VVmZZbWNsTlVVbE5VUT1maVUzUWlWRE1pVTRNRzBsUXpJbE9EQjFKVGRDZWlVMVJXMGxReklsT0RCeFZHc2xNak09ZW0xMGQybHNZMlp6ZVhKb1IzQnRaMjlNWlhKb2NHbDJmaVUzUWlWRE1pVTRNWHB3SlRRd1FXeEJKVFF3YjBGc0pUVkRhR1ZsSlRWRkpUVkRiVTltSlRORVdtMWFKVGREY3lWRE1pVTROV1J2ZWlWRE1pVTRNM009WWlVMVF3PT1KVEkyY0NWRE1pVTRObkI1ZG5BPUpUSXlPVFJZZGxWWUtpY3pWeVV5TXlVeU1pVXlNamswVmlVeU5WVXFKek5YZFNVeVFpVXlOaTEzVlNjb1ZtMVhPU1V5TXprbE1qSTVORllsTWpJNVZTb25NMWQxTFhkV0pUSXpPVlVuS0ZadFZ6a2xNak01VlNvbk0xZDFMWGRWSnloV2JWYzVWU29uTTFkMUxuY2xNak1sTWpJNUpURkNWU29uTTFjbE1qTT1aV0ZXYVNVMVFtUm5ZZz09VFZsV1dTVTFReTVQV2lVMVJWST1WQ1UxUWc9PWFTVTJNQT09WHlVMVJHd2xNME5aYkZrPVpHRjBaUT09SlRJMFpHbGliMmhtWlZWd2RtUnBablE9WmlVMVFtST1KVGRFY25OMkpUZEVlWFlsUXpJbE9EbDJRaVZETWlVNE9Yb2xReklsT0RnbFF6SWxPRGwrZVE9PVpuSnNKVU15SlRnd1ZHZ2xOMEpzZVhCb2N3PT1KVU15SlRoQkpUZEdKVU15SlRoQkpVTXlKVGd5SlRkQ2NtWmpiQT09YlhRPWVRPT1KVGRHZEhod1RTVkRNaVU0TUhGeGNDVTNSSDQ9SlVNeUpUZ3pKVU15SlRnMGNTVkRNaVU0TWlWRE1pVTROR1I1SlRkRWRRPT1KVGRFYkhsdmVuZz1kMnh3YUhaM1pIQnpKVFZEVHlVMVFsTT1jbUU9ZGc9PVVsWmtKVE5GV0ZRbE5VVT1maVZETWlVNE1DVkRNaVU0TmlWRE1pVTROSForSlVNeUpUZ3dKVU15SlRnM2RnPT1kU1ZETWlVNE5IRWxReklsT0RVPVdsbFRXQ1UxUlU4bE5VTmZXZz09WTJGd1FXaGhhV0ZxY0c4bE0wVjFVQ1UxUkdOS0pUVkVhV0U9SlRWRlVGOGxNMFpVV0ZCYUpUWXdYdz09ZHc9PUpUTkZaMjBsTlVWcmJ5VTNReVUzUm5GMFp5VXpRemxGYlRseWFTVkRNaVU0TjBRNEpVTXlKVGc1SlRWREpUVkZZMWdsTlVVbE5VUT1ZblVsTjBSNGRpVkRNaVU0Tnc9PVlsRlRWUT09Y1c1NmFYVnRKVGRDY0NVM1JIRjZKVGRFZUd4NWJuQT1kMmxuYzNKb1pYWWxOMFE9SlVNeUpUZ3pmaVZETWlVNE5ISjNkQ1ZETWlVNE1nPT1haVUxUTFocFdsOVpabTg9V1ZkbU9GOUZabE5tVjBrbE5VSm1XaVV6UWlVMk1GWWxOVUpWVjJVPWJtd2xOMEk9ZW40bFF6SWxPREk9SlRWRVdGbGlhQ1UxUkZvbE5VUlpaZz09V1E9PVpGVmlaRmxSWW1rPUpUZEdiV3B6Y1NVM1ExVnBKVGREYTNCdEpUZENKVFZDYlhSdGF5VTNRM2Q2YkhoM0pUZEVibmNsTjBSdWJYSWxOMFJxYTNWdWFXUmljU1UyTUhackpUWXdaZz09SlRGR1VDRWxNVVlsTWpCWFVDRT1jRzF6SlROR0pVTXlKVGhEYnlWRE1pVTRSRVVsTTBWRlFpVkRNaVU0UmpZPWIyaGxhR2x4YUE9PUpUVkZiUT09YW5GcWNtcHplVkZ1ZUhrPVpXMXJlazVuZVc0PVdHSXdZV0ZRYUE9PWIzaHhiWDRsTmpCMWVYRWxOMElsUXpJbE9ERWxReklsT0RBPWMyWmtjSE5sVldwdVpnPT1KVGRFZGlVelF5VkRNaVU0TWlWRE1pVTRNM0FsUXpJbE9ERWxNME40SlRkRUpVTXlKVGd5ZENWRE1pVTRNU1ZETWlVNE0zUnpKVFZDVEY5VFdVeFlVQT09WVdZbE5VSmtiU1UxUXlVMVJHcz1aSEJ2ZFdKcWIyWnphRmRhWDJVPUpVTXlKVGd5SlVNeUpUZ3pmaVZETWlVNE1YUlRjQ1ZETWlVNE0zQT1OMVJuV0VjbE5VTWxOakJZT1dKbEpUWXdWR2M9ZDJoMmR3PT1mbmNsUXpJbE9EWnplbEp6ZmlWRE1pVTRNblk9WlZsb2FtUjRiM1lsTjBKeFVDVTFSQ1UxUkZwVFR5VTFRdz09SlVNeUpUZzFKVU15SlRnMkpVTXlKVGcwSlRkQ0pVTXlKVGd3ZVNVM1FuZ2xReklsT0VJPUpUZERkMVIzSlRkR2JYcExhU1UzUW0wPUpURTVKVEJFYm5rbE4wUjFiZz09Y21SckpUWXdZMlJSWkZVPUpUZERmaVZETWlVNE5DVkRNaVU0TW5RPVNFcEhkazFGUzNrPVgyUmxZM0o1Y0hRPUpUTkZKVE5FSlRORU9HYzJKVE5FWnc9PUpUZEViaVUzUm5JbE4wSWxReklsT0RFPWJuVm5jR2tsTjBKd1ozVnBlQT09SlRWRFZTVTFSVmRrV0E9PWVTVkRNaVU0TXlVMVJYRWxOVVU9SlRkREpUZENiQT09SlRZd1V5VTFSVnBQVVZNPVoyVjBSVzUwY21sbGMwSjVWSGx3WlE9PWJHOXJjbW89WTNkbGVtbE1aWEpvY0drPWJTVTJNR1VsTmpBbE5VVnZheVUxUW1vbE5VUWxOVVJtSlRWRWFDVTFRMjVtSlRWRloyMD1XRlJaSlRZd1UyZ2xOVUpaVTJaaFpBPT1VRlZPSlRWQ1ZGSXVZbUVsTlVNd1RpVTFSR0ZpWDFJd0pUVkRKVFZDVTFaVUpUWXdaRlpoVUZVPVh5VTFRMjhsTlVNb1ppVTJNSFE9Y0haQ0pVTXlKVGhHY2c9PVdXVmthV3BvYTFscUpUTkVTVUpCSlROQllWcGlXbU5wSlVNeUpUZ3djU1ZETWlVNE5DVkRNaVU0TUE9PWJYWjVkRFJxZG5VbE4wSjVkbk09WWxwa0pUVkNKVEZDVVNVMVJGcGFVMUZpSlRGQ1V5VTJNQ1UyTUNVMVJDVTJNQT09SlRZd1pTVTFSVzhsTkRCc1lXSWxNMFZ4WldvbE5qQmhkRXRpWkdWYUpUVkNURmRpYXlVMVFnPT1kZz09Y2lWRE1pVTROM1IxSlRWRGR3PT1VVlJqVUE9PWVDVkRNaVU0TVhVbFF6SWxPRGNsUXpJbE9EVWxNMFlsUXpJbE9EZ2xOMElsUXpJbE9EVWxOMEowZm5jPVpBPT1hM1ZXZEhkMWRtZG1YMWRoV0NVeE9DVTFSRkJPWVNVeE9GQWxOVVFsTlVSYUpUVkVWQ1UyTUNVMVJWTWxOakJUSlRZd2FRPT1iV2x2YkNVMVJGOD1KVU15SlRnMWRpVTNRM3B1VlNWRE1pVTROaVZETWlVNE5uVWxReklsT0VRPWMzUnlmbk4wSlRWRWZuTjBlaVZETWlVNE15VkRNaVU0TmxsMWR5VTNRdz09ZG01MWRHcz1KVU15SlRoR2ZpVkRNaVU0TlE9PUpUVkZUeVUyTUdGVE55VTFRMkk9WXlVMk1ITWxOakFsTWtOelpISnpaR1o2ZVhSSVpuVjVlbmRxU0hSemEyNXNKVGRFSlVNeUpUZ3hjWDRsUXpJbE9EVmZjWGh4YnlWRE1pVTRNQ1UzUW41TmVIZz1jSFlsTjBad1R5VkRNaVU0TW5OekpUVkVKVU15SlRneUpVTXlKVGd3ZFE9PWJDVkRNaVU0TVd4MGQxTndkSEp6SlRkR1h5VTJNQ1UxUlcxMGEyOD1iV1lsTWtOb2JYVWxOakJyYUdNPUpVTXlKVGd4SlVNeUpUZ3pjQ1ZETWlVNE1TVkRNaVU0TWlWRE1pVTRNSGNsTjBOMVpXZFVabVJYVnc9PVVpVTFSVjlvY0hsdUpUZEVKVU15SlRnMEpUZENKVGRHSlRORlRrc2xOVVZMSlRFM0pUVkNTeVV4TjFOT1dtc2xOakJwWDJScFlrdHRhbWhrYmlVMk1HND1ORFEwTkE9PVJXSjFaZz09UVNVMk1HSnFjbThsTmpCaVpBPT1TU1UxUTA5TldTVTFRMDRsTWtZbE5qQlBXQ1UxUlE9PUpUZENKVU15SlRneWRDVTNSSFlsUXpJbE9EZ2xOMFIwZmlWRE1pVTRNM2w2SlVNeUpUaEVKVGRDSlRkR0pVTXlKVGd5SlVNeUpUZ3hKVU15SlRnMEpVTXlKVGcySlRWRWR5VkRNaVU0UWc9PUpUWXdKVFl3WkhObVluVm1UMkozYW1oaWRXcHdiMDFxZEhWbWIyWnpkQT09ZGlWRE1pVTROQT09WkdjbE5VSlpiR0ZuWmc9PVpRPT1KVU15SlRnekpVTXlKVGcwZVhwamRpVkRNaVU0TW5vPUpVTXlKVGd5ZmlWRE1pVTRNU1ZETWlVNE13PT1XV0lsTlVKb0pUVkZabDlOYm1sc0pUVkNZVjhsTTBad1gyaHVibk54Wmc9PWVTVkRNaVU0TTNaM1ptVnBha01sTlVKcGFWY2xOVVFsTlVJPVdTVTFSR3hmSlRWQ2JsOGxNMFp3WDJodVJtTnRibDlvWDJ4dEpVTXlKVGd4ZVNWRE1pVTRPSFZmZVNWRE1pVTRSQT09SlVNeUpUZzJKVU15SlRneEpVTXlKVGczZFhwM0pVTXlKVGd3ZGc9PUpURkViU1UzUm5wc2FpVTFSR3RuWkc0bE5VUT1VbDlrYUZaalpBPT1ZVjlzWVdOcVIySnFZMEZmYW1vbE5qQmZZV2s9YVd3bE5qQWxOVVZwWWc9PVMxSldlQ1UzUkhKNGR3PT1hR1ZxWnc9PVpsaG5KVEZFSlRGRUpUVkRhblU9WVhWamVHYz1WM1VsUXpJbE9EUWxReklsT0RjbE5qQWxReklsT0ROM0pUZEdhaVUxUTFocFdsOD1WVmhZSlROQlkyWmhPU1UyTUZsaFdXSm9kSFVsTjBRPVV5VTFSR0ZrWTJab0pUTkdXVzA9WkNVMVJGcFVWZz09WWxWalZXUT1YeVV5UWlVeVFqRXVKVEpEWHlVeVF3PT1KVFZDVmlVMVFraFRabEJVU0U1TVdnPT1URzVyYVdWdllRPT1jWGR4ZVNWRE1pVTVNRVpCUnlWRE1pVTVNbkJDUkhKeGVTVkRNaVU1TUVaQlJ5VkRNaVU1TW5CQ1JISnhlU1ZETWlVNU1FZEJTU1ZETWlVNU1uRjNiU1UyTUdvbE5qQlpKVFl3WXlVMk1HdHdXbDlZWlNVMVJTVTFRdz09Y2lVM1JDVkRNaVU0TlNVMVEzWWxReklsT0VFPVlTVTFSWEVsTlVVcVkyWmlhV0U9SlRWRmEydz1VbGRVWjFRPWJWOWFhaVUxUlE9PVgxSWxOVVJaVGxCU0pUUXdZVTVoVWc9PWRXWjNlR289SlVNeUpUZzJlU1ZETWlVNE5TVkRNaVU0T1hrbFF6SWxPRGNsUXpJbE9EZ2xOVVI0SlVNeUpUZ3dlVmQxSlVNeUpUZ3dKVU15SlRnd2RuVjNKVGRHYWlVMVJHNGxOakJ0Y1NVMk1BPT1KVFl3WDFrbE5VVmtWV0pVWDJjbE5VVT1ibXdsTjBSdmZua2xOMFp0Y2c9PVZtbFdWQT09SlVNeUpUZ3dKVGRDSlVNeUpUZ3hiM1I1SlRkQ0pVTXlKVGd5Y1E9PUpUWXdZbWhtV0Y5WVZHbFljR05yWm1SMUpUTkNNemxtTkdscE5nPT1KVU15SlRnemRIcDRhdz09YkdsbVh3PT1jWDUrSlRkQ2ZnPT1ibXR2Ylc1NmRDVkRNaVU0TkhjbFF6SWxPRGg2SlVNeUpUZzNKVU15SlRoQ2VpVkRNaVU0Tnc9PVl5MTBhVzFsSlVNeUpUZ3djMjl5VG1FbE5VTlBTbGhRSlRWRVVsQWxNa1pNWDB3PWRDVTNSSHAySlRkR0pVTXlKVGcxYVE9PVh5VTFSVmdsTlVSalZHRWxOVU1sTlVWbFZBPT1kSElsTjBOekpUZERlWE1sTjBJPVkzZDRjM1psYTJsUGFTVTNSQT09V2xnbE1rSW9KVEpES2lrbE1rST1jaVZETWlVNFFTVkRNaVU0TjI5RVFVMXhKVGREZVhNPWIzaHRlVzV2ZEdnbE4wSnFiMng2ZHlVM1EzVWxReklsT0RBbFF6SWxPREI1SlVNeUpUZ3lKVGRDZVE9PVdXYz1VbHBZWnpaZkpUVkRXR0ZuUmlVMVExcGhWRjltVkZGa1VXTlZaQT09SlVNeUpUZ3plUT09T1NVMVJXUWxOVU09WldVPVQwMVlXQT09SlRJMk16RXpNVE1sTTBJNU1nPT1lR2tsTjBJbE4wSWxOMFozZW13PUpVTXlKVGd5ZFhGMFgzNGxOME1sUXpJbE9Eaz1iM2gxSlRkRGJpVTNRbTErY0ZCdEpVTXlKVGd3YlE9PVVXSlJXaVUyTUNVeVJpVTFRaVUxUWlVMVJWQmZhR1Y0WlRGMVpRPT1maVZETWlVNE15VkRNaVU0TVhaaEpVTXlKVGd5YnlWRE1pVTRNbk09VjJwc1NpVTNSSFU9SlVNeUpUZzVKVGRFZWlWRE1pVTRNbm89WkZWbmFGaz1KVU15SlRnMkpVTXlKVGczZENWRE1pVTROU1ZETWlVNE53PT1URkJaVmxCWU5VNGxOVUpSV1ZKZlpWaG1ZbDlwV0ZkQ1kyY2xOVU5pWVdZPVdWWlhibHBZSlRJMmQxWlhibHBZSlRJMkpURkdhaVUxUTJGWFltcE1kM3A2V1Y5eFltbFpYdz09SlRkR2RIVnlKVU15SlRnd1lXa2xOVVJsYUE9PUxTMG9XU1V6UldkaUpUTkNKVEl3YnlWRE1pVTROWDRsUXpJbE9ETWxReklsT0RVbFF6SWxPREFsUXpJbE9EQWxOMFlsUXpJbE9ESWxReklsT0RSMWRBPT1UaVUyTUZvPUpUWXdaU1UyTUd0SkpUVkRXbVpwSlRWQ1VIaDNaSGRzY25GU1pYWm9kWGxvZFE9PWRuQWxReklsT0RSK2RYTWxReklsT0RKaWR5VTNRbk1sUXpJbE9EZ2xOMFFsTjBOekpUVkVkSFFsUXpJbE9ERnpKVU15SlRneVFXNWhiSGwwYVdOelZGbGFKVFZFVlNVelJGcGtaUT09SlVNeUpUZzFlbjUyVFZsVFp3PT1KVGRFZHlWRE1pVTRRbllsUXpJbE9ERWxReklsT0RrbFF6SWxPREE9VEdkdEpUVkNKVFl3SlRORWJpVTFSR1pzVVdJbE5qQmFPVk5uZVhNbFF6SWxPRGNsUXpJbE9ETitKVU15SlRneWIzVWxOVU52SlRkQ2N3PT1KeVUyTUd4bFpDZGFaeVUxUTNFPUpUZEdjbm9sTjBNbFF6SWxPRE55VWlWRE1pVTRNM0lsTjBJbFF6SWxPREZaZGlWRE1pVTRNQ1ZETWlVNE1YSWxOMEp5SlRkR1kyaGpia2R2YmlVMVFtNWphV2hKSlRWRGJWOXNjRjlzY0cxbWExOXljWEZzYXc9PUlXUndYMnRqSlROQ1kyRndKVE5HYXlVMVJHaGhiMTloSlRZd1FYSmhhbkJ2Y1hwemJ5VkRNaVU0TUZKdkpVTXlKVGd5Ync9PWIyOWxZbFFsTlVSallXZzBZV0VsTlVWaGFTVTFSV0phVDJSaldnPT1iRmxxWHlVMVJHdz1ZaVUyTUdrbE5qQnRKVFZEYnlVMk1FTWxOakJ6SlVNeUpUZ3lKVGRDUVNWRE1pVTRRWFVsUXpJbE9EQWxOMFI0YW5CcEpUTkZKVE5DUjJzbFF6SWxPRGxFSlROQkpVTXlKVGhDYW5BPWVuZHhSM0YwYUhCUmJuaDVaVzVqZFhVPVdpVTJNSEVsTmpCcGIyNU9iMnB0SlRWRFlpVTJNQT09VFZaTEpUVkVKVFZFT0V0WFR3PT1WQ1UxUWw4bFF6SWxPREVsUXpJbE9EWWxOMElsUXpJbE9ERWxReklsT0RCTU1pVTNRaVZETWlVNE1DVTNRaVZETWlVNE5sOGxReklsT0RjbFF6SWxPRFp6SlVNeUpUZzJKVGRDSlVNeUpUZ3hKVU15SlRnd1lYUWxReklsT0RWM0pVTXlKVGcwSlVNeUpUZzRkeVZETWlVNE5BPT1ZbVp0ZUhjeFVGVmZUVTVZVVZBPU1DVTFSQ1UxUkZwVFR5VTFRdz09U2lVeE5DVXlRaVV5TmtkTkpURTVaa2xIVFNVeE9XWWxNVU1sTVRrbE1qVWxNVGNsTVVFbE1UbEpKVEUySlRJMlNDVXhRa2dsTVVKb1NDVXhRa2dsTVVKb1NDVXhRbWdsTUVab1NDVXlRbWhIVFNVeE9XWWxNVU1sTVRrbE1qVWxNVUZMSlRFNVNTVXhOMGdsTVVKSFNraGZTU1V4TmlVeE5RPT1WMm9sTlVSWkpUVkRjUT09WVdOalpXeGxjbUYwYVc5dVVGOVlRVFlsTWtZbE1VSWxNakFsTWpNbE1qUT1KVU15SlRoRUpVTXlKVGhGZHlWRE1pVTROaVZETWlVNE5pVkRNaVU0TWlWRE1pVTRSZz09SlRkR0pVTXlKVGd5SlRWQ0pUUXdibUZ0WlNVelJDVXlNZz09U1E9PUpUVkVKVFZEWWlVMVJHTlJWbUZpVHlVMk1HST1XVkprV1ZSWlVsOVlWZz09YlhCd2NYQmFKVGRDY0hFbE4wWT1aU1UxUkdjbE5VVWxNVVZrSlRWREpURkZYMllsTlVRbE5VUT1hSGxvY1hjPUpUZERiblZ1YkNVM1JBPT1WbXR2WjBSM2FHaG5kQT09T0ZrbE5qQlphRms9ZHlWRE1pVTRNeVZETWlVNE1INVVlWElsUXpJbE9ETlVKVU15SlRnd2RYWT1jaVZETWlVNE1DVkRNaVU0TW5kNEpUVkZjV1JyYmlVMk1HTkliVTl4Ym1aeFpISnlUMVlsTlVWVFZtTWxNVVU9YWc9PUpVTXlKVGd4SlVNeUpUZ3dlaVUzUmlWRE1pVTROWFlsUXpJbE9ETmxKVU15SlRoQkpVTXlKVGd4ZGc9PVpTVkRNaVU0TmlWRE1pVTROQ1UzUWlWRE1pVTRNSGs9SlRZd0pUVkNXV2hzSlRWQ0pUWXdXUT09SlVNeUpUZ3dlU1V6UmlVM1JpVkRNaVU0TVhaM2ZnPT1hVzlKSlRWRWNGOWtZVzlQWVdoaFgzQnJiZz09SlRWRFpHSnhKVFF3VDBacllXSjFiR3A1VjJaemFYUnlKVFZDWm5GNmFuZz1KVFZDYkNVM1JpVTNRa3gxYW5acmJIaz1WRTBsTlVWUVkwMGxOVVZSSlRKR0pUVkNXazloSlRWRkpUVkZVVnBQWlE9PVRWTWxOVU5SSlRWRVVsTXhKVFZFSlRWRFZGZFZRaVUxUkRCWFlsUmFUMVZoY2lVM1EweDRkeVUzUkc1M0pUZEVUbTF5SlRkRWFtdDFiZz09YldvbE4wUnFObXdsUXpJbE9EST1hM1Y2ZFNWRE1pVTRNQT09WkZWb1pGSmZhQT09WjFrbE5qQlpWMmdsTlVSallqbGlXQT09ZFdWMFoyZHdXZz09SlVNeUpUZzRUVk1sTVVac015VXhSa3hQSlRZd1V5VTFSVk5QWWc9PUpUVkVWbWdsTlVRPUpUTkdmaVZETWlVNE1DVTNSQ1ZETWlVNE1pVTNSQ1ZETWlVNE1pVkRNaVU0TjM1emRXWjVkVVJ3YjNWbWIzVT1iVmRvWkE9PVdpVTFSRkZQV2tGaUpUVkVKVFl3VDFWVFNYWjJjM1k9ZVhwNGIzUnRiMmR4YUNnbE5VVm5KVFZGYUZscWF5VTFSRVlsTlVSdkpUTkZaMnBsSlRORVpDVTFSR1VsTlVSbWJHcz1WV1o1ZFVWbVpIQmxabk09YUU0bE0wRm5hZz09WmxoZldGWm5KVFZEWW1GR1oxUmxadz09YjNBPVdpVTFSRTlTUWxjbE5VSlRKVFZFYkY4bE5VSnVYeVV6Um5CZmFHND1TVlZPVFZWbWVYVkNjMlppUm0xbWJtWnZkUT09SlRWRVZpVXhRMlFsTlVSakpUVkZaRkpYVkZNPVpTVTFSU1V5TkNVMVFpVTJNR2xyY0E9PVkyVWxOVU1sTmpCVVpXdz1KVFZEWVdOb1p5VXhSaVV4TTJaWVgxaFdaeVV4UmlVeE0yZFlhMmRVWlZoVVptVm1hV3BYYWlVMVFnPT1jVzVxWjNJPWFnPT1kU1UzUW5BbFF6SWxPRE09WmxsWFkyWllKVFZFWWlVMVFnPT1aR0ZITXlVMk1HY3pKVU15SlRnd1l5VkRNaVU0TVNVelFUSWxNMFVsUXpJbE9ETXFKVGREZEg1MU5XdDBhZz09WDFKbldsaFNaVm9sTmpCZmIyUnhhbmhrYW1oMmJGZGlheVUxUWc9PVRTVXhReVV4UTFJbE1qTWxNVU1sTVVNbE1VWT1VRTB6SlRGR1RGTWxNVVpzSlRJeUpURkdKVEpDSlRGRUlVOGxNVVFsTWtadEpUSXlKVEZGSlRJMGJ5VXhOZz09ZEhZbE4wTjZiR3gxSlRkQ2JIaz1aR1YyYVdObFRXVnRiM0o1Zm00bE4wUndjSGxrSlRWRmNYQndhMm89Zm5GNUpUZENKVU15SlRneWNWVWxReklsT0RCeGVRPT1lSFZ2Ukc5dmNucFBiSFozYkdrbE4wTnBOV3hxTldsMmFYUWxReklsT0RFbE4wTnhheVUzUWpWMmFYVnRYM0J0SlRWRGIyUnFhUT09V21OWGFXYz1abGxsYVNVMVJHWlpXQT09ZENWRE1pVTRPQ1ZETWlVNFFTVkRNaVU0TlNWRE1pVTROU1ZETWlVNE5DVkRNaVU0TnlWRE1pVTRPU1UxUWlWRE1pVTRNWFlsTjBNPVpRPT1YMlVsTlVWRU1DVTFSR1F3SlRkRU16QWxNME14WWlndU1DVTJNQzVESlRWRlJEQWxOVVJrTUNVM1JETXdKVE5ETVRBbE5qQXVYekVsTlVWRU1DVTFSQ1UzUm1Rd0pUZEVKVFl3ZmpVbE1rWWxReklsT0RCZlpRPT1aMjFuYnlWRE1pVTROaVV6UmlWRE1pVTRPR1k0WjM1b1NtZHZKVU15SlRnMkpUTkdKVU15SlRnNFpqaG5mbWhLWjI4bFF6SWxPRFlsTTBZbFF6SWxPRGhtT0dkK2FFcG5ieVZETWlVNE5pVXpSVGNsTTBZbFF6SWxPRGhuYlE9PUpUWXdaVjlrYVcxMWJBPT1iWEJ3VVNWRE1pVTRNbkY2SlVNeUpUZ3dXSFVsTjBZbFF6SWxPREJ4ZW5GK1UxUlBUMUJaV0ZvbE5qQWxOVVZRVDFwaVdRPT1kWEIyWkdsMGRXSnpkUT09SlRWQ1ZXRWxOakE9YjNoMWIzYz1WMVJuVkE9PUpUWXdjM054YUdGMGMyUnllUT09SlRWRkpUVkNiaVUxUWljPVp5VXhReVUxUXlVMVJWTlVKVFZDSlRkRGR3PT1ZVk09VlNVMVExVWxOVVJWSlRWRlpHOGxOVVZmVkZVPUpVTXlKVGd6ZFNWRE1pVTRORmtsUXpJbE9EUjFKVGRFVTJRbE5VSlRKVEZHWWxOa1Z5VTJNR1lsTkRCaFZsYz1maVZETWlVNE15VkRNaVU0TTNvbFF6SWxPRGRwZWlWRE1pVTRSQ1ZETWlVNE9RPT1ObkU9SlRkR2J6az1KVU16SlVKREpVTXlKVGczSlVNeUpUZzBKVGRHSlVNeUpUZ3hKVGRESlVNeUpUZ3ljSFZ3YmlVM1FuQnllUT09YzJWcUpUWXdhM05VSlRWRGFtWndVbVoxV1ZOZlgxTT1hWEp2YTNSNlh3PT1KVFZFVlZKbFVpVXhSV1ZXWkdVbE1VVmFWUT09VjJoZlZ5VXlNMkpYV0NVMVFtST1aWFJ0WW5Ob2JtMD1jU1ZETWlVNE5YTWxReklsT0RoM1ZpVTNRaVZETWlVNE5IZDFKVU15SlRnMmZpVkRNaVU0UWc9PWVBPT1WQ1UxUlNVeE9FOVVKVFZGVEUxWFVFOD1YM05pWldwNUxnPT1ZV2dsTmpCVldHVT1kM0J0YUdsMmRuTWxReklsT0RaekpUTkdkMFIzWTJSMWFHSmtiRzV6YUc1dGJuTWxOMEk9ZDNVbFF6SWxPRFJSSlVNeUpUZzBKVU15SlRnMEpVTXlKVGd5ZVhJbFF6SWxPRFVsUXpJbE9EUjFaRjlPSlRWRUpUVkVVbDg9ZUNWRE1pVTROM1IrSlVNeUpUZ3lkaVZETWlVNFJHa2xReklsT0RRbFF6SWxPRUY0SlRkRVpTVkRNaVU0Tkg0bFF6SWxPRE1sUXpJbE9Ea2xReklsT0RnPVJEVmxOQ2xCVWt3M1lURmxZeVV6Umk1V2IwaE9kQzVXZDBOeExuQTJKVFl3YkVFMlJpVTJNRzlyWmxoVFlteE9ZbThsTmpBdUxUQjNNV3BsTjFSSGQySklUVkZYY1ZKc0pUUXdVbVF1U1VGWE1EQm9ZMnhSSlRKR1luTmZRMWRJUVNVeVJtdHNRbkpTTnpCTmMwTjRZbTlHVmxkaldGSm1jMDBsTmpBbE0wWlVZV3BCTUhJMWJFSnFkRkZTY0d4MWNuUT1YMlJpVnpSbFZDVTFSR009YjJkeGFDZ2xOVVJqYXlnbE5qQnRiV3B0WWlVMVFtMGxNMEp1Ym14akpUVkRiMjVmSlRWRmFXaz1hQT09YzNSdmNtRm5aUT09SlRWRFlpZ2xNMFlsTTBFbE5VTmtKVGRDTVNVeVF6TWxOMFFsTlVNdUtTVTNRak1sTjBRbE5VTmtKVGRDTVNVeVF6TWxOMFFsTlVOaWVXb2xOMEp1ZHlVM1JFNTFiblp1ZHlVM1JBPT1XRXdsTlVWV0pUSkRWMWNsTTBaUVkxOD1WbEZaVWc9PUpUWXdKVFZFY0VWbkpUVkRiV1JuVEZsT1l3PT1jRzlwYm5SbGNrbGtNQT09V0ZWb1ZTRlZhV2hqWVZWb0pUVkVZMkloSlRWRVdBPT1PQT09YzNFbFF6SWxPRFJ6ZUE9PVZXa2xOME53Wm5wdGFXc2xOME0xSlRkQ2JYUnRheVUzUXpVPUpVTXlKVGd4ZVNWRE1pVTROeVZETWlVNE4zVWxOMEo1SlRWRlV5VTJNRmxuVTFsWGVYRWxOMEp5TW5oNlozSnVlVEo1ZEE9PVQxQmhWRTVRSlROQ1ZHTlFWeVV6UkV4ZlZGbz1jbmdsTjBJbE4wSitiV0pqSlRZd2JrVmZjdz09YW10MWRuRjBKVGRDV0NVMVJHTlVZV1ZRSlRWQ1JscGZaU2t5WTJOU2FnPT1kSFp6WjJsM2QwMXhaV3RwVG1FbE5qQWxOakFsTlVKYUpURTRKVEJEVFE9PWVHbHdjSElsUXpJbE9ETjRKVU15SlRnMWRBPT1aMmxXWVNVMVJHZz1aUT09WkhKbWMyNXJhbmg1Y0dGMGNDVTFSRzVoSlRWRUpUVkVYMlZqVldVbE5qQT1lR2s9SlRJMUpUSTFKVEkxSlRJMUpUSTFKVEkxYm1sQ1lXaGhhV0ZxY0VobGIzQmhhbUZ1Ync9PWJYWnBhblJ0YkE9PWZucHZjWE4ySlRkRWVuSnpKVU15SlRnd1FRPT1ZbFZqVldRMFVXUlJUeVV4UWc9PVpuTT1WbWxxY0dsbmVBPT1WbUpoVmxSbg==")
            };

            function t(e) {
                for (; e._DmmS9Z8P !== e._B1PQid;) {
                    var t = e._jok9shc71[e._DmmS9Z8P++],
                        n = e._xYwvz[t];
                    if ("function" != typeof n) return void Be("ooga", "warn", "api", {
                        c: e._DmmS9Z8P,
                        e: e._B1PQid
                    });
                    n(e)
                }
            }
            return e._B1PQid = e._jok9shc71.length, t(e), e._q7N7R9Mdk
        }(), wn = vn.s, bn = vn.m, Rn = vn.b, vn.al, vn.a, Tn = vn.start, vn.stop, vn.j, Sn = vn.d, vn.cr
    } catch (mr) {
        Be("ob-error", "error", "api", {
            message: mr.message
        });
        var _n = function() {};
        _n, Sn = _n, wn = function() {
            return Promise.resolve(null)
        }, bn = {
            record: _n,
            resetData: _n,
            setData: _n,
            getData: _n,
            stop: _n,
            circBuffPush: _n
        }, Rn = {
            record: _n,
            stop: _n
        }, {
            track: _n,
            clearData: _n,
            getData: _n
        }, {
            storeData: _n,
            clearData: _n,
            getData: _n
        }, {}, {
            processImage: function() {
                return Promise.resolve()
            },
            getData: _n
        }, Tn = _n
    }

    function kn(e, t) {
        this.cause = e, this.message = t
    }

    function Un(e) {
        kn.call(this, fe, "Invalid hCaptcha id: " + e)
    }

    function xn() {
        kn.call(this, pe, "No hCaptcha exists.")
    }

    function Wn() {
        kn.call(this, de, "Missing sitekey - https://docs.hcaptcha.com/configuration#javascript-api")
    }
    kn.prototype = Error.prototype;
    var Mn = [],
        Fn = [],
        Nn = {
            add: function(e) {
                Mn.push(e)
            },
            remove: function(e) {
                for (var t = !1, n = Mn.length; --n > -1 && !1 === t;) Mn[n].id === e.id && (t = Mn[n], Mn.splice(n, 1));
                return t
            },
            each: function(e) {
                for (var t = -1; ++t < Mn.length;) e(Mn[t])
            },
            isValidId: function(e) {
                for (var t = !1, n = -1; ++n < Mn.length && !1 === t;) Mn[n].id === e && (t = !0);
                return t
            },
            getByIndex: function(e) {
                for (var t = !1, n = -1; ++n < Mn.length && !1 === t;) n === e && (t = Mn[n]);
                return t
            },
            getById: function(e) {
                for (var t = !1, n = -1; ++n < Mn.length && !1 === t;) Mn[n].id === e && (t = Mn[n]);
                return t
            },
            getCaptchaIdList: function() {
                var e = [];
                return Nn.each((function(t) {
                    e.push(t.id)
                })), e
            },
            pushSession: function(e, t) {
                Fn.push([e, t]), Fn.length > 10 && Fn.splice(0, Fn.length - 10)
            },
            getSession: function() {
                return Fn
            }
        };

    function Pn(e, t) {
        "object" != typeof e || t || (t = e, e = null);
        var n, r, i, o = !0 === (t = t || {}).async,
            a = new Promise((function(e, t) {
                r = e, i = t
            }));
        if (a.resolve = r, a.reject = i, n = e ? Nn.getById(e) : Nn.getByIndex(0)) {
            Ae("Execute called", "hCaptcha", "info");
            try {
                En.setData("exec", "api")
            } catch (pr) {
                Be("Set MD Failed", "error", "execute", pr)
            }
            try {
                Sn(n.config.sitekey) ? (Rn.stop(), bn.stop()) : bn.setData("exec", "api")
            } catch (pr) {
                Be("vm-err", "error", "execute", pr)
            }
            o && n.setPromise(a), n.onReady(n.initChallenge, t)
        } else if (e) {
            if (!o) throw new Un(e);
            a.reject(fe)
        } else {
            if (!o) throw new xn;
            a.reject(pe)
        }
        if (o) return a
    }

    function Zn(e) {
        var t = "",
            n = null;
        n = e ? Nn.getById(e) : Nn.getByIndex(0);
        try {
            for (var r = Nn.getSession(), i = r.length, o = !1; --i > -1 && !o;)(o = r[i][1] === n.id) && (t = r[i][0])
        } catch (mr) {
            t = ""
        }
        return t
    }

    function On(e, t, n) {
        this.target = e, this.setTargetOrigin(n), this.id = t, this.messages = [], this.incoming = [], this.waiting = [], this.isReady = !0, this.queue = []
    }
    On.prototype._sendMessage = function(e, t) {
        var n = e instanceof HTMLIFrameElement;
        try {
            n ? e.contentWindow.postMessage(JSON.stringify(t), this.targetOrigin) : e.postMessage(JSON.stringify(t), this.targetOrigin)
        } catch (pr) {
            De("messaging", pr), "*" !== this.targetOrigin && (this.setTargetOrigin("*"), this._sendMessage(e, t))
        }
    }, On.prototype.setReady = function(e) {
        var t = this;
        t.isReady = e, t.isReady && t.queue.length && (t.queue.forEach((function(e) {
            t._sendMessage.apply(t, e)
        })), t.clearQueue())
    }, On.prototype.clearQueue = function() {
        this.queue = []
    }, On.prototype.setID = function(e) {
        this.id = e
    }, On.prototype.setTargetOrigin = function(e) {
        this.targetOrigin = "*"
    }, On.prototype.contact = function(e, t) {
        if (!this.id) throw new Error("Chat requires unique id to communicate between windows");
        var n = this,
            r = Math.random().toString(36).substr(2),
            i = {
                source: "hcaptcha",
                label: e,
                id: this.id,
                promise: "create",
                lookup: r
            };
        if (t) {
            if ("object" != typeof t) throw new Error("Message must be an object.");
            i.contents = t
        }
        return new Promise((function(t, o) {
            n.waiting.push({
                label: e,
                reject: o,
                resolve: t,
                lookup: r
            }), n._addToQueue(n.target, i)
        }))
    }, On.prototype.listen = function(e, t) {
        if (!this.id) throw new Error("Chat requires unique id to communicate between windows");
        for (var n = this.messages.length, r = !1; --n > -1 && !1 === r;) this.messages[n].label === e && (r = this.messages[n]);
        !1 === r && (r = {
            label: e,
            listeners: []
        }, this.messages.push(r)), r.listeners.push(t)
    }, On.prototype.answer = function(e, t) {
        if (!this.id) throw new Error("Chat requires unique id to communicate between windows");
        for (var n = this.incoming.length, r = !1; --n > -1 && !1 === r;) this.incoming[n].label === e && (r = this.incoming[n]);
        !1 === r && (r = {
            label: e,
            listeners: []
        }, this.incoming.push(r)), r.listeners.push(t)
    }, On.prototype.send = function(e, t) {
        var n = this;
        if (!n.id) throw new Error("Chat requires unique id to communicate between windows");
        var r = {
            source: "hcaptcha",
            label: e,
            id: n.id
        };
        if (t) {
            if ("object" != typeof t) throw new Error("Message must be an object.");
            r.contents = t
        }
        n._addToQueue(n.target, r)
    }, On.prototype.check = function(e, t) {
        for (var n = [].concat.apply([], [this.messages, this.incoming, this.waiting]), r = [], i = -1; ++i < n.length;)
            if (n[i].label === e) {
                if (t && n[i].lookup && t !== n[i].lookup) continue;
                r.push(n[i])
            }
        return r
    }, On.prototype.respond = function(e) {
        for (var t, n, r = -1, i = 0, o = [].concat.apply([], [this.messages, this.incoming, this.waiting]); ++r < o.length;)
            if (o[r].label === e.label) {
                if (e.lookup && o[r].lookup && e.lookup !== o[r].lookup) continue;
                var a = [];
                if (t = o[r], e.error && a.push(e.error), e.contents && a.push(e.contents), e.promise && "create" !== e.promise) {
                    t[e.promise].apply(t[e.promise], a);
                    for (var s = this.waiting.length, l = !1; --s > -1 && !1 === l;) this.waiting[s].label === t.label && this.waiting[s].lookup === t.lookup && (l = !0, this.waiting.splice(s, 1));
                    continue
                }
                for (i = 0; i < t.listeners.length; i++) {
                    if (n = t.listeners[i], "create" === e.promise) {
                        var c = this._contactPromise(t.label, e.lookup);
                        a.push(c)
                    }
                    try {
                        n.apply(n, a)
                    } catch (pr) {
                        De("chat-cb", pr)
                    }
                }
            }
        o = null
    }, On.prototype.destroy = function() {
        return this.clearQueue(), this.messages = null, this.incoming = null, this.waiting = null, this.isReady = !1, null
    }, On.prototype._contactPromise = function(e, t) {
        var n = this,
            r = {},
            i = new Promise((function(e, t) {
                r.resolve = e, r.reject = t
            })),
            o = {
                source: "hcaptcha",
                label: e,
                id: n.id,
                promise: null,
                lookup: t
            };
        return i.then((function(e) {
            o.promise = "resolve", null !== e && (o.contents = e), n._addToQueue(n.target, o)
        }))["catch"]((function(e) {
            o.promise = "reject", null !== e && (o.error = e), n._addToQueue(n.target, o)
        })), r
    }, On.prototype._addToQueue = function(e, t) {
        this.isReady ? this._sendMessage(e, t) : this.queue.push([e, t])
    };
    var jn = {
        chats: [],
        messages: [],
        globalEnabled: !1,
        isSupported: function() {
            return !!window.postMessage
        },
        createChat: function(e, t, n) {
            var r = new On(e, t, n);
            return jn.chats.push(r), r
        },
        addChat: function(e) {
            jn.chats.push(e)
        },
        removeChat: function(e) {
            for (var t = !1, n = jn.chats.length; --n > -1 && !1 === t;) e.id === jn.chats[n].id && e.target === jn.chats[n].target && (t = jn.chats[n], jn.chats.splice(n, 1));
            return t
        },
        consumeMessages: function() {
            var e = jn.messages;
            return jn.messages = [], e
        },
        handleGlobal: function(e) {
            if (jn.globalEnabled) {
                var t = jn.messages;
                if (t.length >= 10) jn.globalEnabled = !1;
                else {
                    var n = t.some((function(t) {
                        return JSON.stringify(t.data) === JSON.stringify(e.data)
                    }));
                    n || t.push(e)
                }
            }
        },
        handle: function(e) {
            var t = e.data,
                n = "string" == typeof t && t.indexOf("hcaptcha") >= 0 || "object" == typeof t && JSON.stringify(t).indexOf("hcaptcha") >= 0;
            try {
                if (!n) return void jn.handleGlobal(e);
                "string" == typeof t && (t = JSON.parse(t)), "d" === t.t && jn.messages.push(e);
                for (var r, i = jn.chats, o = -1; ++o < i.length;) {
                    var a = "*" === (r = i[o]).targetOrigin || e.origin === r.targetOrigin;
                    r.id === t.id && a && r.respond(t)
                }
            } catch (pr) {
                Ae("postMessage handler error", "postMessage", "debug", {
                    event: e,
                    error: pr
                })
            }
        }
    };

    function Cn(e) {
        var t = e ? Nn.getById(e) : Nn.getByIndex(0);
        if (!t) throw e ? new Un(e) : new xn;
        Nn.remove(t), t.destroy(), t = null
    }

    function Bn() {
        try {
            return Object.keys(window).sort().join(",")
        } catch (dr) {
            return null
        }
    }
    window.addEventListener ? window.addEventListener("message", jn.handle) : window.attachEvent("onmessage", jn.handle);
    var Dn = Je();

    function An(e, t) {
        for (var n in t) {
            var r = t[n];
            switch (typeof r) {
                case "string":
                    e[n] = r;
                    break;
                case "object":
                    e[n] = e[n] || {}, An(e[n], r);
                    break;
                default:
                    throw new Error("Source theme contains invalid data types. Only string and object types are supported.")
            }
        }
    }

    function Gn(e, t) {
        try {
            return e in t
        } catch (n) {
            return !1
        }
    }

    function Jn(e) {
        return !!e && "object" == typeof e
    }

    function zn(e) {
        return Jn(e) ? Xn({}, e) : e
    }

    function Xn(e, t) {
        var n, r = {},
            i = Object.keys(e);
        for (n = 0; n < i.length; n++) r[i[n]] = zn(e[i[n]]);
        var o, a, s = Object.keys(t);
        for (n = 0; n < s.length; n++) {
            var l = s[n];
            if (!(!Gn(o = l, a = e) || Object.hasOwnProperty.call(a, o) && Object.propertyIsEnumerable.call(a, o))) return;
            Gn(l, e) && Jn(e[l]) ? r[l] = Xn(e[l], t[l]) : r[l] = zn(t[l])
        }
        return r
    }
    var In = {
            transparent: "transparent",
            white: "#ffffff",
            black: "#000000",
            grey: "#707070"
        },
        Kn = {
            100: "#fafafa",
            200: "#f5f5f5",
            300: "#E0E0E0",
            400: "#D7D7D7",
            500: "#BFBFBF",
            600: "#919191",
            700: "#555555",
            800: "#333333",
            900: "#222222",
            1e3: "#14191F"
        },
        Yn = "#4DE1D2",
        Ln = "#00838F",
        Hn = {
            mode: "light",
            grey: Kn,
            primary: {
                main: Ln
            },
            secondary: {
                main: Yn
            },
            warn: {
                light: "#BF1722",
                main: "#BF1722",
                dark: "#9D1B1B"
            },
            text: {
                heading: Kn[800],
                body: Kn[800]
            }
        },
        Qn = {
            mode: "dark",
            grey: Kn,
            primary: {
                main: Ln
            },
            secondary: {
                main: Yn
            },
            text: {
                heading: Kn[200],
                body: Kn[200]
            }
        };

    function $n(e, t) {
        return "dark" === t && e in Qn ? Qn[e] : Hn[e]
    }

    function qn() {
        this._themes = Object.create(null), this._active = "light", this.add("light", {}), this.add("dark", {
            palette: {
                mode: "dark"
            }
        })
    }
    qn.prototype.get = function(e) {
        if (!e) return this._themes[this._active];
        var t = this._themes[e];
        if (!t) throw new Error("Cannot find theme with name: " + e);
        return t
    }, qn.prototype.use = function(e) {
        this._themes[e] ? this._active = e : console.error("Cannot find theme with name: " + e)
    }, qn.prototype.active = function() {
        return this._active
    }, qn.prototype.add = function(e, t) {
        t || (t = {}), t.palette = function(e) {
            e || (e = {});
            var t = e.mode || "light",
                n = e.primary || $n("primary", t),
                r = e.secondary || $n("secondary", t),
                i = e.warn || $n("warn", t),
                o = e.grey || $n("grey", t),
                a = e.text || $n("text", t);
            return Xn({
                common: In,
                mode: t,
                primary: n,
                secondary: r,
                grey: o,
                warn: i,
                text: a
            }, e)
        }(t.palette), t.component = t.component || Object.create(null), this._themes[e] = t
    }, qn.prototype.extend = function(e, t) {
        "string" == typeof t && (t = JSON.parse(t));
        var n = JSON.parse(JSON.stringify(this.get(e)));
        return An(n, t), n
    }, qn.merge = function(e, t) {
        return Xn(e, t || {})
    };
    var er = ["light", "dark", "contrast", "grey-red"],
        tr = new qn;
    tr.add("contrast", {}), tr.add("grey-red", {
        component: {
            challenge: {
                main: {
                    border: "#6a6a6a"
                }
            }
        }
    });

    function nr(e, t) {
        var n = this;
        this.challengeCreationSent = !1, this.id = e, this.width = null, this.height = null, this.mobile = !1, this.ready = !1, this.listeners = [], this.config = t, this._visible = !1, this._selected = !1, this.$iframe = new St("iframe"), this._host = Ve.host || window.location.hostname;
        var r = Ve.assetUrl;
        ve.assethost && (r = ve.assethost + Ve.assetUrl.replace(Ve.assetDomain, ""));
        var i = r.match(/^.+\:\/\/[^\/]+/),
            o = i ? i[0] : null,
            a = r + "/hcaptcha.html#frame=challenge&id=" + this.id + "&host=" + this._host + (t ? "&" + Qe(this.config) : ""),
            s = ve.isSecure && ee.Browser.supportsPST();
        this.setupParentContainer(t), this.chat = jn.createChat(this.$iframe.dom, e, o), this.chat.setReady(!1), this._timeoutFailedToInitialize = setTimeout((function() {
            n.$iframe && n.$iframe.isConnected() ? Be("Failed to initialize. Iframe attached", "error", "frame:challenge", {
                contentWindow: !!n.$iframe.dom.contentWindow,
                iframeSrc: a,
                supportsPST: s,
                customContainer: n._hasCustomContainer
            }) : Be("Failed to initialize. Iframe detached", "error", "frame:challenge")
        }), 6e4), this.$iframe.dom.src = a, this.$iframe.dom.frameBorder = 0, this.$iframe.dom.scrolling = "no", s && (this.$iframe.dom.allow = "private-state-token-redemption"), this.translate(), this._hasCustomContainer ? (this._hideIframe(), this._parent.appendChild(this.$iframe.dom)) : (this.$container = new St("div"), this.$wrapper = this.$container.createElement("div"), this.$overlay = this.$container.createElement("div"), this.$arrow = this.$container.createElement("div"), this.$arrow.fg = this.$arrow.createElement("div"), this.$arrow.bg = this.$arrow.createElement("div"), this.style.call(this), this.$wrapper.appendElement(this.$iframe), this._parent.appendChild(this.$container.dom), this.$container.setAttribute("aria-hidden", !0)), this.style()
    }
    nr.prototype.setupParentContainer = function(e) {
        var t, n = e["challenge-container"];
        n && (t = "string" == typeof n ? document.getElementById(n) : n), t ? (this._hasCustomContainer = !0, this._parent = t) : (this._hasCustomContainer = !1, this._parent = document.body)
    }, nr.prototype._hideIframe = function() {
        var e = {};
        "ie" !== ee.Browser.type || "ie" === ee.Browser.type && 8 !== ee.Browser.version ? (e.opacity = 0, e.visibility = "hidden") : e.display = "none", this.$iframe.setAttribute("aria-hidden", !0), this.$iframe.css(e)
    }, nr.prototype._showIframe = function() {
        var e = {};
        "ie" !== ee.Browser.type || "ie" === ee.Browser.type && 8 !== ee.Browser.version ? (e.opacity = 1, e.visibility = "visible") : e.display = "block", this.$iframe.removeAttribute("aria-hidden"), this.$iframe.css(e)
    }, nr.prototype.style = function() {
        var e = function(e) {
            var t = e.palette,
                n = e.component;
            return qn.merge({
                main: {
                    fill: t.common.white,
                    border: t.grey[400]
                }
            }, n.challenge)
        }(tr.get());
        if (this._hasCustomContainer) this.$iframe.css({
            border: 0,
            position: "relative",
            backgroundColor: e.main.fill
        });
        else {
            var t = {
                backgroundColor: e.main.fill,
                border: "1px solid " + e.main.border,
                boxShadow: "rgba(0, 0, 0, 0.1) 0px 0px 4px",
                borderRadius: 4,
                left: "auto",
                top: -1e4,
                zIndex: -9999999999999,
                position: "absolute",
                pointerEvents: "auto"
            };
            "ie" !== ee.Browser.type || "ie" === ee.Browser.type && 8 !== ee.Browser.version ? (t.transition = "opacity 0.15s ease-out", t.opacity = 0, t.visibility = "hidden") : t.display = "none", this.$container.css(t), this.$wrapper.css({
                position: "relative",
                zIndex: 1
            }), this.$overlay.css({
                width: "100%",
                height: "100%",
                position: "fixed",
                pointerEvents: "none",
                top: 0,
                left: 0,
                zIndex: 0,
                backgroundColor: e.main.fill,
                opacity: .05
            }), this.$arrow.css({
                borderWidth: 11,
                borderStyle: "none",
                position: "absolute",
                pointerEvents: "none",
                marginTop: -11,
                zIndex: 1,
                right: "100%"
            }), this.$arrow.fg.css({
                borderWidth: 10,
                borderStyle: "solid",
                borderColor: "transparent rgb(255, 255, 255) transparent transparent",
                position: "relative",
                top: 10,
                zIndex: 1
            }), this.$arrow.bg.css({
                borderWidth: 11,
                borderStyle: "solid",
                borderColor: "transparent " + e.main.border + " transparent transparent",
                position: "relative",
                top: -11,
                zIndex: 0
            }), this.$iframe.css({
                border: 0,
                zIndex: 2e9,
                position: "relative"
            })
        }
    }, nr.prototype.setup = function(e) {
        this.chat.send("create-challenge", e), this.challengeCreationSent = !0
    }, nr.prototype.sendTranslation = function(e) {
        var t = {
            locale: e,
            table: Pt.getTable(e) || {}
        };
        this.chat && this.chat.send("challenge-translate", t), this.translate()
    }, nr.prototype.translate = function() {
        this.$iframe.dom.title = Pt.translate("hCaptcha challenge")
    }, nr.prototype.isVisible = function() {
        return this._visible
    }, nr.prototype.getDimensions = function(e, t) {
        return this._visible ? this.chat.contact("resize-challenge", {
            width: e,
            height: t
        }) : Promise.resolve(null)
    }, nr.prototype.show = function() {
        if (!0 !== this._visible)
            if (this._visible = !0, this._hasCustomContainer) this._showIframe();
            else {
                var e = {
                    zIndex: 9999999999999,
                    display: "block"
                };
                ("ie" !== ee.Browser.type || "ie" === ee.Browser.type && 8 !== ee.Browser.version) && (e.opacity = 1, e.visibility = "visible"), this.$container.css(e), this.$container.removeAttribute("aria-hidden"), this.$overlay.css({
                    pointerEvents: "auto",
                    cursor: "pointer"
                })
            }
    }, nr.prototype.focus = function() {
        this.$iframe.dom.focus()
    }, nr.prototype.close = function(e) {
        if (!1 !== this._visible) {
            if (this._visible = !1, this._hasCustomContainer) return this._hideIframe(), void this.chat.send("close-challenge", {
                event: e
            });
            var t = {
                left: "auto",
                top: -1e4,
                zIndex: -9999999999999
            };
            "ie" !== ee.Browser.type || "ie" === ee.Browser.type && 8 !== ee.Browser.version ? (t.opacity = 0, t.visibility = "hidden") : t.display = "none", this.$container.css(t), this._hasCustomContainer || this.$overlay.css({
                pointerEvents: "none",
                cursor: "default"
            }), this.chat.send("close-challenge", {
                event: e
            }), this.$container.setAttribute("aria-hidden", !0)
        }
    }, nr.prototype.size = function(e, t, n) {
        this.width = e, this.height = t, this.mobile = n, this.$iframe.css({
            width: e,
            height: t
        }), this._hasCustomContainer || (this.$wrapper.css({
            width: e,
            height: t
        }), n ? this.$overlay.css({
            opacity: .5
        }) : this.$overlay.css({
            opacity: .05
        }))
    }, nr.prototype.position = function(e) {
        if (!this._hasCustomContainer && e) {
            var t = 10,
                n = window.document.documentElement,
                r = ee.Browser.scrollY(),
                i = ee.Browser.width(),
                o = ee.Browser.height(),
                a = this.mobile || "invisible" === this.config.size || e.offset.left + e.tick.x <= e.tick.width / 2,
                s = Math.round(e.bounding.top) + r !== e.offset.top,
                l = a ? (i - this.width) / 2 : e.bounding.left + e.tick.right + 10;
            (l + this.width + t > i || l < 0) && (l = (i - this.width) / 2, a = !0);
            var c = (n.scrollHeight < n.clientHeight ? n.clientHeight : n.scrollHeight) - this.height - t,
                u = a ? (o - this.height) / 2 + r : e.bounding.top + e.tick.y + r - this.height / 2;
            s && u < r && (u = r + t), s && u + this.height >= r + o && (u = r + o - (this.height + t)), u = Math.max(Math.min(u, c), 10);
            var h = e.bounding.top + e.tick.y + r - u - 10,
                p = this.height - 10 - 30;
            h = Math.max(Math.min(h, p), t), this.$container.css({
                left: l,
                top: u
            }), this.$arrow.fg.css({
                display: a ? "none" : "block"
            }), this.$arrow.bg.css({
                display: a ? "none" : "block"
            }), this.$arrow.css({
                top: h
            }), this.top = u, this.$container.dom.getBoundingClientRect()
        }
    }, nr.prototype.destroy = function() {
        this._timeoutFailedToInitialize && (clearTimeout(this._timeoutFailedToInitialize), this._timeoutFailedToInitialize = null), this._visible && this.close.call(this), jn.removeChat(this.chat), this.chat = this.chat.destroy(), this._hasCustomContainer ? this._parent.removeChild(this.$iframe.dom) : (this._parent.removeChild(this.$container.dom), this.$container = this.$container.__destroy()), this.$iframe = this.$iframe.__destroy()
    }, nr.prototype.setReady = function() {
        var e;
        this._timeoutFailedToInitialize && (clearTimeout(this._timeoutFailedToInitialize), this._timeoutFailedToInitialize = null), this.chat && this.chat.setReady(!0), this.ready = !0;
        for (var t = this.listeners.length; --t > -1;) e = this.listeners[t], this.listeners.splice(t, 1), e()
    }, nr.prototype.onReady = function(e) {
        var t = Array.prototype.slice.call(arguments, 1),
            n = function() {
                e.apply(null, t)
            };
        this.ready ? n() : this.listeners.push(n)
    }, nr.prototype.onOverlayClick = function(e) {
        this._hasCustomContainer || this.$overlay.addEventListener("click", e)
    }, nr.prototype.setData = function(e) {
        this.chat && this.chat.send("challenge-data", e)
    }, nr.prototype.resetData = function() {
        this.chat && this.chat.send("reset-challenge-data")
    };

    function rr(e, t, n) {
        var r = this;
        this.id = t, this.response = null, this.location = {
            tick: null,
            offset: null,
            bounding: null
        }, this.config = n, this._ticked = !0, this.$container = e instanceof St ? e : new St(e), this._host = Ve.host || window.location.hostname, this.$iframe = new St("iframe");
        var i = Ve.assetUrl;
        ve.assethost && (i = ve.assethost + Ve.assetUrl.replace(Ve.assetDomain, ""));
        var o = i.match(/^.+\:\/\/[^\/]+/),
            a = o ? o[0] : null,
            s = i + "/hcaptcha.html#frame=checkbox&id=" + this.id + "&host=" + this._host + (n ? "&" + Qe(this.config) : "");
        this.chat = jn.createChat(this.$iframe.dom, t, a), this.chat.setReady(!1), this._timeoutFailedToInitialize = setTimeout((function() {
            r.$iframe && r.$iframe.isConnected() ? Be("Failed to initialize. Iframe attached", "error", "frame:checkbox", {
                contentWindow: !!r.$iframe.dom.contentWindow,
                iframeSrc: s
            }) : Be("Failed to initialize. Iframe detached", "error", "frame:checkbox")
        }), 6e4), this.$iframe.dom.src = s, this.$iframe.dom.tabIndex = this.config.tabindex || 0, this.$iframe.dom.frameBorder = "0", this.$iframe.dom.scrolling = "no", ve.isSecure && ee.Browser.supportsPST() && (this.$iframe.dom.allow = "private-state-token-redemption"), this.translate(), this.config.size && "invisible" === this.config.size && this.$iframe.setAttribute("aria-hidden", "true"), this.$iframe.setAttribute("data-hcaptcha-widget-id", t), this.$iframe.setAttribute("data-hcaptcha-response", ""), this.$container.appendElement(this.$iframe), "off" !== ve.recaptchacompat && (this.$textArea0 = this.$container.createElement("textarea", "#g-recaptcha-response-" + t), this.$textArea0.dom.name = "g-recaptcha-response", this.$textArea0.css({
            display: "none"
        })), this.$textArea1 = this.$container.createElement("textarea", "#h-captcha-response-" + t), this.$textArea1.dom.name = "h-captcha-response", this.$textArea1.css({
            display: "none"
        }), this.ready = new Promise((function(e) {
            r.chat.listen("checkbox-ready", e)
        })).then((function() {
            r._timeoutFailedToInitialize && (clearTimeout(r._timeoutFailedToInitialize), r._timeoutFailedToInitialize = null), r.chat && r.chat.setReady(!0)
        })), this.clearLoading = this.clearLoading.bind(this), this.style()
    }

    function ir(e, t, n) {
        this.id = t, this.response = null, this.location = {
            tick: null,
            offset: null,
            bounding: null
        }, this.config = n, this.$container = e instanceof St ? e : new St(e), this.$iframe = new St("iframe"), this.$iframe.setAttribute("aria-hidden", "true"), this.$iframe.css({
            display: "none"
        }), this.$iframe.setAttribute("data-hcaptcha-widget-id", t), this.$iframe.setAttribute("data-hcaptcha-response", "");
        var r = Ve.assetUrl;
        ve.assethost && (r = ve.assethost + Ve.assetUrl.replace(Ve.assetDomain, "")), this.$iframe.dom.src = r + "/hcaptcha.html#frame=checkbox-invisible", this.$container.appendElement(this.$iframe), "off" !== ve.recaptchacompat && (this.$textArea0 = this.$container.createElement("textarea", "#g-recaptcha-response-" + t), this.$textArea0.dom.name = "g-recaptcha-response", this.$textArea0.css({
            display: "none"
        })), this.$textArea1 = this.$container.createElement("textarea", "#h-captcha-response-" + t), this.$textArea1.dom.name = "h-captcha-response", this.$textArea1.css({
            display: "none"
        })
    }

    function or(e, t, n) {
        if (!n.sitekey) throw new Wn;
        this.id = t, this.visible = !1, this.overflow = {
            override: !1,
            cssUsed: !0,
            value: null,
            scroll: 0
        }, this.onError = null, this.onPass = null, this.onExpire = null, this.onChalExpire = null, this.onOpen = null, this.onClose = null, this._ready = !1, this._active = !1, this._listeners = [], this.config = n, er.indexOf(n.theme) >= 0 && tr.use(n.theme), this._state = {
            escaped: !1,
            passed: !1,
            expiredChallenge: !1,
            expiredResponse: !1
        }, this._origData = null, this._langSet = !1, this._promise = null, this._responseTimer = null, this.initChallenge = this.initChallenge.bind(this), this.closeChallenge = this.closeChallenge.bind(this), this.displayChallenge = this.displayChallenge.bind(this), this.getGetCaptchaManifest = this.getGetCaptchaManifest.bind(this), this.challenge = new nr(t, n), "invisible" === this.config.size ? (Ae("Invisible mode is set", "hCaptcha", "info"), this.checkbox = new ir(e, t, n)) : this.checkbox = new rr(e, t, n)
    }

    function ar(e) {
        if ("en" === e) return Promise.resolve();
        var t = e + ".json";
        return new Promise((function(n, r) {
            qt(t).then((function(n) {
                return n || $t(t, {
                    prefix: "https://newassets.hcaptcha.com/captcha/v1/5ea3feff9cf1292d7051510930d98c4719f64575/static/i18n"
                }).then((function(t) {
                    return Pt.addTable(e, t.data), t
                }))
            })).then((function(e) {
                n(e.data)
            }))["catch"]((function(e) {
                r(e)
            }))
        }))
    }
    rr.prototype.setResponse = function(e) {
        this.response = e, this.$iframe.dom.setAttribute("data-hcaptcha-response", e), "off" !== ve.recaptchacompat && (this.$textArea0.dom.value = e), this.$textArea1.dom.value = e
    }, rr.prototype.style = function() {
        var e = this.config.size;
        switch (this.$iframe.css({
            pointerEvents: "auto",
            backgroundColor: "rgba(255,255,255,0)",
            borderRadius: 4
        }), e) {
            case "compact":
                this.$iframe.css({
                    width: 158,
                    height: 138
                });
                break;
            case "invisible":
                this.$iframe.css({
                    display: "none"
                });
                break;
            default:
                this.$iframe.css({
                    width: 302,
                    height: 76,
                    overflow: "hidden"
                })
        }
    }, rr.prototype.reset = function() {
        this._ticked = !1, this.$iframe && this.$iframe.dom.contentWindow && this.chat && this.chat.send("checkbox-reset")
    }, rr.prototype.clearLoading = function() {
        this.chat && this.chat.send("checkbox-clear")
    }, rr.prototype.sendTranslation = function(e) {
        var t = {
            locale: e,
            table: Pt.getTable(e) || {}
        };
        this.chat && this.chat.send("checkbox-translate", t), this.translate()
    }, rr.prototype.translate = function() {
        this.$iframe.dom.title = Pt.translate("Widget containing checkbox for hCaptcha security challenge")
    }, rr.prototype.status = function(e, t) {
        this.$iframe && this.$iframe.dom.contentWindow && this.chat && this.chat.send("checkbox-status", {
            text: e || null,
            a11yOnly: t || !1
        })
    }, rr.prototype.tick = function() {
        this._ticked = !0, this.chat && this.chat.send("checkbox-tick")
    }, rr.prototype.getTickLocation = function() {
        return this.chat.contact("checkbox-location")
    }, rr.prototype.getOffset = function() {
        var e = this.$iframe.dom;
        e.offsetParent || (e = e.parentElement);
        for (var t = 0, n = 0; e;) t += e.offsetLeft, n += e.offsetTop, e = e.offsetParent;
        return {
            top: n,
            left: t
        }
    }, rr.prototype.getBounding = function() {
        return this.$iframe.dom.getBoundingClientRect()
    }, rr.prototype.destroy = function() {
        this._timeoutFailedToInitialize && (clearTimeout(this._timeoutFailedToInitialize), this._timeoutFailedToInitialize = null), this._ticked && this.reset(), jn.removeChat(this.chat), this.chat = this.chat.destroy(), this.$container.removeElement(this.$iframe), this.$container.removeElement(this.$textArea1), "off" !== ve.recaptchacompat && (this.$container.removeElement(this.$textArea0), this.$textArea0 = this.$textArea0.__destroy()), this.$textArea1 = this.$textArea1.__destroy(), this.$container = this.$container.__destroy(), this.$iframe = this.$iframe.__destroy()
    }, ir.prototype.setResponse = function(e) {
        this.response = e, this.$iframe.dom.setAttribute("data-hcaptcha-response", e), "off" !== ve.recaptchacompat && (this.$textArea0.dom.value = e), this.$textArea1.dom.value = e
    }, ir.prototype.reset = function() {}, ir.prototype.clearLoading = function() {}, ir.prototype.sendTranslation = function(e) {}, ir.prototype.status = function(e, t) {}, ir.prototype.tick = function() {}, ir.prototype.getTickLocation = function() {
        return Promise.resolve({
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            width: 0,
            height: 0,
            x: 0,
            y: 0
        })
    }, ir.prototype.getOffset = function() {
        var e = this.$iframe.dom;
        e.offsetParent || (e = e.parentElement);
        for (var t = 0, n = 0; e;) t += e.offsetLeft, n += e.offsetTop, e = e.offsetParent;
        return {
            top: n,
            left: t
        }
    }, ir.prototype.getBounding = function() {
        return this.$iframe.dom.getBoundingClientRect()
    }, ir.prototype.destroy = function() {
        this._ticked && this.reset(), this.$container.removeElement(this.$iframe), this.$container.removeElement(this.$textArea1), "off" !== ve.recaptchacompat && (this.$container.removeElement(this.$textArea0), this.$textArea0 = this.$textArea0.__destroy()), this.$textArea1 = this.$textArea1.__destroy(), this.$container = this.$container.__destroy(), this.$iframe = this.$iframe.__destroy()
    }, or.prototype._resetTimer = function() {
        null !== this._responseTimer && (clearTimeout(this._responseTimer), this._responseTimer = null)
    }, or.prototype.initChallenge = function(e) {
        var t = this;
        e || (e = {}), Ae("Initiate challenge", "hCaptcha", "info"), t._origData = e;
        var n = this.getGetCaptchaManifest(),
            r = e.charity || null,
            i = e.a11yChallenge || !1,
            o = e.link || null,
            a = e.action || "",
            s = e.rqdata || null,
            l = e.errors || [],
            c = e.mfa_phone || null,
            u = e.mfa_phoneprefix || null,
            h = ee.Browser.width(),
            p = ee.Browser.height();
        this._active = !0, this._resetTimer(), this._resetState(), this.checkbox.setResponse("");
        var d = {
            a11yChallenge: i,
            manifest: n,
            width: h,
            height: p,
            charity: r,
            link: o,
            action: a,
            rqdata: s,
            mfa_phone: c,
            mfa_phoneprefix: u,
            wdata: Bn(),
            errors: l.concat(Dn.collect())
        };
        try {
            var f = this.visible || "invisible" !== this.config.size,
                m = wn(t.id, f, !0, this.config.sitekey);
            if (null == m) return void t.challenge.setup(d);
            ot(m, 100).then((function(e) {
                d.vmdata = e
            }))["catch"]((function(e) {
                De("submitvm", e)
            }))["finally"]((function() {
                t.challenge.setup(d)
            }))
        } catch (pr) {
            t.challenge.setup(d), Be("SubmitVM Failed", "error", "execute", pr)
        }
    }, or.prototype.getGetCaptchaManifest = function() {
        var e = (this._origData || {}).manifest || null;
        e || ((e = Object.create(null)).st = Date.now()), e.v = 1, e.session = Nn.getSession(), e.widgetList = Nn.getCaptchaIdList(), e.widgetId = this.id;
        try {
            e.topLevel = En.getData()
        } catch (pr) {
            Be("challenge:get-manifest-error", "error", "challenge", {
                error: pr
            })
        }
        return e.href = window.location.href, e.prev = JSON.parse(JSON.stringify(this._state)), e
    }, or.prototype.displayChallenge = function(e) {
        if (this._active) {
            var t = this;
            this.visible = !0;
            var n = this.checkbox,
                r = this.challenge,
                i = ee.Browser.height();
            if (!("ie" === ee.Browser.type && 8 === ee.Browser.version)) {
                var o = window.getComputedStyle(document.body).getPropertyValue("overflow-y");
                this.overflow.override = "hidden" === o, this.overflow.override && (this.overflow.cssUsed = "" === document.body.style.overflow && "" === document.body.style.overflowY, this.overflow.cssUsed || (this.overflow.value = "" === o ? "auto" : o), this.overflow.scroll = ee.Browser.scrollY(), document.body.style.overflowY = "auto")
            }
            return new Promise((function(o) {
                n.status(), n.getTickLocation().then((function(a) {
                    if (t._active) {
                        if (r.size(e.width, e.height, e.mobile), r.show(), n.clearLoading(), n.location.bounding = n.getBounding(), n.location.tick = a, n.location.offset = n.getOffset(), r.position(n.location), r.focus(), r.height > window.document.documentElement.clientHeight)(window.document.scrollingElement || document.getElementsByTagName("html")[0]).scrollTop = Math.abs(r.height - i) + r.top;
                        o()
                    }
                }))
            })).then((function() {
                Ae("Challenge is displayed", "hCaptcha", "info"), t.onOpen && ht(t.onOpen)
            }))
        }
    }, or.prototype.resize = function(e, t, n) {
        var r = this,
            i = this.checkbox,
            o = this.challenge;
        o.getDimensions(e, t).then((function(e) {
            e && o.size(e.width, e.height, e.mobile), i.location.bounding = i.getBounding(), i.location.offset = i.getOffset(), ee.System.mobile && !n || o.position(i.location)
        }))["catch"]((function(e) {
            r.closeChallenge.call(r, {
                event: ue,
                message: "Captcha resize caused error.",
                error: e
            })
        }))
    }, or.prototype.position = function() {
        var e = this.checkbox,
            t = this.challenge;
        ee.System.mobile || (e.location.bounding = e.getBounding(), t.position(e.location))
    }, or.prototype.reset = function() {
        Ae("Captcha Reset", "hCaptcha", "info");
        try {
            this.checkbox.reset(), this.checkbox.setResponse(""), this.challenge.resetData(), this._resetTimer(), this._resetState()
        } catch (mr) {
            De("hCaptcha", mr)
        }
    }, or.prototype._resetState = function() {
        for (var e in this._state) this._state[e] = !1
    }, or.prototype.closeChallenge = function(e) {
        this.visible = !1, this._active = !1;
        var t = this,
            n = this.checkbox,
            r = this.challenge;
        this.overflow.override && ((window.document.scrollingElement || document.getElementsByTagName("html")[0]).scrollTop = this.overflow.scroll, this.overflow.override = !1, this.overflow.scroll = 0, document.body.style.overflowY = this.overflow.cssUsed ? null : this.overflow.value);
        var i = e.response || "";
        n.setResponse(i);
        var o = e.event;
        switch ("string" == typeof i && "" !== i || o !== te || (o = ne, Be("Passed without response", "error", "api", e)), r.close(o), n.$iframe.dom.focus(), Ae("Challenge has closed", "hCaptcha", "info", {
            event: o,
            response: e.response,
            message: e.message
        }), o) {
            case ne:
                this._state.escaped = !0, n.reset(), t.onClose && ht(t.onClose), t._promise && t._promise.reject(re);
                break;
            case ie:
                this._state.expiredChallenge = !0, n.reset(), n.status("hCaptcha window closed due to timeout.", !0), t.onChalExpire && ht(t.onChalExpire), t._promise && t._promise.reject(ie);
                break;
            case ae:
                n.reset(), this.onError && ht(this.onError, ae), t._promise && t._promise.reject(ae);
                break;
            case ue:
            case se:
            case ce:
                var a = o;
                n.reset(), o === ce ? (n.status(e.message), 429 === e.status ? a = le : "invalid-data" === e.message ? a = oe : "client-fail" === e.message && (a = ue)) : o === se ? a = ue : o === ue && "Answers are incomplete" === e.message && (a = he), Be("api:challenge-failed-" + a, "error", "hCaptcha", {
                    error: a,
                    event: o,
                    message: e.message
                }), this.onError && ht(this.onError, a), t._promise && t._promise.reject(a);
                break;
            case te:
                this._state.passed = !0, n.tick(), this.onPass && ht(this.onPass, i), t._promise && t._promise.resolve({
                    response: i,
                    key: Zn(this.id)
                }), "number" == typeof e.expiration && (t._resetTimer(), t._responseTimer = setTimeout((function() {
                    try {
                        n.$iframe && (n.$iframe.dom.contentWindow ? (n.reset(), n.setResponse(""), n.status("hCaptcha security token has expired. Please complete the challenge again.", !0)) : Cn(t.id))
                    } catch (pr) {
                        De("global", pr)
                    }
                    t.onExpire && ht(t.onExpire), t._responseTimer = null, t._state.expiredResponse = !0
                }), 1e3 * e.expiration))
        }
        t._promise = null
    }, or.prototype.updateTranslation = function(e) {
        this.config.hl = e, this._langSet = !0, this.checkbox && this.checkbox.sendTranslation(e), this.challenge && this.challenge.sendTranslation(e)
    }, or.prototype.isLangSet = function() {
        return this._langSet
    }, or.prototype.isReady = function() {
        return this._ready
    }, or.prototype.isActive = function() {
        return this._active
    }, or.prototype.setReady = function(e) {
        if (this._ready = e, this._ready) {
            var t;
            Ae("Instance is ready", "hCaptcha", "info");
            for (var n = this._listeners.length; --n > -1;) t = this._listeners[n], this._listeners.splice(n, 1), t()
        }
    }, or.prototype.setPromise = function(e) {
        this._promise = e
    }, or.prototype.onReady = function(e) {
        var t = Array.prototype.slice.call(arguments, 1),
            n = function() {
                e.apply(null, t)
            };
        this._ready ? n() : this._listeners.push(n)
    }, or.prototype.destroy = function() {
        (Ae("Captcha Destroy", "hCaptcha", "info"), this._resetTimer(), this.overflow.override) && ((window.document.scrollingElement || document.getElementsByTagName("html")[0]).scrollTop = this.overflow.scroll, this.overflow.override = !1, this.overflow.scroll = 0, document.body.style.overflowY = this.overflow.cssUsed ? null : this.overflow.value);
        this.challenge.destroy(), this.checkbox.destroy(), this.challenge = null, this.checkbox = null
    }, or.prototype.setSiteConfig = function(e) {
        var t = this;
        if ("ok" in e) {
            var n = e.ok.features || {};
            if (this.config.themeConfig && n.custom_theme) {
                var r = "custom-" + this.id;
                tr.add(r, tr.extend(tr.active(), this.config.themeConfig)), tr.use(r), this.challenge.style()
            }
        }
        return "invisible" === this.config.size ? ("err" in e && console.error("[hCaptcha] " + e.err.message), Promise.resolve()) : this.checkbox.ready.then((function() {
            return t.checkbox.chat.send("site-setup", e), new Promise((function(e) {
                t.checkbox.chat.listen("checkbox-loaded", (function() {
                    e()
                }))
            }))
        }))
    };
    var sr = 0,
        lr = ["hl", "custom", "andint", "tplinks", "sitekey", "theme", "size", "tabindex", "challenge-container", "confirm-nav", "orientation", "mode"];

    function cr(e, t) {
        if (e) try {
            e.updateTranslation(t)
        } catch (pr) {
            De("translation", pr)
        }
    }
    var ur, hr = {
        render: (ur = function(e, t) {
            if ("string" == typeof e && (e = document.getElementById(e)), e && "object" == typeof e && 1 === e.nodeType && "string" == typeof e.tagName)
                if (function(e) {
                        if (!e || !("challenge-container" in e)) return !0;
                        var t = e["challenge-container"];
                        return "string" == typeof t && (t = document.getElementById(t)), !!t && 1 === t.nodeType
                    }(t)) {
                    if (!1 !== jn.isSupported()) {
                        for (var n, r, i = e.getElementsByTagName("iframe"), o = -1; ++o < i.length && !n;)(r = i[o].getAttribute("data-hcaptcha-widget-id")) && (n = !0);
                        if (n) return console.error("Only one captcha is permitted per parent container."), r;
                        Ae("Render instance", "hCaptcha", "info");
                        var a = pt(e, t),
                            s = sr++ + Math.random().toString(36).substr(2),
                            l = Object.create(null);
                        l.sentry = ve.sentry, l.reportapi = ve.reportapi, l.recaptchacompat = ve.recaptchacompat, l.custom = ve.custom, null !== ve.language && (l.hl = Pt.getLocale()), ve.assethost && (l.assethost = ve.assethost), ve.imghost && (l.imghost = ve.imghost), ve.tplinks && (l.tplinks = ve.tplinks), ve.andint && (l.andint = ve.andint), ve.se && (l.se = ve.se), "off" === ve.pat && (l.pat = ve.pat), l.pstissuer = ve.pstIssuer, "landscape" === ve.orientation && (l.orientation = ve.orientation);
                        for (var c = 0; c < lr.length; c++) {
                            var u = lr[c];
                            u in a && (l[u] = a[u])
                        }
                        var h = ve.endpoint,
                            p = l.sitekey;
                        "78c843a4-f80d-4a14-b3e5-74b492762487" === p && (h = ge);
                        try {
                            if (Sn(p)) try {
                                Rn.stop(), bn.stop()
                            } catch (pr) {
                                De("bivm", pr)
                            }
                        } catch (pr) {
                            De("vm", pr)
                        }
                        h === me && -1 === ["pt-BR", "es-BR"].indexOf(navigator.language) && Math.random() < .001 && p && -1 === p.indexOf("-0000-0000-0000-") && (h = ge), h !== me && (l.endpoint = h), l.theme = ve.theme;
                        var d = window.location,
                            f = d.origin || d.protocol + "//" + d.hostname + (d.port ? ":" + d.port : "");
                        if ("null" !== f && (l.origin = f), a.theme) try {
                            var m = a.theme;
                            "string" == typeof m && (m = JSON.parse(m)), l.themeConfig = m, l.custom = !0
                        } catch (dr) {
                            l.theme = m
                        }
                        if (e instanceof HTMLButtonElement || e instanceof HTMLInputElement) {
                            var g = new St("div", ".h-captcha");
                            g.css({
                                display: "none"
                            });
                            for (var y = null, V = 0; V < e.attributes.length; V++)(y = e.attributes[V]).name.startsWith("data-") && g.setAttribute(y.name, y.value);
                            var v = e.tagName.toLowerCase() + "[data-hcaptcha-widget-id='" + s + "']";
                            e.setAttribute("data-hcaptcha-widget-id", s), g.setAttribute("data-hcaptcha-source-id", v), e.parentNode.insertBefore(g.dom, e), e.onclick = function(e) {
                                return e.preventDefault(), Ae("User initiated", "hCaptcha", "info", e), Pn(s)
                            }, e = g, l.size = "invisible"
                        }
                        l.mode === ye && "invisible" === l.size && (console.warn("[hCaptcha] mode='auto' cannot be used in combination with size='invisible'."), delete l.mode);
                        try {
                            var b = new or(e, s, l)
                        } catch (pr) {
                            De("api", pr);
                            var R = "Your browser plugins or privacy policies are blocking the hCaptcha service. Please disable them for hCaptcha.com";
                            return pr instanceof Wn && (R = "hCaptcha has failed to initialize. Please see the developer tools console for more information.", console.error(pr.message)), void Te(e, R)
                        }
                        a.callback && (b.onPass = a.callback), a["expired-callback"] && (b.onExpire = a["expired-callback"]), a["chalexpired-callback"] && (b.onChalExpire = a["chalexpired-callback"]), a["open-callback"] && (b.onOpen = a["open-callback"]), a["close-callback"] && (b.onClose = a["close-callback"]), a["error-callback"] && (b.onError = a["error-callback"]);
                        try {
                            En.setData("inv", "invisible" === l.size), En.setData("size", l.size), En.setData("theme", mt(l.themeConfig || l.theme)), En.setData("pel", (e.outerHTML || "").replace(e.innerHTML, "")), Sn(b.config.sitekey) || (bn.setData("inv", "invisible" === l.size), bn.setData("size", l.size), bn.setData("theme", mt(l.themeConfig || l.theme)), bn.setData("pel", (e.outerHTML || "").replace(e.innerHTML, "")))
                        } catch (mr) {
                            De("api", mr)
                        }
                        return function(e, t) {
                                "invisible" !== t.size && (e.checkbox.chat.listen("checkbox-selected", (function(t) {
                                    Ae("User initiated", "hCaptcha", "info");
                                    try {
                                        var n = "enter" === t.action ? "kb" : "m";
                                        try {
                                            En.setData("exec", n), Sn(e.config.sitekey) || bn.setData("exec", n)
                                        } catch (pr) {
                                            De("msetdata", pr)
                                        }
                                        try {
                                            e.onReady(e.initChallenge, t)
                                        } catch (pr) {
                                            De("onready", pr)
                                        }
                                    } catch (pr) {
                                        Be("Checkbox Select Failed", "error", "render", pr)
                                    }
                                })), e.checkbox.chat.listen("checkbox-loaded", (function(n) {
                                    Ae("Loaded", "frame:checkbox", "info"), e.checkbox.location.bounding = e.checkbox.getBounding(), e.checkbox.location.tick = n, e.checkbox.location.offset = e.checkbox.getOffset(), e.checkbox.sendTranslation(t.hl)
                                })), t.mode === ye && e.onReady((function() {
                                    Pn(e.id)
                                }), t))
                            }(b, l),
                            function(e, t) {
                                function n(t, n) {
                                    if (t.locale) {
                                        var r = Pt.resolveLocale(t.locale);
                                        ar(r).then((function() {
                                            n ? cr(e, r) : (Pt.setLocale(r), Nn.each((function(e) {
                                                cr(e, r)
                                            })))
                                        }))["catch"]((function(e) {
                                            Be("lang:loading-error", "error", "api", {
                                                locale: r,
                                                error: e
                                            })
                                        }))
                                    }
                                }
                                e.challenge.chat.listen("site-setup", (function(t) {
                                    var n = e.setSiteConfig(t);
                                    e.challenge.onReady((function() {
                                        n.then((function() {
                                            e.setReady(!0)
                                        }))
                                    }))
                                })), e.challenge.chat.listen("challenge-loaded", (function() {
                                    Ae("Loaded", "frame:challenge", "info"), e.challenge.setReady(), e.challenge.sendTranslation(t.hl)
                                })), e.challenge.chat.answer("challenge-ready", (function(t, n) {
                                    if (e && e.isActive()) try {
                                        e.displayChallenge(t).then(n.resolve)["catch"]((function(e) {
                                            De("display-challenge", e), n.reject(e)
                                        }))
                                    } catch (pr) {
                                        De("challenge-ready", pr), n.reject(pr)
                                    } else e.isActive() ? Ae("hCaptcha instance no longer exists.", "frame:challenge", "info") : Ae("hCaptcha instance was stopped during execution flow.", "frame:challenge", "info")
                                })), e.challenge.chat.listen("challenge-resize", (function() {
                                    var t = ee.Browser.width(),
                                        n = ee.Browser.height();
                                    e.resize(t, n)
                                })), e.challenge.chat.listen(re, (function(t) {
                                    try {
                                        En.setData("lpt", Date.now()), Sn(e.config.sitekey) || bn.setData("lpt", Date.now())
                                    } catch (pr) {
                                        De("challenge-closed-vm", pr)
                                    }
                                    try {
                                        e.closeChallenge(t)
                                    } catch (pr) {
                                        De("challenge-closed", pr)
                                    }
                                })), e.challenge.chat.answer("get-url", (function(e) {
                                    try {
                                        e.resolve(window.location.href)
                                    } catch (pr) {
                                        De("get-url", pr), e.reject(pr)
                                    }
                                })), e.challenge.chat.answer("getcaptcha-manifest", (function(t) {
                                    try {
                                        var n = e.getGetCaptchaManifest(),
                                            r = e.visible || "invisible" !== e.config.size;
                                        try {
                                            var i = wn(e.id, r, e.config.sitekey);
                                            if (null == i) return void t.resolve(n);
                                            ot(i, 100).then((function(e) {
                                                n.vmdata = e
                                            }))["catch"]((function(e) {
                                                De("submitvm", e)
                                            }))["finally"]((function() {
                                                t.resolve(n)
                                            }))
                                        } catch (pr) {
                                            De("svm", pr), t.resolve(n)
                                        }
                                    } catch (pr) {
                                        De("getcaptcha-manifest", pr), t.reject(pr)
                                    }
                                })), e.challenge.chat.answer("check-api", (function(t) {
                                    try {
                                        var n = e.visible || "invisible" !== e.config.size,
                                            r = {
                                                motiondata: En.getData()
                                            };
                                        try {
                                            var i = wn(e.id, n, !n, e.config.sitekey);
                                            if (null == i) return void t.resolve(r);
                                            ot(i, 100).then((function(e) {
                                                r.vmdata = e
                                            }))["catch"]((function(e) {
                                                De("submitvm", e)
                                            }))["finally"]((function() {
                                                try {
                                                    t.resolve(r)
                                                } catch (pr) {
                                                    t.reject(pr)
                                                }
                                            }))
                                        } catch (pr) {
                                            De("svm", pr), t.resolve(r)
                                        }
                                    } catch (pr) {
                                        Be("check api error", "error", "render", pr), t.reject(pr)
                                    }
                                })), e.challenge.chat.listen("challenge-key", (function(t) {
                                    Nn.pushSession(t.key, e.id)
                                })), e.challenge.onOverlayClick((function() {
                                    e.closeChallenge({
                                        event: ne
                                    })
                                })), e.challenge.chat.listen("challenge-language", n), n({
                                    locale: t.hl
                                }, !0), e.challenge.chat.answer("get-ac", (function(e) {
                                    try {
                                        var t = ze.hasCookie("hc_accessibility");
                                        e.resolve(t)
                                    } catch (pr) {
                                        De("get-ac", pr), e.reject(pr)
                                    }
                                }))
                            }(b, l), Nn.add(b), s
                    }
                    Te(e, "Your browser is missing or has disabled Cross-Window Messaging. Please <a style='color:inherit;text-decoration:underline; font: inherit' target='_blank' href='https://www.whatismybrowser.com/guides/how-to-update-your-browser/auto'>upgrade your browser</a> or enable it for hCaptcha.com")
                } else console.log("[hCaptcha] render: invalid challenge container '" + t["challenge-container"] + "'.");
            else {
                console.log("[hCaptcha] render: invalid container '" + e + "'.");
                var w = e && "object" == typeof e;
                Be("invalid-container", "error", "render", {
                    container: e,
                    containerTypeof: typeof e,
                    containerNodeType: w ? e.nodeType : "-",
                    containerTagNameTypeof: w ? typeof e.tagName : "-"
                })
            }
        }, function() {
            try {
                return ur.apply(this, arguments)
            } catch (pr) {
                De("global", pr)
            }
        }),
        reset: function(e) {
            var t;
            if (e) {
                if (!(t = Nn.getById(e))) throw new Un(e);
                t.reset()
            } else {
                if (!(t = Nn.getByIndex(0))) throw new xn;
                t.reset()
            }
        },
        remove: Cn,
        execute: Pn,
        getResponse: function(e) {
            var t, n;
            if ((n = e ? Nn.getById(e) : Nn.getByIndex(0)) && (t = n.checkbox.response || ""), void 0 !== t) return t;
            throw e ? new Un(e) : new xn
        },
        getRespKey: Zn,
        close: function(e) {
            var t = !1;
            if (!(t = e ? Nn.getById(e) : Nn.getByIndex(0))) throw e ? new Un(e) : new xn;
            t.closeChallenge({
                event: ne
            })
        },
        setData: function(e, t) {
            if ("object" != typeof e || t || (t = e, e = null), !t || "object" != typeof t) throw Error("[hCaptcha] invalid data supplied");
            var n = !1;
            if (!(n = e ? Nn.getById(e) : Nn.getByIndex(0))) throw e ? new Un(e) : new xn;
            Ae("Set data", "hCaptcha", "info");
            var r = n.challenge.setData.bind(n.challenge);
            n.onReady(r, t)
        },
        nodes: Nn
    };
    ! function(e) {
        try {
            Tn(0)
        } catch (pr) {
            De("vm", pr)
        }
        Ve.file = "hcaptcha";
        var t = document.currentScript,
            n = !1,
            r = !1,
            i = "on",
            o = ee.Browser.width() / ee.Browser.height(),
            a = !(!window.hcaptcha || !window.hcaptcha.render),
            s = !1;

        function l() {
            var e = ee.Browser.width(),
                t = ee.Browser.height(),
                n = ee.System.mobile && o !== e / t;
            o = e / t, h(), hr.nodes.each((function(r) {
                r.visible && r.resize(e, t, n)
            }))
        }

        function c(e) {
            u(), hr.nodes.each((function(e) {
                e.visible && e.position()
            }))
        }

        function u() {
            try {
                var e = [ee.Browser.scrollX(), ee.Browser.scrollY(), document.documentElement.clientWidth / ee.Browser.width(), Date.now()];
                En.circBuffPush("xy", e), bn.circBuffPush("xy", e)
            } catch (pr) {
                De("motion", pr)
            }
        }

        function h() {
            try {
                var e = [ee.Browser.width(), ee.Browser.height(), ee.System.dpr(), Date.now()];
                En.circBuffPush("wn", e)
            } catch (pr) {
                De("motion", pr)
            }
        }
        window.hcaptcha = {
                render: function() {
                    return a || console.warn("[hCaptcha] should not render before js api is fully loaded. `render=explicit` should be used in combination with `onload`."), hr.render.apply(this, arguments)
                },
                remove: hr.remove,
                execute: hr.execute,
                reset: hr.reset,
                close: hr.close,
                setData: hr.setData,
                getResponse: hr.getResponse,
                getRespKey: hr.getRespKey
            }, Dn.run({
                topLevel: !0
            }),
            function(e) {
                var t = Array.prototype.slice.call(arguments, 1);
                !0 !== nn && "interactive" !== document.readyState && "loaded" !== document.readyState && "complete" !== document.readyState ? (en.push({
                    fn: e,
                    args: t
                }), !1 === tn && rn()) : setTimeout((function() {
                    e(t)
                }), 1)
            }((function() {
                ! function() {
                    var o;
                    o = t ? [t] : document.getElementsByTagName("script");
                    var a = -1,
                        l = !1,
                        c = null,
                        u = null;
                    for (; ++a < o.length && !1 === l;) o[a] && o[a].src && (u = (c = o[a].src.split("?"))[0], /\/(hcaptcha|1\/api)\.js$/.test(u) && (l = o[a], u && -1 !== u.toLowerCase().indexOf("www.") && console.warn("[hCaptcha] JS API is being loaded from www.hcaptcha.com. Please use https://js.hcaptcha.com/1/api.js")));
                    if (!1 === l) return;
                    e = e || He(c[1]), n = e.onload || !1, r = e.render || !1, s = Boolean(e.uj) || !1, "off" === e.tplinks && (i = "off");
                    ve.tplinks = i, ve.language = e.hl || null, e.endpoint && (ve.endpoint = e.endpoint);
                    ve.reportapi = e.reportapi || ve.reportapi, ve.imghost = e.imghost || null, ve.custom = e.custom || ve.custom, ve.se = e.se || null, ve.pat = e.pat || ve.pat, ve.pstIssuer = e.pstissuer || ve.pstIssuer, ve.andint = e.andint || ve.andint, ve.orientation = e.orientation || null, e.assethost && (ft.URL(e.assethost) ? ve.assethost = e.assethost : console.error("Invalid assethost uri."));
                    ve.isSecure = "https:" === window.location.protocol, ve.recaptchacompat = e.recaptchacompat || ve.recaptchacompat, Ve.host = e.host || window.location.hostname, ve.sentry = !1 !== e.sentry, Ce(!0, !1), ve.language = ve.language || window.navigator.userLanguage || window.navigator.language, Pt.setLocale(ve.language), "off" === ve.recaptchacompat ? console.log("recaptchacompat disabled") : window.grecaptcha = window.hcaptcha
                }(), n && setTimeout((function() {
                    ht(n)
                }), 1), a || (a = !0, function() {
                    var e = Pt.getLocale();
                    if ("en" === e) return;
                    ar(e).then((function() {
                        hr.nodes.each((function(t) {
                            if (t) try {
                                t.isLangSet() || t.updateTranslation(e)
                            } catch (pr) {
                                De("translation", pr)
                            }
                        }))
                    }))["catch"]((function(t) {
                        Be("lang:loading-error", "error", "api", {
                            locale: e,
                            error: t
                        })
                    }))
                }(), !1 === r || "onload" === r ? Se(hr.render) : "explicit" !== r && console.log("hcaptcha: invalid render parameter '" + r + "', using 'explicit' instead."), function() {
                    try {
                        En.record(), En.setData("sc", ee.Browser.getScreenDimensions()), En.setData("or", ee.Browser.getOrientation()), En.setData("wi", ee.Browser.getWindowDimensions()), En.setData("nv", ee.Browser.interrogateNavigator()), En.setData("dr", document.referrer), h(), u(), bn.record({
                            1: !0,
                            2: !0,
                            3: !0,
                            4: !1
                        }), bn.setData("sc", ee.Browser.getScreenDimensions()), bn.setData("wi", ee.Browser.getWindowDimensions()), bn.setData("or", ee.Browser.getOrientation()), bn.setData("dr", document.referrer)
                    } catch (pr) {
                        De("motion", pr)
                    }
                }(), function() {
                    try {
                        Rn.record({
                            1: !1,
                            2: !0,
                            3: !0,
                            4: !0,
                            5: !0,
                            6: !0,
                            7: s,
                            8: s
                        })
                    } catch (pr) {
                        De("bi-vm", pr)
                    }
                }(), sn.addEventListener("resize", l), sn.addEventListener("scroll", c))
            }))
    }()
}();